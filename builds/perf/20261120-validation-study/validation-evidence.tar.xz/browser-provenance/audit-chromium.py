#!/usr/bin/env python3
"""Independent audit of one immutable Chromium study artifact; never pools cells."""

import argparse
import collections
import datetime
import functools
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import random
import statistics
import subprocess
import sys
import traceback
import zipfile


REPOSITORY = Path('/workspace/scratch/f34c9c9fae89/manabitan-validation-study')
TOOLING = '007f16306b9f8036a9930b653fbffca3c750068e'
TOOLING_TREE = '22ae6f01e31d5a83da431cb078ba7f474f6578e1'
MANIFEST_SHA256 = '6b95afafe06e522bd05375541eaa765236e7df32c77a8f8808448789663c2b6a'
SOURCES = {
    'baseline': ('bde55dfbee1451edc32051f8bf51e8a870d5c72c', 'd6df511865f88246b21aa4688ff40cc455c719c4'),
    'validation': ('9b947eb6130020bdd2986787cb42df3a7eb72d73', '1537fcc1e181e3f3711b9bc2d06bf7cccf4ffee6'),
    'checksum': ('025596858e4e176d92c8f7f016057317c60c2793', 'cbd4e38c90b1776094185633649e924ef2b03a09'),
}
ARMS = {'A': 'baseline', 'B': 'validation', 'C': 'baseline', 'D': 'checksum'}
PAIRS = {'C/A': ['A', 'C'], 'B/A': ['A', 'B'], 'D/A': ['A', 'D']}
ORDERS = ['ABCD', 'BDAC', 'CADB', 'DCBA']


def check(condition, message):
    if not condition:
        raise RuntimeError(message)


def read(path):
    return json.loads(path.read_text())


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


@functools.cache
def git_bytes(revision, name):
    return subprocess.check_output(['git', 'show', revision + ':' + name], cwd=REPOSITORY)


@functools.cache
def git_hash(revision, name):
    return hashlib.sha256(git_bytes(revision, name)).hexdigest()


def equal_numeric(actual, expected):
    if isinstance(expected, dict):
        return isinstance(actual, dict) and actual.keys() == expected.keys() and all(equal_numeric(actual[key], value) for key, value in expected.items())
    if isinstance(expected, list):
        return isinstance(actual, list) and len(actual) == len(expected) and all(equal_numeric(a, b) for a, b in zip(actual, expected))
    if isinstance(expected, float):
        return type(actual) in (int, float) and math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-10)
    return actual == expected


def calculate_pairs(pairs):
    changes = [(candidate / baseline - 1) * 100 for baseline, candidate in pairs]
    rng = random.Random(20261119)
    # Match the declared seed/resampling procedure using raw observed pairs;
    # do not import the measured driver's analysis implementation.
    medians = sorted(statistics.median(rng.choices(changes, k=len(changes))) for _ in range(10000))
    return {'pairs': len(pairs), 'pairedChangesPercent': changes,
            'medianPairedChangePercent': statistics.median(changes),
            'equalWorkChangePercent': (sum(candidate for _, candidate in pairs) / sum(baseline for baseline, _ in pairs) - 1) * 100,
            'fasterPairs': sum(candidate < baseline for baseline, candidate in pairs),
            'worstPairPercent': max(changes), 'descriptiveBootstrap95Percent': [medians[250], medians[9749]]}


def distribution(values):
    ordered = sorted(values)
    return {'count': len(ordered), 'min': ordered[0], 'median': statistics.median(ordered),
            'p95': ordered[math.ceil(len(ordered) * 0.95) - 1], 'max': ordered[-1]}


def schedule(replication):
    result = []
    for warmup, order in enumerate(['ABCD', 'DCBA']):
        if replication == 'reverse':
            order = order[::-1]
        result += [{'label': f'warmup-{warmup + 1}-{arm}', 'arm': arm, 'warmup': True, 'block': warmup} for arm in order]
    for block in range(24):
        order = ORDERS[block % 4]
        if replication == 'reverse':
            order = order[::-1]
        result += [{'label': f'block-{block + 1:02d}-{arm}', 'arm': arm, 'warmup': False, 'block': block} for arm in order]
    return result


def audit(directory, archive, replication, source_probes):
    manifest_path = directory / 'manifest.json'
    manifest = read(manifest_path)
    preparation = read(directory / 'preparation.json')
    cohort = read(directory / 'cohort.json')
    check(digest(manifest_path) == MANIFEST_SHA256, 'Wrong measured manifest')
    check(preparation['diagnosticCommit'] == TOOLING, 'Wrong measured tooling commit')
    check(manifest['arms'] == ARMS and manifest['comparisonPairs'] == PAIRS, 'Wrong arms or controls')
    check(manifest['blocks'] == 24 and manifest['warmupsPerArm'] == 2, 'Changed sample schedule')
    check(manifest['node'] == preparation['node'] == 'v22.22.0', 'Unexpected Node runtime')
    check(preparation['manifestSha256'] == cohort['manifestSha256'] == MANIFEST_SHA256, 'Manifest receipt mismatch')
    check(preparation['complete'] is True and cohort['complete'] is True and cohort['failures'] == [], 'Failed or incomplete cell')
    check(preparation['browser'] == cohort['browser'] == 'chromium' and preparation['replication'] == cohort['replication'] == replication, 'Wrong cell')
    check(cohort['dictionary'] == preparation['dictionary'] == manifest['dictionary'] == 'jmdict', 'Wrong workload')
    check(cohort['completedAt'] - cohort['startedAt'] <= manifest['measurementDeadlineMinutes'] * 60 + 180, 'Deadline inconsistency')

    with zipfile.ZipFile(archive) as payload:
        check(payload.testzip() is None, 'ZIP CRC failure')
        files = [entry for entry in payload.infolist() if not entry.is_dir()]
        check(len({entry.filename for entry in files}) == len(files), 'Duplicate ZIP paths')
        for entry in files:
            name = PurePosixPath(entry.filename)
            check(not name.is_absolute() and '..' not in name.parts, 'Unsafe ZIP path')
            extracted = directory.joinpath(*name.parts)
            check(extracted.is_file(), 'Missing extracted payload: ' + entry.filename)
            check(hashlib.sha256(payload.read(entry)).hexdigest() == digest(extracted), 'Changed extracted payload: ' + entry.filename)
        archive_inventory = {'sha256': digest(archive), 'bytes': archive.stat().st_size,
                             'filePayloads': len(files), 'uncompressedBytes': sum(entry.file_size for entry in files)}

    for name, expected in manifest['harnessSha256'].items():
        copied = directory / 'tooling' / name
        check(copied.is_file() and digest(copied) == expected, 'Missing or changed embedded harness input: ' + name)
        check(git_hash(TOOLING_TREE, name) == expected, 'Harness differs from measured tooling tree: ' + name)
    check(digest(directory / 'driver.py') == manifest['harnessSha256']['dev/perf/jmdict-validation-study/run.py'], 'Changed standalone driver')
    check(digest(directory / 'workflow.yml') == manifest['harnessSha256'][manifest['workflow']], 'Changed standalone workflow')

    package_entries = {arm: read(directory / (arm + '-package-entries.json')) for arm in ARMS}
    check(package_entries['A'] == package_entries['C'], 'Baseline package contents differ')
    overlays = set()
    for arm, role in ARMS.items():
        source = manifest['sources'][role]
        expected_commit, expected_tree = SOURCES[role]
        receipt = preparation['arms'][arm]
        check((source['commit'], source['tree']) == (expected_commit, expected_tree), 'Wrong manifest source')
        check((receipt['commit'], receipt['tree'], receipt['source']) == (expected_commit, expected_tree, role), 'Wrong prepared source')
        check(receipt['buildTarget'] == 'chrome', 'Wrong build target')
        for name, expected in manifest['sharedProductInputs'].items():
            check(receipt['frozenFiles'][name] == expected == git_hash(expected_commit, name), 'Changed shared product input: ' + name)
        for name in source['productPaths']:
            check(receipt['frozenFiles'][name] == git_hash(expected_commit, name), 'Changed candidate product file: ' + name)
        for role_name, (commit, _) in SOURCES.items():
            for name in manifest['sources'][role_name]['productPaths']:
                check(package_entries[arm][name.removeprefix('ext/')] == git_hash(expected_commit, name), 'Packaged candidate-path bytes do not match source')
        changed = sorted(name for name in package_entries['A'].keys() | package_entries[arm].keys() if package_entries['A'].get(name) != package_entries[arm].get(name))
        check(changed == sorted(name.removeprefix('ext/') for name in source['productPaths']), 'Unexpected changed package entries')
        overlay = receipt['commonGeneratedOverlay']['ext/legal-npm.html']
        check(receipt['frozenFiles']['ext/legal-npm.html'] == package_entries[arm]['legal-npm.html'] == overlay, 'Legal overlay identity mismatch')
        overlays.add(overlay)
    check(len(overlays) == 1, 'Generated legal pages differ between arms')
    fixture = preparation['fixture']
    lock = read(directory / 'tooling/test/perf/dictionaries.lock.json')
    check(fixture == lock['dictionaries']['jmdict'] and fixture['termRows'] == 526942, 'Wrong pinned fixture')
    check(source_probes['archiveSha256'] == fixture['sha256'] and source_probes['archiveBytes'] == fixture['sizeBytes'], 'Wrong source-probe archive identity')
    check(source_probes['fixtureLockSha256'] == digest(directory / 'tooling/test/perf/dictionaries.lock.json'), 'Wrong source-probe lock identity')
    expected_probes = [probe['expression'] for probe in source_probes['probes']]
    check(len(expected_probes) == 12 and source_probes['banks'] == 53, 'Incomplete source-probe derivation')

    expected_schedule = schedule(replication)
    check(cohort['planned'] == expected_schedule and len(cohort['observations']) == 104, 'Missing or changed observation schedule')
    check({path.name for path in (directory / 'observations').iterdir()} == {item['label'] for item in expected_schedule}, 'Extra or missing observation directories')
    expected_commands = {'verify-source-bundle', 'import-source-bundle', 'prepare-fixtures'}
    expected_commands |= {f'{stage}-{arm}' for arm in ARMS for stage in ['worktree', 'libraries', 'package']}
    expected_commands |= {item['label'] for item in expected_schedule}
    check({path.name for path in (directory / 'commands').iterdir()} == expected_commands, 'Extra or missing attempted commands')
    for label in expected_commands:
        command_dir = directory / 'commands' / label
        command = read(command_dir / 'command.json')
        check(command['complete'] is True and command['exitCode'] == 0 and not command.get('timedOut') and not command.get('error'), 'Failed command: ' + label)
        check(command['completedAt'] >= command['startedAt'] and command['elapsedSeconds'] >= 0, 'Invalid command timing')
        check((command_dir / 'stdout.log').is_file() and (command_dir / 'stderr.log').is_file(), 'Missing command logs')

    digests, versions, dirty_flags = set(), set(), collections.Counter()
    effective_flags, parser_flags, compression_flags, term_counter_records, final_counter_records = set(), set(), set(), set(), set()
    host_records = set()
    measured = {}
    phase_values = {arm: collections.defaultdict(list) for arm in ARMS}
    exact_cache_counts = {arm: set() for arm in ARMS}
    for item, observed in zip(expected_schedule, cohort['observations']):
        label, arm = item['label'], item['arm']
        check(all(observed[key] == value for key, value in item.items()) and not observed.get('error'), 'Observation order/status mismatch: ' + label)
        check(observed['directory'] == 'observations/' + label and observed['command'] == 'commands/' + label + '/command.json', 'Wrong observation receipt routes')
        path = directory / observed['directory']
        summary = read(path / 'summary.json')
        report = read(path / 'run-1.json')
        receipt = preparation['arms'][arm]
        command = read(directory / observed['command'])
        check(command['cwd'] == receipt['root'] and command['environmentOverrides'] == {}, 'Wrong source/environment for observation')
        check(0 < command['timeoutSeconds'] <= 180, 'Changed observation timeout')
        check(command['command'][:-1] == ['node', 'dev/perf/import-benchmark.js', 'jmdict', '--runs', '1', '--no-build', '--build-target', 'chrome', '--output'], 'Wrong observation invocation')
        check(command['command'][-1].endswith('/observations/' + label), 'Wrong output route')
        check(summary['schemaVersion'] == 3 and summary['authoritativeTiming'] is True and summary['traceEnabled'] is False and summary['importFlags'] is None, 'Non-authoritative summary')
        check(summary['fixture'] == fixture and summary['gitSha'] == receipt['commit'] and summary['buildTarget'] == 'chrome', 'Wrong observed source/fixture')
        check(len(summary['runs']) == 1 and summary['runs'][0]['index'] == 1, 'Observation contains multiple imports')
        run = summary['runs'][0]
        check(run['tracePath'] is None and run['packageSha256'] == report['packageSha256'] == receipt['packageSha256'], 'Wrong package or trace')
        check(report['status'] == 'success' and report['skippedVerification'] is False and not report['failureReason'] and not report['skipReason'], 'Failed raw report')
        check(report['browserFlavor'] == 'chromium' and report['launchMode'] == 'headless' and report['buildTarget'] == 'chrome', 'Changed browser launch configuration')
        benchmark = report['benchmark']
        for key, expected in {'dictionary': 'jmdict', 'pinnedDictionaries': True, 'productionImportDefaults': True,
                              'traceEnabled': False, 'authoritativeTiming': True, 'phaseProfiling': False,
                              'phaseScreenshots': False, 'processSampling': False, 'importFlags': None}.items():
            check(benchmark[key] == expected, 'Changed benchmark policy: ' + key)
        phases = report['phases']
        imports = [phase for phase in phases if phase['name'] == fixture['label'] + ': total import']
        triggers = [phase for phase in phases if phase['name'] == 'Import ' + fixture['label'] + ' via file input']
        check(len(imports) == len(triggers) == 1, 'Missing or duplicate external timing phases')
        phase, trigger = imports[0], triggers[0]
        check(phase['startMs'] == trigger['startMs'] <= trigger['endMs'] <= phase['endMs'], 'Import timing excludes dispatch or completion')
        check(math.isclose(phase['durationMs'], phase['endMs'] - phase['startMs'], abs_tol=0.001), 'Inconsistent automation timing')
        timing = phase['data']['browserTiming']
        check(timing['trigger'] == 'file-input-change' and timing['errorCount'] == 0 and timing['sequence'] > timing['sequenceBefore'], 'Not current-operation browser timing')
        elapsed = timing['completedAtMs'] - timing['startedAtMs']
        check(math.isfinite(elapsed) and elapsed > 0 and math.isclose(elapsed, run['totalImportMs'], abs_tol=1e-8) and elapsed == observed['totalImportMs'], 'Authoritative timing mismatch')
        debug = phase['data']['importDebug']
        check(debug == run['importDebug'] == observed['importDebug'], 'Changed debug evidence')
        check(debug['hasResult'] is True and debug['resultTitle'] == fixture['expectedTitle'] and debug['errorCount'] == debug['addSettingsErrorCount'] == 0 and debug['usesFallbackStorage'] is False, 'Import errors or fallback storage')
        check(debug['openStorageDiagnostics']['mode'] == report['runtimeDiagnostics']['openStorageMode'] == 'opfs-sahpool', 'Wrong storage path')
        term_phases = [p for p in debug['importerPhaseTimings'] if p['phase'].startswith('term-file')]
        check(len(term_phases) == 1 and term_phases[0]['phase'].startswith('term-file-fast-path:'), 'Changed native term path')
        details = term_phases[0]['details']
        for key, expected in {'rows': 526942, 'batchedFileCount': 53, 'chunkCount': 12,
                              'parserSourceCompressedBytes': 15574114, 'parserSourceTransferredBytes': 15574114,
                              'parserSourceUncompressedBytes': 171092992, 'parserParallelWorkerCount': 3,
                              'parserParallelGroupCount': 12, 'parserFusedFallbacks': 0, 'parserDiscardedFusedRows': 0,
                              'dedupNativeFallbackCount': 0, 'sourceInitialPrefetchFileCount': 0,
                              'sourceInitialPrefetchEstimatedBytes': 0}.items():
            check(details[key] == expected, 'Executed-work mismatch: ' + key)
        finalizations = [p['details'] for p in debug['importerPhaseTimings'] if p['phase'] == 'bulk-finalization']
        check(len(finalizations) == 1, 'Wrong finalization count')
        finalization = finalizations[0]
        check(finalization['ok'] is True and finalization['published'] is True and finalization['housekeepingErrors'] == [], 'Unclean publication')
        data_banks = [p['details'] for p in debug['importerPhaseTimings'] if p['phase'] == 'import-data-banks']
        check(len(data_banks) == 1, 'Wrong data-bank receipt count')
        effective_flags.add(json.dumps(data_banks[0]['fastPathParserEffectiveExperiments'], sort_keys=True))
        parser_flags.add(json.dumps(details['parserExperiments'], sort_keys=True))
        compression_flags.add(json.dumps(finalization['compressionExperiments'], sort_keys=True))
        term_counter_records.add(json.dumps({key: value for key, value in details.items() if not key.endswith('Ms') and not isinstance(value, (dict, list))}, sort_keys=True))
        final_counter_records.add(json.dumps({key: value for key, value in finalization.items() if not key.endswith('Ms') and not isinstance(value, (dict, list))}, sort_keys=True))
        validation = benchmark['validation']
        check(validation == run['validation'] == observed['validation'], 'Changed correctness receipt')
        for target in [validation, validation['restart']]:
            check(target['title'] == fixture['expectedTitle'] and target['revision'] == fixture['revision'] and target['termRows'] == 526942 and target['contentReadable'] is True and target['probeCount'] == 12, 'Bad persistence/content result')
        check(validation['probeTerms'] == expected_probes, 'Wrong source-derived expression probes')
        digests.add(validation['outputDigestSha256'])
        check(summary['browserVersion'] == run['browserVersion'] == report['browserVersion'] == observed['browserVersion'], 'Mixed runtime versions')
        versions.add(summary['browserVersion'])
        provenance = summary['source']
        check(provenance['gitSha'] == receipt['commit'], 'Wrong observed source provenance')
        dirty_flags[str(provenance['dirty'])] += 1
        for name, expected in provenance['sha256'].items():
            if name == 'builds/manabitan-chrome.zip':
                check(expected == receipt['packageSha256'], 'Package provenance mismatch')
            elif expected is not None:
                check(expected == git_hash(receipt['commit'], name), 'Source provenance hash mismatch: ' + name)
        host = summary['hostEnvironment']
        check(host['nodeVersion'] == 'v22.22.0' and host['platform'] == 'linux', 'Wrong observation host/runtime')
        host_records.add(json.dumps({key: host[key] for key in ['nodeVersion', 'v8Version', 'platform', 'arch', 'cpuModel', 'logicalCpuCount', 'totalMemoryBytes']}, sort_keys=True))
        exact_cache_counts[arm].add((details['dedupExactFallbackCount'], details['dedupRecentSourceHitCount']))
        if not item['warmup']:
            measured[(item['block'], arm)] = elapsed
            for key, value in details.items():
                if key.endswith('Ms') and type(value) in (int, float):
                    phase_values[arm][key].append(value)
            phase_values[arm]['finalizationTotalMs'].append(finalization['totalMs'])
    check(len(measured) == 96 and len(digests) == len(versions) == len(host_records) == 1, 'Mixed outputs, runtimes, hosts or missing measured imports')
    check(len(effective_flags) == len(parser_flags) == len(compression_flags) == 1, 'Different executed policies across arms')
    check(next(iter(versions)) in preparation['browserRuntime']['version'], 'Prepared and executed versions differ')
    comparisons = {label: calculate_pairs([(measured[(block, baseline)], measured[(block, candidate)]) for block in range(24)]) for label, (baseline, candidate) in PAIRS.items()}
    check(equal_numeric(cohort['statistics'], comparisons), 'Independent statistics differ from frozen cohort')
    return {'complete': True, 'browser': 'chromium', 'replication': replication,
            'toolingCommit': TOOLING, 'toolingTree': TOOLING_TREE, 'manifestSha256': MANIFEST_SHA256,
            'archive': archive_inventory, 'harnessInputsVerified': len(manifest['harnessSha256']),
            'sharedProductInputsVerifiedPerArm': len(manifest['sharedProductInputs']),
            'attemptedCommands': len(expected_commands), 'attemptedObservations': 104, 'measuredObservations': 96, 'warmups': 8,
            'failures': [], 'sourceIdentities': {name: {'commit': commit, 'tree': tree} for name, (commit, tree) in SOURCES.items()},
            'packageSha256': {arm: preparation['arms'][arm]['packageSha256'] for arm in ARMS},
            'packageEntryCount': {arm: len(package_entries[arm]) for arm in ARMS}, 'commonLegalSha256': sorted(overlays),
            'fixture': fixture, 'browserRuntime': preparation['browserRuntime'], 'observedVersions': sorted(versions),
            'host': json.loads(next(iter(host_records))), 'observedDirtyFlags': dict(dirty_flags),
            'sampledContentDigests': sorted(digests), 'verifiedProbeExpressions': expected_probes,
            'effectiveFlags': json.loads(next(iter(effective_flags))),
            'parserFlags': json.loads(next(iter(parser_flags))), 'compressionFlags': json.loads(next(iter(compression_flags))),
            'termCounterRecords': [json.loads(value) for value in sorted(term_counter_records)],
            'finalizationCounterRecords': [json.loads(value) for value in sorted(final_counter_records)],
            'exactAndRecentSourceHits': {arm: sorted(values) for arm, values in exact_cache_counts.items()},
            'armTimingsMs': {arm: distribution([measured[(block, arm)] for block in range(24)]) for arm in ARMS},
            'comparisons': comparisons,
            'phaseMediansMs': {arm: {key: statistics.median(values) for key, values in sorted(columns.items())} for arm, columns in phase_values.items()},
            'limits': ['No pooling of browsers, hosts, order cells, candidates or attempts; no control subtraction.',
                       'Bootstrap intervals are descriptive, not corrected for time dependence or multiple comparisons.',
                       'Chromium checks 12 source-derived terms for bounds, readability and previews before/after browser restart; it does not compare expected reading/full glossary against the archive.',
                       'Fresh processes/profiles and full restart are bound by the pinned observer; per-observation profile paths/PIDs are not archived.',
                       'Runtime executable hashes are checked repeatedly by the frozen driver, but the Chromium executable is not embedded in this evidence.',
                       'Dirty provenance is retained; common legal-page output and harness/dependency overlays do not imply a clean checkout.',
                       'WASM heaps and untimed snapshots are not peak process memory; nested phase medians are not whole-import savings.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', required=True, type=Path)
    parser.add_argument('--archive', required=True, type=Path)
    parser.add_argument('--replication', required=True, choices=['forward', 'reverse'])
    parser.add_argument('--probe-receipt', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    check(not args.output.exists(), 'Refusing to overwrite an audit attempt')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    source = Path(__file__).read_bytes()
    snapshot = args.output.with_suffix('.py')
    check(not snapshot.exists(), 'Refusing to overwrite auditor source snapshot')
    snapshot.write_bytes(source)
    receipt = {'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'auditorSha256': hashlib.sha256(source).hexdigest(), 'evidence': str(args.evidence.resolve()),
               'originalArchive': str(args.archive.resolve()), 'complete': False}
    try:
        receipt['sourceProbeReceiptSha256'] = digest(args.probe_receipt)
        receipt.update(audit(args.evidence, args.archive, args.replication, read(args.probe_receipt)))
    except Exception as error:
        receipt['error'] = str(error)
        receipt['traceback'] = traceback.format_exc()
    receipt['completedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    args.output.write_text(json.dumps(receipt, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'output': str(args.output), 'complete': receipt['complete'], 'error': receipt.get('error'),
                      'comparisons': {key: {'median': value['medianPairedChangePercent'], 'equalWork': value['equalWorkChangePercent'],
                                            'faster': value['fasterPairs'], 'interval': value['descriptiveBootstrap95Percent']}
                                      for key, value in receipt.get('comparisons', {}).items()}}))
    return 0 if receipt['complete'] else 1


if __name__ == '__main__':
    sys.exit(main())
