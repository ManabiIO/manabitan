#!/usr/bin/env python3
"""Execute the predeclared six generic/fixed-format component cohorts once."""

import datetime
import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import time


ROOT = Path('/workspace/scratch/f34c9c9fae89')
DIRECTORY = ROOT / 'manabitan-validation/builds/perf/20261120-validation'
RUNNER = DIRECTORY / 'record-validation-formats-screen.mjs'
RECEIPT = DIRECTORY / 'format-cohorts.json'
PLAN = [(form, mode) for form in ('arrays', 'fixed-length', 'fixed-span') for mode in ('measure', 'control')]


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def identities():
    previous = json.loads((DIRECTORY / 'cohort-before.json').read_text())
    result = {'sources': {}}
    for label, expected in previous['sources'].items():
        path = Path(expected['root'])
        git = lambda *args: subprocess.check_output(['git', '-C', str(path), *args], text=True).strip()
        value = {'root': str(path), 'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'trackedDiff': git('diff', 'HEAD', '--name-only'), 'hashes': {relative: digest(path / relative) for relative in expected['hashes']}}
        assert value == expected
        result['sources'][label] = value
    result['runnerSha256'] = digest(RUNNER)
    assert result['runnerSha256'] == 'a6c7fa0be236a693c2496c26cae01752a20ec352fdafd1cfa72f684cf5f68cf4'
    result['archiveSha256'] = digest(ROOT / 'fixtures/JMdict.zip')
    assert result['archiveSha256'] == previous['archiveSha256']
    result['originalComponentFiles'] = {name: digest(DIRECTORY / name) for name in ('record-validation-screen.mjs', 'candidate-screen.json', 'control-screen.json', 'cohort-before.json', 'cohort-after.json', 'evidence-receipt.json')}
    return result


def save(value):
    temporary = RECEIPT.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(RECEIPT)


def main():
    assert not RECEIPT.exists()
    before = identities()
    receipt = {'startedAt': now(), 'status': 'running', 'plan': PLAN, 'before': before, 'cohorts': [], 'runnerSha256': digest(Path(__file__))}
    save(receipt)
    print(json.dumps({'startedAt': receipt['startedAt'], 'status': 'all identities bound before timing'}), flush=True)
    for form, mode in PLAN:
        output = DIRECTORY / f'format-{form}-{mode}.json'
        log = DIRECTORY / f'format-{form}-{mode}.log'
        assert not output.exists() and not log.exists()
        command = ['node', '--expose-gc', str(RUNNER), str(ROOT / 'manabitan'), str(ROOT / 'manabitan-validation'), str(ROOT / 'fixtures/JMdict.zip'), str(output), mode, form]
        item = {'format': form, 'mode': mode, 'command': command, 'startedAt': now(), 'output': str(output), 'log': str(log)}
        receipt['cohorts'].append(item)
        save(receipt)
        started = time.monotonic()
        with log.open('xb') as stream:
            result = subprocess.run(command, cwd=ROOT / 'manabitan-validation', stdout=stream, stderr=subprocess.STDOUT)
        item.update({'completedAt': now(), 'durationSeconds': time.monotonic() - started, 'exitCode': result.returncode, 'logSha256': digest(log)})
        save(receipt)
        if result.returncode != 0:
            receipt.update({'status': 'failed', 'completedAt': now()})
            save(receipt)
            return result.returncode
        data = json.loads(output.read_text())
        assert len(data['observations']) == 104 and len(data['paired']) == 24
        assert data['runnerSha256'] == before['runnerSha256']
        preflight = json.loads((DIRECTORY / f'format-{form}-verify.json').read_text())
        assert data['oracle'] == preflight['oracle'] and data['descriptors'] == preflight['descriptors']
        item['outputSha256'] = digest(output)
        item['summary'] = data['summary']
        item['armMediansPerDictionary'] = {
            arm: {key: statistics.median(observation[key] for observation in data['observations'] if observation['arm'] == arm and not observation['warmup']) / data['protocol']['iterationsPerObservation'] for key in ('validationMs', 'wallMs')}
            for arm in 'AB'
        }
        save(receipt)
        print(json.dumps({'format': form, 'mode': mode, 'summary': item['summary'], 'armMediansPerDictionary': item['armMediansPerDictionary']}), flush=True)
    after = identities()
    assert after == before
    receipt.update({'after': after, 'identitiesUnchanged': True, 'status': 'completed', 'completedAt': now()})
    save(receipt)
    print(json.dumps({'status': 'completed', 'identitiesUnchanged': True, 'receipt': str(RECEIPT)}), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
