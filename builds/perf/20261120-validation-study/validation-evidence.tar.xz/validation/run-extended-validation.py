#!/usr/bin/env python3
"""Record required validation on the frozen JMdict validation-loop candidate."""

import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time


ROOT = Path('/workspace/scratch/f34c9c9fae89')
BASELINE = ROOT / 'manabitan'
CANDIDATE = ROOT / 'manabitan-validation'
OUTPUT = CANDIDATE / 'builds/perf/20261120-validation'
RECEIPT = OUTPUT / 'extended-validation.json'
WASM = [
    'ext/lib/term-bank-parser.wasm',
    'ext/lib/term-content-canonical-scan-v1.wasm',
    'ext/lib/zstd.wasm',
    'ext/lib/resvg.wasm',
    'ext/lib/sqlite/sqlite3.wasm',
]
ENVIRONMENT = (
    'set -e\n'
    'source /workspace/scratch/f34c9c9fae89/toolchains/llvm21-env.sh\n'
    'export NODE_OPTIONS=--max-old-space-size=2048\n'
)


def now():
    return datetime.datetime.now(datetime.UTC).isoformat()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(CANDIDATE), *args], text=True).strip()


def save(receipt):
    temporary = RECEIPT.with_suffix('.tmp')
    temporary.write_text(json.dumps(receipt, indent=2) + '\n')
    temporary.replace(RECEIPT)


def run(label, command, receipt):
    log = OUTPUT / f'{label}.log'
    item = {'label': label, 'command': ENVIRONMENT + command, 'cwd': str(CANDIDATE), 'startedAt': now(), 'log': str(log)}
    receipt['commands'].append(item)
    save(receipt)
    started = time.monotonic()
    with log.open('wb') as stream:
        process = subprocess.run(
            ['bash', '--noprofile', '--norc', '-c', ENVIRONMENT + command],
            cwd=CANDIDATE, stdout=stream, stderr=subprocess.STDOUT,
        )
    item.update({'completedAt': now(), 'durationSeconds': time.monotonic() - started, 'exitCode': process.returncode, 'logSha256': digest(log), 'logBytes': log.stat().st_size})
    save(receipt)
    print(json.dumps(item), flush=True)
    return process.returncode


def main():
    if RECEIPT.exists():
        raise RuntimeError('Preserve the existing validation receipt; use a separately named runner for a new attempt')
    assert git('rev-parse', 'HEAD') == '9b947eb6130020bdd2986787cb42df3a7eb72d73'
    assert git('rev-parse', 'HEAD^{tree}') == '1537fcc1e181e3f3711b9bc2d06bf7cccf4ffee6'
    assert git('diff', 'HEAD', '--name-only') == ''
    wasm = {relative: {'baseline': digest(BASELINE / relative), 'candidateBefore': digest(CANDIDATE / relative)} for relative in WASM}
    assert all(entry['baseline'] == entry['candidateBefore'] for entry in wasm.values())
    receipt = {
        'startedAt': now(), 'status': 'running',
        'candidate': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
        'baseline': subprocess.check_output(['git', '-C', str(BASELINE), 'rev-parse', 'HEAD'], text=True).strip(),
        'environment': {'nodeOptions': '--max-old-space-size=2048', 'vitestWorkers': 1, 'toolchainEnvironment': str(ROOT / 'toolchains/llvm21-env.sh')},
        'runnerSha256': digest(Path(__file__)),
        'wasm': wasm, 'commands': [],
    }
    save(receipt)
    commands = [
        ('runtime-versions', 'node --version\n"$MANABITAN_CLANG" --version\n"$MANABITAN_WASM_LD" --version'),
        ('full-unit-suite', 'npm run test:unit -- --maxWorkers=1'),
        ('seven-target-dry-build', 'npm run test:build'),
    ]
    for label, command in commands:
        result = run(label, command, receipt)
        if result != 0:
            receipt.update({'status': 'failed', 'completedAt': now(), 'failedCommand': label})
            save(receipt)
            return result
    for relative, entry in receipt['wasm'].items():
        entry['candidateAfter'] = digest(CANDIDATE / relative)
    receipt['wasmUnchanged'] = all(entry['candidateAfter'] == entry['baseline'] == entry['candidateBefore'] for entry in receipt['wasm'].values())
    receipt['trackedDiffAfter'] = git('diff', 'HEAD', '--name-only')
    receipt.update({'status': 'passed', 'completedAt': now()})
    assert receipt['wasmUnchanged']
    assert receipt['trackedDiffAfter'] == ''
    save(receipt)
    print(json.dumps({'receipt': str(RECEIPT), 'status': receipt['status'], 'wasmUnchanged': True}), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
