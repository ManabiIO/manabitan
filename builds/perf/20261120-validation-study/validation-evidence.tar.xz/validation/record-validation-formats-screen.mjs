#!/usr/bin/env node
/* Copyright (C) 2026 Manabitan authors; SPDX-License-Identifier: GPL-3.0-or-later */

// Node component screening only. Native JMdict row-to-unique IDs and encoded
// content spans are replayed through the actual artifact validation method.
// Encoding and append are replaced with constant sinks only during timing.
// Parser/ZIP I/O, fixture copies, full byte-oracle passes, and GC are untimed.
// This does not emulate cross-group persisted dedup or OPFS and cannot support
// an end-to-end import speedup claim.

import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {readFile, writeFile} from 'node:fs/promises'
import {createRequire} from 'node:module'
import os from 'node:os'
import path from 'node:path'
import {fileURLToPath, pathToFileURL} from 'node:url'

const [baselineInput, candidateInput, archiveInput, outputInput, execution = 'verify', format = 'arrays'] = process.argv.slice(2)
assert(baselineInput && candidateInput && archiveInput && outputInput, 'Expected baseline root, candidate root, locked JMdict ZIP, output JSON, and optional measure/control mode')
assert(['verify', 'measure', 'control'].includes(execution), 'Invalid execution mode')
assert(['arrays', 'fixed-length', 'fixed-span'].includes(format), 'Invalid descriptor format')
const baselineRoot = path.resolve(baselineInput)
const candidateRoot = path.resolve(candidateInput)
const archivePath = path.resolve(archiveInput)
const outputPath = path.resolve(outputInput)
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex')
const load = async (root, relative) => await import(pathToFileURL(path.join(root, relative)).href)
const require = createRequire(path.join(baselineRoot, 'package.json'))
const {ZipReader, Uint8ArrayReader, Uint8ArrayWriter} = await import(pathToFileURL(require.resolve('@zip.js/zip.js')).href)
const parser = await load(baselineRoot, 'ext/js/dictionary/term-bank-wasm-parser.js')
const {snapshotTermBankExperiments} = await load(baselineRoot, 'ext/js/dictionary/term-bank-experiments.js')
const {TermRecordOpfsStore: BaselineStore} = await load(baselineRoot, 'ext/js/dictionary/term-record-opfs-store.js')
const {TermRecordOpfsStore: CandidateStore} = await load(candidateRoot, 'ext/js/dictionary/term-record-opfs-store.js')
const flags = snapshotTermBankExperiments()
const lockBytes = await readFile(path.join(baselineRoot, 'test/perf/dictionaries.lock.json'))
const fixture = JSON.parse(lockBytes.toString()).dictionaries.jmdict
const archive = await readFile(archivePath)
assert.equal(archive.length, fixture.sizeBytes)
assert.equal(sha256(archive), fixture.sha256)
const wasmBytes = await readFile(path.join(baselineRoot, 'ext/lib/term-bank-parser.wasm'))
parser.setTermBankWasmModule(await WebAssembly.compile(wasmBytes))
const reader = new ZipReader(new Uint8ArrayReader(new Uint8Array(archive)))
const sources = []
try {
    const entries = (await reader.getEntries())
        .filter((entry) => /^term_bank_\d+\.json$/.test(entry.filename))
        .sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
    for (const entry of entries) {
        sources.push(await entry.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true}))
    }
} finally {
    await reader.close()
}

const chunks = []
const groupProfiles = []
let contentBase = 0
const descriptorHash = createHash('sha256')
for (let start = 0; start < sources.length; start += 7) {
    await parser.parseTermBankWithWasmColumnChunks(sources.slice(start, start + 7), 3, (raw) => {
        assert(raw.contentDedupPlan && raw.contentUniqueIndexList && raw.contentMetaList)
        assert.equal(raw.contentRowStart, 0)
        const uniqueIndexList = new Uint32Array(raw.contentUniqueIndexList)
        const uniqueCount = raw.contentDedupPlan.uniqueCount
        const offsets = new Float64Array(uniqueCount)
        const lengths = new Uint32Array(uniqueCount)
        for (let index = 0; index < uniqueCount; index++) {
            const row = raw.contentDedupPlan.uniqueRowIndexes[index]
            offsets[index] = contentBase + raw.contentMetaList[row * 4]
            lengths[index] = raw.contentMetaList[row * 4 + 1]
        }
        for (const column of [uniqueIndexList, offsets, lengths]) {
            descriptorHash.update(new Uint8Array(column.buffer, column.byteOffset, column.byteLength))
        }
        const chunk = structuredClone({
            dictionary: 'JMdict component replay',
            rowCount: raw.rowCount,
            expressionBytesList: raw.expressionBytesList,
            readingBytesList: raw.readingBytesList,
            readingEqualsExpressionList: raw.readingEqualsExpressionList,
            scoreList: raw.scoreList,
            sequenceList: raw.sequenceList,
            termRecordPreinternedPlan: raw.termRecordPreinternedPlan,
            preparedLookupIndexes: raw.preparedLookupIndexes,
            resolvedContentReferences: {uniqueIndexList, offsets, lengths},
        })
        assert(chunk.preparedLookupIndexes instanceof Map && chunk.preparedLookupIndexes.size > 0)
        chunks.push(chunk)
        contentBase += raw.contentBytesLength
    }, 2048, {
        ...flags,
        singleChunk: true,
        emitTermByteLists: false,
        computeContentHashes: true,
        emitContentSlab: true,
        emitTokenBinaryContent: true,
        mediaHintFastScan: true,
        validateGlossaryTypes: true,
        prepareLookupIndexes: true,
    })
    const profile = parser.consumeLastTermBankWasmParseProfile()
    assert(profile && profile.fusedParseFallbacks === 0)
    groupProfiles.push(profile)
}
assert.equal(chunks.reduce((sum, chunk) => sum + chunk.rowCount, 0), fixture.termRows)

// Generic arrays preserve every real native descriptor value. Fixed forms use
// the same real JMdict keys, scores and lookup indexes, but deliberately replace
// storage lengths (and, for fixed spans, offsets) with a synthetic 32-byte layout.
const nativeDescriptorSha256 = descriptorHash.digest('hex')
const layoutHash = createHash('sha256')
let fixedOffset = 1024
for (const chunk of chunks) {
    const references = chunk.resolvedContentReferences
    chunk.nativeUniqueCount = references.offsets.length
    chunk.replayContentOffsets = Float64Array.from(references.uniqueIndexList, (index) => references.offsets[index])
    chunk.replayContentLengths = Uint32Array.from(references.uniqueIndexList, (index) => references.lengths[index])
    chunk.resolvedContentReferences = void 0
    if (format === 'fixed-length' || format === 'fixed-span') {
        chunk.fixedContentLength = 32
        chunk.replayContentLengths.fill(32)
    }
    if (format === 'fixed-span') {
        chunk.fixedContentOffsetBase = fixedOffset
        chunk.replayContentOffsets = new Float64Array(0)
        chunk.replayContentLengths = new Uint32Array(0)
        fixedOffset += chunk.rowCount * 32
    }
    layoutHash.update(JSON.stringify({format, rowCount: chunk.rowCount, fixedContentOffsetBase: chunk.fixedContentOffsetBase, fixedContentLength: chunk.fixedContentLength}))
    for (const column of [chunk.replayContentOffsets, chunk.replayContentLengths]) {
        layoutHash.update(new Uint8Array(column.buffer, column.byteOffset, column.byteLength))
    }
}
const layoutSha256 = layoutHash.digest('hex')


const empty = new Uint8Array(0)
async function replay(store) {
    let validationMs = 0
    let nextId = 1
    for (const chunk of chunks) {
        const metrics = await store._encodeAndAppendArtifactChunkForState(
            {}, chunk, nextId, chunk.replayContentOffsets, chunk.replayContentLengths,
            chunk.termRecordPreinternedPlan, 'raw', chunk.preparedLookupIndexes,
        )
        validationMs += metrics.validationMs
        nextId += chunk.rowCount
    }
    assert.equal(nextId, fixture.termRows + 1)
    return validationMs
}

async function byteOracle(Store) {
    const store = new Store()
    const digest = createHash('sha256')
    const ranges = []
    store._appendEncodedChunk = async (_state, firstId, count, dictionary, base, lookup, fields, format) => {
        const metadata = {firstId, count, dictionary, base, format, lookupBytes: lookup.byteLength, fieldBytes: fields.byteLength}
        ranges.push(metadata)
        digest.update(JSON.stringify(metadata))
        digest.update(lookup)
        digest.update(fields)
    }
    await replay(store)
    return {sha256: digest.digest('hex'), ranges}
}
const baselineOracle = await byteOracle(BaselineStore)
const candidateOracle = await byteOracle(CandidateStore)
assert.deepEqual(candidateOracle, baselineOracle)

const protocol = {measuredBlocks: 24, warmupBlocks: 2, iterationsPerObservation: 12, order: 'ABBA', groups: 7, sourceBanks: sources.length}
if (execution !== 'verify') {
    assert.equal(typeof globalThis.gc, 'function', 'Measurements require --expose-gc; GC remains outside timing')
}
const makeTimedStore = (Store) => {
    const store = new Store()
    store._encodeArtifactChunkRecords = async (_chunk, _offsets, _lengths, _plan, _prepared, base) => ({
        contentOffsetBase: base, lookupIndexBytes: empty, recordFields: empty,
        recordFieldsFormat: 1, validationMs: 0, recordFieldEncodeMs: 0, lookupIndexEncodeMs: 0,
    })
    store._appendEncodedChunk = async () => {}
    return store
}
const stores = {
    A: makeTimedStore(BaselineStore),
    B: makeTimedStore(execution === 'control' ? BaselineStore : CandidateStore),
}
const observations = []
if (execution !== 'verify') {
    for (let block = -protocol.warmupBlocks; block < protocol.measuredBlocks; block++) {
        for (const arm of protocol.order) {
            globalThis.gc?.()
            const started = performance.now()
            let validationMs = 0
            for (let iteration = 0; iteration < protocol.iterationsPerObservation; iteration++) {
                validationMs += await replay(stores[arm])
            }
            observations.push({
                block, arm, warmup: block < 0,
                wallMs: performance.now() - started,
                validationMs,
            })
        }
    }
}
const median = (values) => {
    const sorted = [...values].sort((a, b) => a - b)
    return sorted.length === 0 ? null : (sorted[(sorted.length - 1) >> 1] + sorted[sorted.length >> 1]) / 2
}
const paired = []
for (let block = 0; block < protocol.measuredBlocks && execution !== 'verify'; block++) {
    const values = observations.filter((observation) => observation.block === block)
    const average = (arm, key) => values.filter((value) => value.arm === arm).reduce((sum, value) => sum + value[key], 0) / 2
    paired.push({
        block,
        validationPercent: (average('B', 'validationMs') / average('A', 'validationMs') - 1) * 100,
        wallPercent: (average('B', 'wallMs') / average('A', 'wallMs') - 1) * 100,
    })
}
const sourcePaths = ['ext/js/dictionary/term-record-opfs-store.js', 'ext/js/dictionary/term-bank-wasm-parser.js', 'ext/js/dictionary/term-bank-experiments.js', 'ext/lib/term-bank-parser.wasm']
const sourceHashes = {}
for (const [arm, root] of [['baseline', baselineRoot], ['candidate', candidateRoot]]) {
    sourceHashes[arm] = {}
    for (const relative of sourcePaths) {
        sourceHashes[arm][relative] = sha256(await readFile(path.join(root, relative)))
    }
}
const result = {
    kind: 'generic/fixed-format validation component screen; not complete import',
    format,
    syntheticStorageLayout: format !== 'arrays',
    parentRunnerSha256: 'd31c953a33e2c5be8f80b220a71eb003de7b5f84ca18fd7b2957b48e9b0647af',
    execution,
    protocol,
    node: process.version,
    host: {platform: os.platform(), architecture: os.arch(), cpus: os.cpus().map(({model}) => model), totalMemory: os.totalmem()},
    archive: {path: archivePath, bytes: archive.length, sha256: fixture.sha256, termRows: fixture.termRows},
    lockSha256: sha256(lockBytes),
    runnerSha256: sha256(await readFile(fileURLToPath(import.meta.url))),
    sourceHashes,
    armSources: {A: 'baseline', B: execution === 'control' ? 'baseline' : 'candidate'},
    descriptors: {nativeSha256: nativeDescriptorSha256, layoutSha256, chunks: chunks.map((chunk) => ({rows: chunk.rowCount, nativeUnique: chunk.nativeUniqueCount})), nativeCanonicalContentBytes: contentBase},
    oracle: baselineOracle,
    groupProfiles,
    observations,
    paired,
    summary: {
        medianValidationPercent: median(paired.map(({validationPercent}) => validationPercent)),
        medianWallPercent: median(paired.map(({wallPercent}) => wallPercent)),
        validationFasterBlocks: paired.filter(({validationPercent}) => validationPercent < 0).length,
        wallFasterBlocks: paired.filter(({wallPercent}) => wallPercent < 0).length,
    },
    limitations: [
        'Generic arrays project the real native canonical-content spans; fixed-length/fixed-span layouts are synthetic 32-byte storage shapes with real JMdict keys. No cross-group persisted dedup resolution or OPFS occurs.',
        'Seven-bank component groups follow existing import-lookup-screen convention, not the browser production planner.',
        'Actual field/index encoding is fully verified outside timing; timing uses constant encoder/append sinks.',
        'Two arm constructors share one Node process and host; neither browser scheduling nor peak memory is qualified.',
    ],
}
await writeFile(outputPath, JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify({output: outputPath, execution, rows: fixture.termRows, oracle: baselineOracle.sha256, descriptors: result.descriptors, summary: result.summary}))
