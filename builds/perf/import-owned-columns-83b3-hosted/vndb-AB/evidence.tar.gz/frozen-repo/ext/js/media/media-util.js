/*
 * Copyright (C) 2023-2026  Yomitan Authors
 * Copyright (C) 2020-2022  Yomichan Authors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * Gets the file extension of a file path. URL search queries and hash
 * fragments are not handled.
 * @param {string} path The path to the file.
 * @returns {string} The file extension, including the '.', or an empty string
 *   if there is no file extension.
 */
export function getFileNameExtension(path) {
    const match = /\.[^./\\]*$/.exec(path);
    return match !== null ? match[0] : '';
}

/**
 * Gets an image file's media type using a file path.
 * @param {string} path The path to the file.
 * @returns {?string} The media type string if it can be determined from the file path,
 *   otherwise `null`.
 */
export function getImageMediaTypeFromFileName(path) {
    // Canonical WebP paths need no temporary extension or case conversion.
    if (path.endsWith('.webp')) { return 'image/webp'; }

    // The longest supported image extension is ".pjpeg" (6 code units).
    // Avoid scanning the complete path or running the generic extension regex
    // for this import-hot classifier.
    const length = path.length;
    const minIndex = Math.max(0, length - 6);
    let extensionStart = -1;
    for (let i = length - 1; i >= minIndex; --i) {
        const code = path.charCodeAt(i);
        if (code === 0x2e) {
            extensionStart = i;
            break;
        }
        if (code === 0x2f || code === 0x5c) {
            break;
        }
    }
    if (extensionStart < 0) { return null; }

    switch (path.slice(extensionStart).toLowerCase()) {
        case '.apng':
            return 'image/apng';
        case '.avif':
            return 'image/avif';
        case '.bmp':
            return 'image/bmp';
        case '.gif':
            return 'image/gif';
        case '.ico':
        case '.cur':
            return 'image/x-icon';
        case '.jpg':
        case '.jpeg':
        case '.jfif':
        case '.pjpeg':
        case '.pjp':
            return 'image/jpeg';
        case '.png':
            return 'image/png';
        case '.svg':
            return 'image/svg+xml';
        case '.tif':
        case '.tiff':
            return 'image/tiff';
        case '.webp':
            return 'image/webp';
        default:
            return null;
    }
}

/**
 * Gets an audio file's media type using a file path.
 * @param {string} path The path to the file.
 * @returns {?string} The media type string if it can be determined from the file path,
 *   otherwise `null`.
 */
export function getAudioMediaTypeFromFileName(path) {
    switch (getFileNameExtension(path).toLowerCase()) {
        case '.aac':
            return 'audio/aac';
        case '.flac':
            return 'audio/flac';
        case '.m4a':
        case '.m4b':
        case '.mp4':
            return 'audio/mp4';
        case '.mp3':
            return 'audio/mpeg';
        case '.oga':
        case '.ogg':
        case '.opus':
            return 'audio/ogg';
        case '.wav':
            return 'audio/wav';
        case '.weba':
        case '.webm':
            return 'audio/webm';
        default:
            return null;
    }
}

/**
 * Gets a file's media type using a file path.
 * @param {string} path The path to the file.
 * @returns {string} The media type string.
 */
export function getMediaTypeFromFileName(path) {
    return (
        getImageMediaTypeFromFileName(path) ??
        getAudioMediaTypeFromFileName(path) ??
        'application/octet-stream'
    );
}

/**
 * Gets the file extension for a corresponding media type.
 * @param {string} mediaType The media type to use.
 * @returns {?string} A file extension including the dot for the media type,
 *   otherwise `null`.
 */
export function getFileExtensionFromImageMediaType(mediaType) {
    switch (mediaType) {
        case 'image/apng':
            return '.apng';
        case 'image/avif':
            return '.avif';
        case 'image/bmp':
            return '.bmp';
        case 'image/gif':
            return '.gif';
        case 'image/x-icon':
            return '.ico';
        case 'image/jpeg':
            return '.jpeg';
        case 'image/png':
            return '.png';
        case 'image/svg+xml':
            return '.svg';
        case 'image/tiff':
            return '.tiff';
        case 'image/webp':
            return '.webp';
        default:
            return null;
    }
}

/**
 * Gets the file extension for a corresponding media type.
 * @param {string} mediaType The media type to use.
 * @returns {?string} A file extension including the dot for the media type,
 *   otherwise `null`.
 */
export function getFileExtensionFromAudioMediaType(mediaType) {
    switch (mediaType.split(';', 1)[0].trim().toLowerCase()) {
        case 'audio/aac':
            return '.aac';
        case 'audio/mpeg':
        case 'audio/mp3':
            return '.mp3';
        case 'audio/mp4':
            return '.mp4';
        case 'audio/ogg':
        case 'audio/vorbis':
        case 'application/ogg':
            return '.ogg';
        case 'audio/vnd.wav':
        case 'audio/wave':
        case 'audio/wav':
        case 'audio/x-wav':
        case 'audio/x-pn-wav':
            return '.wav';
        case 'audio/flac':
            return '.flac';
        case 'audio/webm':
            return '.webm';
        default:
            return null;
    }
}
