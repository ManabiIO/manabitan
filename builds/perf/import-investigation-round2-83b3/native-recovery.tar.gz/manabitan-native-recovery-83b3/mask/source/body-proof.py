import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
def leb(data, at):
    value = 0; shift = 0
    while True:
        b = data[at]; at += 1
        value |= (b & 127) << shift
        if b < 128: return value, at
        shift += 7
        assert shift < 35
def string(data, at):
    n, at = leb(data, at)
    return data[at:at+n].decode(), at+n
def inspect(data):
    assert data[:8] == b'\0asm\x01\0\0\0'
    at=8; sections=[]; names={}; bodies=[]
    while at<len(data):
        kind=data[at]; at+=1; size,at=leb(data,at); payload=data[at:at+size]; at+=size
        if kind!=0: sections.append((kind,payload))
        if kind==2: assert payload==b'\0', 'Unexpected imported functions'
        if kind==10:
            count,p=leb(payload,0)
            for _ in range(count):
                n,p=leb(payload,p); bodies.append(payload[p:p+n]); p+=n
            assert p==len(payload)
        if kind==0:
            name,p=string(payload,0)
            if name=='name':
                while p<len(payload):
                    sub=payload[p];p+=1;n,p=leb(payload,p);end=p+n
                    if sub==1:
                        count,p=leb(payload,p)
                        for _ in range(count):
                            index,p=leb(payload,p);name,p=string(payload,p);names[index]=name
                    p=end
    return sections,names,bodies
arms={}
for arm in ['A','B32','D64']:
    release=(ROOT/(arm+'.wasm')).read_bytes();named=(ROOT/(arm+'-names.wasm')).read_bytes()
    sections,_,bodies=inspect(release)
    named_sections,names,named_bodies=inspect(named)
    assert sections==named_sections and bodies==named_bodies
    assert len(names)==len(bodies)
    arms[arm]={'sections':sections,'names':names,'bodies':bodies,'releaseSha256':sha(release),'namedSha256':sha(named)}
report={'complete':True,'variants':{}}
base=arms['A']
for arm in ['B32','D64']:
    value=arms[arm];assert value['names']==base['names']
    changed=[{'index':i,'name':value['names'][i],'baselineBytes':len(a),'candidateBytes':len(b),'baselineSha256':sha(a),'candidateSha256':sha(b)} for i,(a,b) in enumerate(zip(base['bodies'],value['bodies'])) if a!=b]
    other_sections=[{'id':a[0],'baselineSha256':sha(a[1]),'candidateSha256':sha(b[1])} for a,b in zip(base['sections'],value['sections']) if a[0]!=10 and a!=b]
    report['variants'][arm]={'releaseSha256':value['releaseSha256'],'namedSha256':value['namedSha256'],'functions':len(value['bodies']),'unchangedFunctions':len(value['bodies'])-len(changed),'changedFunctions':changed,'otherChangedSections':other_sections}
(ROOT/'body-proof.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
