import assert from 'node:assert/strict';
import {readFile, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const [out, ...paths]=process.argv.slice(2);
assert.equal(paths.length,3);
const moduleBytes=await Promise.all(paths.map(p=>readFile(p)));
const instances=await Promise.all(moduleBytes.map(async b=>(await WebAssembly.instantiate(b,{})).instance.exports));
const encoder=new TextEncoder();
const sha=b=>createHash('sha256').update(b).digest('hex');
const report={kind:'native-mask-grammar-differential',complete:false,modules:paths.map((p,i)=>({path:p,sha256:sha(moduleBytes[i])})),cases:0,accepted:0,rejected:0,physicalEnds:0,sourceMutationBetweenCalls:0};
const metadataWords=17;
function parse(wasm,bytes,alignment,limit=bytes.length,physicalEnd=false) {
 wasm.wasm_reset_heap();
 const outPtr=wasm.wasm_alloc(metadataWords*4*8);
 let ptr;
 if(physicalEnd) {
  ptr=wasm.memory.buffer.byteLength-bytes.length;
 } else {
  ptr=wasm.wasm_alloc(bytes.length+alignment+128)+alignment;
 }
 const heap=new Uint8Array(wasm.memory.buffer);
 if(!physicalEnd)heap.fill(34,ptr,ptr+bytes.length+128);
 heap.set(bytes,ptr);
 new Uint32Array(wasm.memory.buffer,outPtr,metadataWords*8).fill(0xdeadbeef);
 const count=wasm.parse_term_bank_with_media_hints(ptr,limit,outPtr,8,0,0,1);
 return {count,metas:count>=0?Array.from(new Uint32Array(wasm.memory.buffer,outPtr,count*metadataWords)):[]};
}
function check(bytes,alignment=0,limit=bytes.length,physicalEnd=false) {
 const expected=parse(instances[0],bytes,alignment,limit,physicalEnd);
 for(let i=1;i<instances.length;i++){
  assert.deepEqual(parse(instances[i],bytes,alignment,limit,physicalEnd),expected,JSON.stringify({case:report.cases,module:i,alignment,limit,physicalEnd,bytes:Buffer.from(bytes).toString('base64')}));
 }
 ++report.cases;
 if(expected.count>=0)++report.accepted;else++report.rejected;
 if(physicalEnd)++report.physicalEnds;
}
function source(glossary){return encoder.encode(JSON.stringify([['漢字','かんじ','tag','v1',-100,glossary,123,'term']]));}
const strings=['','a','日本語','é😀','"\\/\b\f\n\r\t','\\\\\\\\"','\\u0022','img','image'];
for(let pad=0;pad<128;pad++){
 const glossary=['x'.repeat(pad),{type:'text',text:strings[pad%strings.length]},{type:'structured-content',content:{tag:'span',content:[strings[(pad+3)%strings.length],'y'.repeat(129-pad),'img','image']}}];
 const bytes=source(glossary);
 for(const alignment of [0,1,3,7,15,16,31,32,47,63])check(bytes,alignment);
 for(let end=0;end<=bytes.length;end++)check(bytes,pad%64,end);
 check(bytes,0,bytes.length,true);
 for(const position of [bytes.indexOf(120),bytes.indexOf(121)]){
  if(position<0)continue;
  for(const control of [0,1,9,10,13,31,34,92,127,128,255]){
   const changed=bytes.slice();changed[position]=control;check(changed,pad%64);
  }
 }
}
for(const alignment of Array.from({length:64},(_,i)=>i)){
 const long='x'.repeat(96);
 for(const escape of ['\\q','\\u','\\u0','\\u00','\\u000','\\u00xz','\\','\\\\','\\"','\\/','\\n','\\u0022','\\\\\\"']){
  const text='[["x","","","",1,["'+long+escape+'","end"],2,""]]';
  check(encoder.encode(text),alignment);
 }
}
const first=source(['aaaaaaaa','bbbbbbbb',{type:'text',text:'ccc'}]);
const second=source(['cccccccc','dddddddd',{type:'text',text:'eee'}]);
assert.equal(first.length,second.length);
for(let i=0;i<64;i++){check(first,i);check(second,i);++report.sourceMutationBetweenCalls;}
report.complete=true;
await writeFile(out,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
process.stdout.write(JSON.stringify(report)+'\n');
