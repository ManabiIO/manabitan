import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/83b3b3bfba02/native-string-round2')
OUT = Path(__file__).resolve().parent
PREFIX = Path('/tmp/manabitan-81585d-toolchain/usr')
CLANG = PREFIX / 'lib/llvm-21/bin/clang'
LINKER = PREFIX / 'lib/llvm-21/bin/wasm-ld'
env = dict(os.environ)
env['LD_LIBRARY_PATH'] = str(PREFIX / 'lib/x86_64-linux-gnu') + ':' + str(PREFIX / 'lib/llvm-21/lib')
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest = json.loads((ROOT / 'dev/data/dictionary-wasm/manifest.json').read_text())
target = next(x for x in manifest['targets'] if x['name'] == 'term-bank-parser.wasm')
receipt = {'complete': False, 'versions': {}, 'binaries': {}, 'commands': [], 'modules': {}, 'failures': []}
def save():
    (OUT / 'build-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
save()
try:
    for label, binary in [('clang', CLANG), ('wasm-ld', LINKER)]:
        version = subprocess.check_output([str(binary), '--version'], env=env, text=True)
        assert '21.1.8' in version, version
        receipt['versions'][label] = version
        receipt['binaries'][label] = {'path': str(binary.resolve()), 'sha256': sha(binary.resolve().read_bytes())}
    for label, source in [('A', 'baseline-parser.c'), ('B32', 'parser-32.c'), ('D64', 'parser-64.c')]:
        for named in [False, True]:
            suffix = '-names' if named else ''
            args = [x for x in target['arguments'] if not (named and x == '-Wl,--strip-all')]
            module = OUT / (label + suffix + '.wasm')
            command = [str(CLANG), '-fuse-ld=' + str(LINKER), *args, '-o', str(module), str(OUT / source), str(ROOT / 'ext/js/dictionary/wasm/term-bank-inflate.c')]
            item = {'label': label, 'named': named, 'command': command, 'sourceSha256': sha((OUT / source).read_bytes()), 'startNs': time.monotonic_ns()}
            receipt['commands'].append(item); save()
            with (OUT / (label + suffix + '-build.log')).open('wb') as log:
                result = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=120)
            item['endNs'] = time.monotonic_ns(); item['exitCode'] = result.returncode
            save(); assert result.returncode == 0, label + suffix
            data = module.read_bytes()
            receipt['modules'][label + suffix] = {'path': str(module), 'bytes': len(data), 'sha256': sha(data)}
            if label == 'A' and not named:
                assert data == (ROOT / 'dev/data/dictionary-wasm/term-bank-parser.wasm').read_bytes()
                assert sha(data) == '8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee'
            save()
    assert (ROOT / 'ext/js/dictionary/wasm/term-bank-parser.c').read_bytes() == (OUT / 'parser-32.c').read_bytes()
    receipt['complete'] = True; save()
except BaseException as error:
    receipt['failures'].append({'type': type(error).__name__, 'message': str(error)})
    save(); raise
print(json.dumps(receipt, indent=2))
