// Copyright (C) 2026 Manabitan authors
// SPDX-License-Identifier: GPL-3.0-or-later
// Fresh-process native parser experiment. Never a whole-browser import claim.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createReadStream, openAsBlob} from 'node:fs';
import {mkdir, readFile, writeFile, statfs} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {performance} from 'node:perf_hooks';
import {execFileSync} from 'node:child_process';
import {BlobReader, ZipReader} from '@zip.js/zip.js';
const [rootArg, wasmArg, oracleArg, outputArg, arm] = process.argv.slice(2);
const root=path.resolve(rootArg);
const wasmPath=path.resolve(wasmArg);
const output=path.resolve(outputArg);
assert(['A','B32','C','D64'].includes(arm));
assert.equal(process.version,'v22.22.0');
assert(process.execArgv.includes('--max-old-space-size=192'));
const moduleHashes={A:'8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee',B32:'09fbb91f5d3b4da75a1c2e2e83335877e06d8d33f51a2f39046945c2a5d13b06',C:'8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee',D64:'0a71e99122663e33a8c0c45f43238fd432be5312dbb6ca61484b4853c2900e3f'};
const parserWorkers=3;
const sha256=bytes=>createHash('sha256').update(bytes).digest('hex');
const viewBytes=view=>new Uint8Array(view.buffer,view.byteOffset,view.byteLength);
const load=(sourceRoot,file)=>import(pathToFileURL(path.join(sourceRoot,file)).href);
const lockBytes=await readFile(path.join(root,'test/perf/dictionaries.lock.json'));
assert.equal(sha256(lockBytes),'60aa981791f3b60ca17588212aea5bd3536fb8f59288855e5accd019c6e4cf89');
const fixture=JSON.parse(lockBytes).dictionaries.jmdict;
const oracleBytes=await readFile(oracleArg);
assert.equal(sha256(oracleBytes),'b471985781ae3a6ee6e8b3363f71020ba221dbd7e049347cc7bc7408d22a1c11');
const reference=JSON.parse(oracleBytes).dictionaries.find(x=>x.dictionary==='jmdict');
assert(reference&&reference.groups.length===12&&reference.rows===528299);
const sourceFiles=[
 'ext/js/dictionary/term-bank-wasm-parser.js','ext/js/dictionary/term-bank-wasm-parser-worker.js',
 'ext/js/dictionary/term-bank-experiments.js','ext/js/dictionary/term-content-ownership.js',
 'ext/js/dictionary/term-record-preinterned-plan.js','ext/js/dictionary/term-lookup-index-preparation.js',
 'ext/js/dictionary/term-lookup-index.js','ext/js/dictionary/term-lookup-route.js',
 'ext/js/dictionary/dictionary-importer.js','ext/js/dictionary/dense-zip-directory.js',
 'ext/js/dictionary/term-bank-source-pipeline.js','ext/js/dictionary/term-key-hash.js',
 'ext/js/media/media-util.js','ext/lib/term-bank-parser.wasm',
 'ext/js/dictionary/wasm/term-bank-parser.c','ext/js/dictionary/wasm/term-bank-inflate.c',
 'dev/data/dictionary-wasm/manifest.json','dev/data/dictionary-wasm/term-bank-parser.wasm'
];
const sourceIdentity=async()=>Object.fromEntries(await Promise.all(sourceFiles.map(async file=>[file,sha256(await readFile(path.join(root,file)))])));
const {readDenseZipDirectory}=await load(root,'ext/js/dictionary/dense-zip-directory.js');
const {RawZipPayloadReader}=await load(root,'ext/js/dictionary/term-bank-source-pipeline.js');
const {getImageMediaTypeFromFileName}=await load(root,'ext/js/media/media-util.js');
const {hashTermKeyBytes}=await load(root,'ext/js/dictionary/term-key-hash.js');
const {registerOwnedTermContent}=await load(root,'ext/js/dictionary/term-content-ownership.js');

// BEGIN EXACT V3 HELPER FUNCTIONS
function partition(entries,groupsPerWorker){
    const total=entries.reduce((sum,entry)=>sum+entry.uncompressedSize,0);
    const groupCount=Math.min(entries.length,Math.max(parserWorkers*groupsPerWorker,Math.ceil(total/(24*1024*1024))));
    const groups=[];let start=0;let consumed=0;
    for(let index=0;index<groupCount-1;++index){
        const remaining=groupCount-index;const target=(total-consumed)/remaining;
        let end=start+1;let bytes=entries[start].uncompressedSize;const maxEnd=entries.length-(remaining-1);
        while(end<maxEnd){const nextBytes=bytes+entries[end].uncompressedSize;if(Math.abs(nextBytes-target)>Math.abs(bytes-target))break;bytes=nextBytes;++end;}
        groups.push(entries.slice(start,end));start=end;consumed+=bytes;
    }
    groups.push(entries.slice(start));return groups;
}
async function openTermBanks(archivePath){
    const archive=await openAsBlob(archivePath);let reader=null;
    const dense=await readDenseZipDirectory(archive);
    let entries=dense;
    if(entries===null){reader=new ZipReader(new BlobReader(archive),{useWebWorkers:false});entries=await reader.getEntries();}
    const hasArchiveImages=entries.some(entry=>!entry.directory&&getImageMediaTypeFromFileName(entry.filename)!==null);
    const banks=entries.filter(entry=>/^term_bank_\d+\.json$/.test(entry.filename)).sort((a,b)=>Number(a.filename.slice(10,-5))-Number(b.filename.slice(10,-5)));
    const payloads=new RawZipPayloadReader(archive);const signal=new AbortController().signal;
    return {entries:banks,hasArchiveImages,close:async()=>{if(reader)await reader.close();},read:async entry=>({
        bytes:await payloads.read(entry,signal),compressionMethod:entry.compressionMethod,
        compressedSize:entry.compressedSize,uncompressedSize:entry.uncompressedSize,
        signature:entry.signature,filename:entry.filename,
    })};
}
function updateView(digest,label,view){
    digest.update(label+':');
    if(!view){digest.update('absent;');return;}
    digest.update(String(view.byteLength)+':');digest.update(viewBytes(view));
}
function digestPlan(digest,plan){
    const offsets=plan.stringOffsets??new Uint32Array(plan.stringLengths.length);
    const hashes=plan.stringHashes??new Uint32Array(plan.stringLengths.length);
    if(!plan.stringOffsets||!plan.stringHashes){
        let offset=0;for(let key=0;key<plan.stringLengths.length;++key){const end=offset+plan.stringLengths[key];
            if(!plan.stringOffsets)offsets[key]=offset;if(!plan.stringHashes)hashes[key]=hashTermKeyBytes(plan.stringsBuffer.subarray(offset,end));offset=end;}
        assert.equal(offset,plan.stringsBuffer.byteLength);
    }
    for(const [label,view]of Object.entries({lengths:plan.stringLengths,offsets,hashes,strings:plan.stringsBuffer,
        expressions:Uint32Array.from(plan.expressionIndexes),readings:Uint32Array.from(plan.readingIndexes)}))updateView(digest,label,view);
}
function digestMedia(digest,rows){
    digest.update('media:'+rows.length+':');
    for(const entry of rows){digest.update(JSON.stringify({index:entry.index,imagePaths:entry.imagePaths??null}));
        for(const [key,value]of Object.entries(entry.row).sort(([a],[b])=>a.localeCompare(b))){
            if(ArrayBuffer.isView(value))updateView(digest,key,value);else digest.update(key+':'+JSON.stringify(value)+';');
        }
    }
}
function outputDigest(owned,includeContent){
    const digest=createHash('sha256');digestPlan(digest,owned.termRecordPreinternedPlan);
    for(const [key,entry]of owned.preparedLookupIndexes){digest.update(key);updateView(digest,'index',entry.bytes);updateView(digest,'route',entry.routeFilter);digestPlan(digest,entry.preinternedPlan);}
    for(const key of ['readingEqualsExpressionList','scoreList','sequenceList','contentHash1List','contentHash2List','contentMetaList','contentUniqueIndexList'])updateView(digest,key,owned[key]);
    for(const key of ['expressionBytesList','readingBytesList','contentBytesList']){
        digest.update(key+':'+owned[key].length+':');
        for(const [index,bytes]of owned[key].entries())updateView(digest,String(index),bytes);
    }
    digest.update('dedup:');
    if(owned.contentDedupPlan===null||typeof owned.contentDedupPlan==='undefined')digest.update(String(owned.contentDedupPlan));
    else for(const [key,value]of Object.entries(owned.contentDedupPlan).sort(([a],[b])=>a.localeCompare(b))){
        if(ArrayBuffer.isView(value))updateView(digest,key,value);else digest.update(key+':'+JSON.stringify(value)+';');
    }
    digest.update(JSON.stringify({contentMetaByUniqueIndex:owned.contentMetaByUniqueIndex===true,contentBytesBaseOffset:owned.contentBytesBaseOffset,contentBytesLength:owned.contentBytesLength,rowCount:owned.rowCount,contentRowStart:owned.contentRowStart,useResolvedContentReferences:owned.useResolvedContentReferences}));
    if(includeContent)updateView(digest,'content',owned.contentBytesBuffer);
    digestMedia(digest,owned.mediaRows);return digest.digest('hex');
}
function transferFootprint(chunk){
    const buffers=new Set();const addView=value=>{if(ArrayBuffer.isView(value)&&value.buffer instanceof ArrayBuffer&&value.buffer.byteLength>0)buffers.add(value.buffer);};
    for(const key of ['expressionBytesList','readingBytesList','contentBytesList'])for(const bytes of chunk[key])addView(bytes);
    for(const key of ['readingEqualsExpressionList','scoreList','sequenceList','contentHash1List','contentHash2List','contentBytesBuffer','contentMetaList','contentUniqueIndexList'])addView(chunk[key]);
    for(const {row}of chunk.mediaRows)for(const key of ['expressionBytes','readingBytes','glossaryJsonBytes','termEntryContentBytes'])addView(row[key]);
    const addPlan=plan=>{for(const key of ['stringLengths','stringOffsets','stringHashes','stringsBuffer','expressionIndexes','readingIndexes'])addView(plan?.[key]);};
    addPlan(chunk.termRecordPreinternedPlan);
    for(const prepared of chunk.preparedLookupIndexes.values()){addView(prepared.bytes);addView(prepared.routeFilter);addPlan(prepared.preinternedPlan);}
    for(const key of ['uniqueRowIndexes','uniqueSignatures','resolvedFlags','resolvedOffsets','resolvedLengths','pendingEpochs','pendingIndexes','pendingSpanOffsetsScratch','pendingSpanLengthsScratch'])addView(chunk.contentDedupPlan?.[key]);
    return {bufferCount:buffers.size,bytes:[...buffers].reduce((sum,b)=>sum+b.byteLength,0)};
}
// END EXACT V3 HELPER FUNCTIONS
async function replayGroup(source,compressed,policy){
    // Copies model the already-delivered owned compressed inputs and remain
    // outside the worker interval. Each arm receives the same bounded bytes.
    const sourceBuffers=compressed.map(entry=>Uint8Array.from(entry.bytes).buffer);
    const sourceMetadata=compressed.map(({bytes,...metadata})=>metadata);
    const options={copyContentBytes:false,includeContentMetadata:true,initialContentBytesPerRow:48,minimalDecode:true,
        reuseExpressionForReadingDecode:true,preallocateChunkRows:true,skipTagRuleDecode:policy.mediaHintFastScan,lazyGlossaryDecode:true,
        mediaHintFastScan:policy.mediaHintFastScan,projectImagePaths:policy.projectImagePaths,validateGlossaryTypes:true,
        computeContentHashes:true,emitContentSlab:true,emitTokenBinaryContent:true,emitTermByteLists:false,prepareLookupIndexes:true,
        prepareLookupRoute:policy.prepareLookupRoute,ownContentBytes:policy.ownContentBytes,
        experimentalNativeEscapedKeys:policy.ownContentBytes};
    const start=performance.now();
    const response=await source.send({type:'parse',id:0,version:3,sourceBuffers,sourceMetadata,chunkSize:8192,options});
    const elapsedMs=response.postReachedAt-start;
    const {chunk:owned,profile,borrowsWorkerMemory:borrowedContent}=response.message;
    assert.equal(response.message.ownsContentBytes,true,'JMdict must return an explicit owned content result');
    assert.equal(registerOwnedTermContent(owned.contentBytesBuffer),true,'Parent must accept the actual owned content receipt');
    assert(owned?.preparedLookupIndexes instanceof Map);
    const plan=owned.termRecordPreinternedPlan;
    const first=owned.preparedLookupIndexes.values().next().value;
    const wholeIndex=owned.preparedLookupIndexes.size===1&&first.preinternedPlan===plan;
    const potentialOwnedColumnBytes=wholeIndex?plan.stringsBuffer.byteLength+plan.stringLengths.byteLength+4*owned.rowCount:0;
    const reusedOwnedColumnBytes=wholeIndex&&plan.stringsBuffer.buffer===first.bytes.buffer&&plan.stringLengths.buffer===first.bytes.buffer&&plan.expressionIndexes.buffer===first.bytes.buffer?potentialOwnedColumnBytes:0;
    // Checksums and shape/ownership checks remain outside the worker interval.
    if(source.previous)assert.equal(outputDigest(source.previous.owned,!source.previous.borrowedContent),source.previous.digest,'Owned result changed after native heap reuse');
    const digest=outputDigest(owned,true);const stableDigest=outputDigest(owned,false);
    const transferred=transferFootprint(owned);
    assert.equal(transferred.bytes,response.transferBytes,'Transfer list must contain every expected owned result buffer');
    assert.equal(transferred.bufferCount,response.transferBuffers);
    let ownedContentBytes=0;
    if(owned.contentBytesBuffer?.buffer instanceof SharedArrayBuffer&&!borrowedContent)ownedContentBytes=owned.contentBytesBuffer.buffer.byteLength;
    for(const key of ['stringsBuffer','stringLengths','expressionIndexes','readingIndexes'])assert(plan[key].buffer instanceof ArrayBuffer,`Key column must own private bytes: ${key}`);
    source.previous={owned,borrowedContent,digest:borrowedContent?stableDigest:digest};
    return {rows:owned.rowCount,digest,stableDigest,wholeIndex,potentialOwnedColumnBytes,reusedOwnedColumnBytes,
        transferBuffers:transferred.bufferCount,transferBytes:transferred.bytes,ownedOutputBufferBytes:transferred.bytes+ownedContentBytes,
        contentMetaByUniqueIndex:owned.contentMetaByUniqueIndex===true,contentMetaBytes:owned.contentMetaList?.byteLength,
        borrowedContent,copyMs:profile.resultCopyMs,elapsedMs,adapterDeliveryMs:response.deliveryMs,processCpuMicros:response.processCpuMicros,profile,ownershipReceipt:true,
        inflationMs:profile.sourceInflateMs,sourceCrcMs:profile.sourceCrcMs??0,
        nativeSegments:profile.nativeSegmentedLookupSegments??0,nativeFallbacks:profile.nativeSegmentedLookupFallbacks??0,
        parseBankMs:profile.parseBankMs,lookupIndexPrepareMs:profile.lookupIndexPrepareMs??0,maxWasmHeapBytes:profile.maxWasmHeapBytes};
}

const report={schemaVersion:1,complete:false,arm,node:process.version,groups:[],failures:[],rows:0,
 boundary:'Sum of sequential actual compressed-source parser-worker handler intervals, from send invocation to postMessage before structuredClone. Includes native inflate/immediate CRC, parse/encode/intern, completed lookup preparation, owned result copy and transfer-list construction. Actual structured-clone transfer and parent owned-content receipt occur outside timer. Archive I/O, source copies, SHA oracles, module compilation, initialization, resource sampling, browser scheduling/IPC, canonical sink, downstream compression/storage and UI excluded.',
 cpuBoundary:'Process CPU counters captured at send entry and postMessage before transfer; includes the process and background compiler threads, not exclusively parser-thread CPU.',
 grouping:{parserWorkers:3,targetBytes:24*1024*1024,executionConcurrency:1},warmupCorpusPasses:0,firstGroupCold:true,
 sourceSha:'9e10d3b3fcf66d344ab31bc42c9b522fa5215da2',sourceHashes:await sourceIdentity(),
 activeModulePath:wasmPath,activeModuleSha256:sha256(await readFile(wasmPath)),
 runnerSha256:sha256(await readFile(fileURLToPath(import.meta.url))),oracleSha256:sha256(oracleBytes),
 resources:[]};
await mkdir(path.dirname(output),{recursive:true});await writeFile(output,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
const save=()=>writeFile(output,JSON.stringify(report,null,2)+'\n');
let reader;
try{
 assert.equal(report.activeModuleSha256,moduleHashes[arm],'Active module does not match frozen arm identity');
 assert.equal(report.sourceHashes['ext/lib/term-bank-parser.wasm'],moduleHashes.A,'Installed baseline artifact mismatch');
 assert.equal(report.sourceHashes['dev/data/dictionary-wasm/term-bank-parser.wasm'],moduleHashes.A,'Pinned baseline artifact mismatch');
 const sourceChange=execFileSync('git',['diff','--name-only','9e10d3b3fcf66d344ab31bc42c9b522fa5215da2','HEAD','--','ext','dev','test/perf/dictionaries.lock.json'],{cwd:root,encoding:'utf8'}).trim();
 assert.equal(sourceChange,'');
 assert.equal(execFileSync('git',['diff','--name-only','HEAD','--','ext','dev','test/perf/dictionaries.lock.json'],{cwd:root,encoding:'utf8'}).trim(),'');
 const resourceCheck=async label=>{
  const fsInfo=await statfs(path.dirname(output));const info={label,availableMemory:process.availableMemory(),diskReservePath:path.dirname(output),diskFreeBytes:fsInfo.bavail*fsInfo.bsize,memoryUsage:process.memoryUsage(),resourceUsage:process.resourceUsage()};
  report.resources.push(info);assert(info.availableMemory>=512*1024*1024,'Insufficient 512MiB available headroom');assert(info.diskFreeBytes>=256*1024*1024,'Insufficient 256MiB disk reserve');
 };
 await resourceCheck('before-initialize');
 const context={callback:null,pending:null,cpuStart:null};
 context.self={addEventListener(type,callback){if(type==='message')context.callback=callback;},postMessage(message,transfer=[]){
  const postReachedAt=performance.now();
  const processCpuMicros=context.cpuStart===null?null:process.cpuUsage(context.cpuStart);
  const transferBytes=transfer.reduce((sum,buffer)=>sum+buffer.byteLength,0);
  const received=structuredClone(message,{transfer});const deliveredAt=performance.now();
  const resolve=context.pending;context.pending=null;assert.equal(typeof resolve,'function');
  resolve({message:received,transferBytes,transferBuffers:transfer.length,postReachedAt,deliveryMs:deliveredAt-postReachedAt,processCpuMicros});
 }};
 globalThis.self=context.self;
 const startupStart=performance.now();
 await load(root,'ext/js/dictionary/term-bank-wasm-parser-worker.js');
 const send=async data=>{
  context.cpuStart=process.cpuUsage();assert.equal(context.pending,null);globalThis.self=context.self;
  let timer;
  const promise=new Promise((resolve,reject)=>{context.pending=resolve;timer=setTimeout(()=>{context.pending=null;reject(Error('Worker response timed out after 30s'));},30000);});
  try{context.callback({data});const result=await promise;const expected=data.type==='initialize'?'ready':'result';assert.equal(result.message.type,expected,JSON.stringify(result.message.error));return result;}
  finally{clearTimeout(timer);}
 };
 await send({type:'initialize',module:await WebAssembly.compile(await readFile(wasmPath))});
 report.startupMs=performance.now()-startupStart;
 const source={send,previous:null};
 const archivePath=path.join(root,'builds/e2e-dictionary-cache',fixture.cacheFile);
 const archiveDigest=createHash('sha256');let archiveBytes=0;
 for await(const bytes of createReadStream(archivePath)){archiveDigest.update(bytes);archiveBytes+=bytes.length;}
 assert.equal(archiveDigest.digest('hex'),fixture.sha256);assert.equal(archiveBytes,fixture.sizeBytes);
 report.archiveSha256=fixture.sha256;report.archiveBytes=archiveBytes;
 reader=await openTermBanks(archivePath);assert.equal(reader.entries.length,53);assert.equal(reader.hasArchiveImages,false);
 for(let i=0;i<reader.entries.length;i++)assert.equal(reader.entries[i].filename,'term_bank_'+(i+1)+'.json');
 const totalSourceBytes=reader.entries.reduce((sum,e)=>sum+e.uncompressedSize,0);
 assert.equal(totalSourceBytes,171617523);
 const policy={mediaHintFastScan:false,projectImagePaths:false,prepareLookupRoute:totalSourceBytes>=128*1024*1024,ownContentBytes:false};
 const groups=partition(reader.entries,4);assert.equal(groups.length,12);report.policy=policy;
 for(const [index,group]of groups.entries()){
  await resourceCheck('group-'+index);
  const compressed=[];for(const entry of group)compressed.push(await reader.read(entry));
  const observed=await replayGroup(source,compressed,policy);
  const expectedGroup=reference.groups[index];const expected=expectedGroup.observations[0].baseline;
  assert.equal(group[0].filename,expectedGroup.firstBank);assert.equal(group.at(-1).filename,expectedGroup.lastBank);
  assert.equal(group.reduce((sum,e)=>sum+e.uncompressedSize,0),expectedGroup.sourceBytes);
  for(const key of ['rows','digest','stableDigest','wholeIndex','potentialOwnedColumnBytes','reusedOwnedColumnBytes','transferBuffers','transferBytes','ownedOutputBufferBytes','contentMetaByUniqueIndex','contentMetaBytes','borrowedContent','nativeSegments','nativeFallbacks','maxWasmHeapBytes'])assert.equal(observed[key],expected[key],'Group '+index+' '+key);
  report.groups.push({index,firstBank:group[0].filename,lastBank:group.at(-1).filename,...observed});report.rows+=observed.rows;
  await save();
 }
 assert.equal(report.rows,528299);
 assert.deepEqual(await sourceIdentity(),report.sourceHashes,'Source changed during acquisition');
 assert.equal(execFileSync('git',['diff','--name-only','HEAD','--','ext','dev','test/perf/dictionaries.lock.json'],{cwd:root,encoding:'utf8'}).trim(),'','Tracked source changed during acquisition');
 report.totalWorkerMs=report.groups.reduce((s,g)=>s+g.elapsedMs,0);
 report.totalProcessCpuMicros=report.groups.reduce((s,g)=>s+g.processCpuMicros.user+g.processCpuMicros.system,0);
 report.finalResourceUsage=process.resourceUsage();report.complete=true;await save();
}catch(error){report.failures.push({name:error.name,message:error.message,stack:error.stack});await save();throw error;}
finally{if(reader)await reader.close();}
process.stdout.write(JSON.stringify({complete:report.complete,arm,rows:report.rows,totalWorkerMs:report.totalWorkerMs,totalProcessCpuMicros:report.totalProcessCpuMicros})+'\n');
