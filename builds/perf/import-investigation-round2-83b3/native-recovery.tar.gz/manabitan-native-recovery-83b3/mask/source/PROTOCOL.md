# Native string classification experiment — prospective protocol

Date: 2026-11-28. This is an exploratory component experiment. No performance
observations have been acquired when this protocol is frozen. It is not a
whole-browser import benchmark or a claim of an import improvement.

## Hypothesis and fixed candidates

Current native composite traversal repeatedly classifies overlapping bytes in
nearby JSON strings. Reusing a bounded block's quote/backslash/control mask across
strings within the same composite may reduce that work. All tokens still validate
their own escapes, terminators, control bytes and logical end.

The two candidates are fixed before acquisition:

- B32: one 32-byte mask per composite invocation.
- D64: one 64-byte mask per composite invocation.
- A: exact current baseline native module.
- C: the exact same baseline bytes and module path as A, used as a noise control.

The cache is stack local and valid only for the caller's immutable source arena.
It does not survive a parse invocation. Unsupported raw-ABI callers deliberately
aliasing mutable output metadata with source bytes are outside the existing arena
contract. The ordinary supported JS source and metadata allocations are separate.
Same-address source mutation between independent calls is covered by the
differential test.

Both candidates preserve source format, worker count, group policy, memory
budgets, storage policy, native lookup completion and result ownership. No further
candidate, block size, warmup strategy or cohort may be selected after results.

## Fixed source and artifacts

The production JS/C baseline is
9e10d3b3fcf66d344ab31bc42c9b522fa5215da2. Product code is read from the unchanged
base checkout. The candidate module is injected through the actual parser worker's
ordinary initialize message. All tracked ext/dev files must match the baseline;
source identities and dirty checks are repeated after each corpus pass.

The compiler and linker are the existing Clang/LLD 21.1.8 binaries, whose resolved
paths, complete command lines, binary SHA256 and output SHA256 are in
build-receipt.json. The rebuilt baseline exactly matches the checked-in artifact:

| Arm | SHA256 | Module bytes |
| --- | --- | ---: |
| A / C | 8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee | 67659 |
| B32 | 09fbb91f5d3b4da75a1c2e2e83335877e06d8d33f51a2f39046945c2a5d13b06 | 67877 |
| D64 | 0a71e99122663e33a8c0c45f43238fd432be5312dbb6ca61484b4853c2900e3f | 67961 |

The named and release modules have identical noncustom sections. The body proof
records 48 of 51 function bodies unchanged. The composite scanner changes; two
other functions with inlined scalar escape/type handling are reordered and each
grows by one byte. Textual assembly confirms those two callers contain no vector
instructions in either baseline or B32. Do not describe this as every
non-composite instruction being identical.

The frozen manifest hashes the exact candidate sources, runner, controller,
protocol, module-build receipt, differential test/results, body proof and oracle.
It also identifies the Node executable bytes. Controller and child both reject
an arm/module mismatch. A and C use the same A.wasm file.

## Correctness before the screen

The 45,046-case focused actual-WASM differential run passed for both candidates
before this protocol: identical acceptance and all 17 row metadata words,
including every-byte truncation, string/control/escape/UTF-8 cases, misalignment,
128 physical memory-end cases and 64 same-address mutation pairs.

Before measured acquisition, run one correctness-only complete corpus pass for
A, B32 and D64, in that fixed order, in fresh processes. These passes retain
ordinary native timing counters for audit but are not performance observations,
are not pooled into the screen, and cannot guide candidate or protocol changes.

The exact pinned JMdict fixture is
3a614c92cfa747946de8422fc408d6d93926ba76541df66e434b24976a10160f
(15,645,766 archive bytes). The lock file SHA256 is
60aa981791f3b60ca17588212aea5bd3536fb8f59288855e5accd019c6e4cf89.
The corpus is 53 banks, 528,299 rows and 171,617,523 uncompressed source bytes,
partitioned into the current policy-3 12 groups for three parser workers.

Every group must equal the frozen existing baseline output oracle. The oracle's
SHA256 is b471985781ae3a6ee6e8b3363f71020ba221dbd7e049347cc7bc7408d22a1c11,
recovered from Git blob 9fd473e3c9dc4d508e5f774537fec88c64188cd0 at
f65f4ef97ebf2f37a5b1b79ca7733d7b362ec963. The exact earlier replay source
is also retained, SHA256
cee15f1242da2c2a5e73f030f6bf2a5f4a54f292a723319a3924105c6f10eaaf.

Equality includes all earlier complete-output and stable-output digests, row
counts, completed lookup indexes/routes and preinterned plan, content slab/meta
and hash/index columns, media rows, dedup plan, transfer buffers/bytes, owned
output bytes, heap maximum, native fallback/segment counts and group boundaries.
The adapter performs structuredClone with the worker's actual transfer list.
The actual parent owned-content receipt is checked outside timing. Every result
must remain stable after the next group reuses native memory.

## What the interval measures

Each observation is one fresh Node 22.22.0 process loading the actual current
parser-worker handler and running all 12 compressed groups sequentially, with
execution concurrency one. Group partition policy remains the production
three-worker policy. The first group is cold; there are no corpus warmups.

Primary metric: sum of the actual worker-handler intervals, starting immediately
before send and ending at the handler's postMessage entry before structuredClone.
This includes native inflate and immediate CRC, grammar validation,
parse/encode/intern, completed native lookup preparation, owned result copying
and transfer-list construction.

Excluded: archive I/O, adapter source-buffer copies, module compilation and
initialization, result transfer/delivery, parent owned-content registration,
SHA/oracle validation, resource sampling, browser scheduling/IPC, canonical sink,
downstream compression/storage and UI. This is deliberately not a full import.

CPU counters are process CPU from send entry to postMessage entry. They may
include background compiler activity and are not labeled exclusively parser CPU.
Per-stage profile counters are retained only as diagnostics, not alternative
selection metrics.

## Fixed cohort and decision

Exactly 12 four-arm rounds, 48 fresh measured child processes, using these orders
repeated three times:

1. A, B32, D64, C
2. B32, C, A, D64
3. C, D64, B32, A
4. D64, A, C, B32

No warmup corpus, profiler, optional extra rounds, replacement runs or retuning.
Every raw result and failure is retained. Stop on failed correctness, resource
gate, identity, timeout or process exit; do not silently replace an observation.

For a candidate to proceed to a separately defined browser qualification, all
of these exploratory gates must pass:

- Its median paired time ratio against A is at most 0.95.
- Its median paired time ratio against C is at most 0.95.
- It is faster than A in at least 10 of 12 paired rounds.
- It is faster than C in at least 10 of 12 paired rounds.
- The absolute median paired C/A ratio deviation from 1 is at most 0.03.

Report both fixed candidates regardless of outcome. This is a filtering decision,
not a confidence interval or proof of whole-import improvement. A passing
component result does not authorize a product PR without real-browser import
validation and appropriate Jitendex/VNDB regression coverage.

## Resource and failure discipline

Root serializes heavy work; no build, test suite, profiler or competing benchmark
from this team may run during acquisition. Other session interference may still
exist, so the controller retains machine/CPU/process snapshots and per-child
RSS/CPU samples. Do not discard a slow but valid observation.

Inputs and fixtures remain read-only in existing checkouts. Write all acquisition
results under /tmp/manabitan-native-string-screen-83b3, whose filesystem must
retain at least 256 MiB free. This target was chosen prospectively before any
corpus replay because the workspace filesystem is constrained and shared.

Every child uses --max-old-space-size=192. The child checks at least 512 MiB
available memory headroom before initialization and before every group.
The controller samples child RSS/CPU every 250 ms and stops if observed RSS
exceeds 400 MiB, or after 120 seconds. Resource sampling is outside handler
intervals. Process resourceUsage is retained too, because sampled RSS can miss a
peak. There is no claim that these checks isolate all host contention.

All partial JSON, stdout/stderr and failure receipts remain. The prior unrelated
normalized-glossary census exited 137 and produced no complete result; its partial
normalized counts are not output parity, raw-byte identity, or performance
evidence for this candidate.

