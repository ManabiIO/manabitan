import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import signal
import statistics
import subprocess
import time

HERE = Path(__file__).resolve().parent
BASE = Path('/workspace/scratch/83b3b3bfba02/manabitan')
NODE = Path('/workspace/scratch/83b3b3bfba02/node-v22.22.0-linux-x64/bin/node')
OUTPUT = Path('/tmp/manabitan-native-string-screen-83b3')
SOURCE_SHA = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
ARM_HASHES = {
    'A': '8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee',
    'B32': '09fbb91f5d3b4da75a1c2e2e83335877e06d8d33f51a2f39046945c2a5d13b06',
    'C': '8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee',
    'D64': '0a71e99122663e33a8c0c45f43238fd432be5312dbb6ca61484b4853c2900e3f',
}
ORDERS = [['A','B32','D64','C'], ['B32','C','A','D64'],
          ['C','D64','B32','A'], ['D64','A','C','B32']] * 3
sha = lambda b: hashlib.sha256(b).hexdigest()

def module(arm):
    return HERE / (('A' if arm == 'C' else arm) + '.wasm')

def write_json(file, value):
    file.write_text(json.dumps(value, indent=2) + '\n')

def read_optional(file):
    try: return Path(file).read_text()
    except OSError as error: return 'unavailable: ' + str(error)

def identity():
    inputs = ['worker-replay.mjs','differential.mjs','differential-result-v1.json',
              'build.py','build-receipt.json','body-proof.py','body-proof.json',
              'A-assembly-scope.json','B32-assembly-scope.json',
              'baseline-parser.c','parser-32.c','parser-64.c','policy-3-oracle.json',
              'original-owned-column-replay.mjs','screen-controller.py','PROTOCOL.md']
    return {f: {'sha256': sha((HERE/f).read_bytes()), 'bytes': (HERE/f).stat().st_size}
            for f in inputs}

def machine():
    return {
        'platform': platform.platform(), 'python': platform.python_version(),
        'cpuCount': os.cpu_count(), 'cpuInfo': read_optional('/proc/cpuinfo'),
        'memInfo': read_optional('/proc/meminfo'), 'selfCgroup': read_optional('/proc/self/cgroup'),
        'procStat': read_optional('/proc/stat'), 'uptime': read_optional('/proc/uptime'),
        'sourceHead': subprocess.check_output(['git','rev-parse','HEAD'],cwd=BASE,text=True).strip(),
        'sourceExtTree': subprocess.check_output(['git','rev-parse',SOURCE_SHA+':ext'],cwd=BASE,text=True).strip(),
        'sourceDevTree': subprocess.check_output(['git','rev-parse',SOURCE_SHA+':dev'],cwd=BASE,text=True).strip(),
        'nodeSha256': sha(NODE.read_bytes()),
        'processCensus': subprocess.check_output(['ps','-eo','pid,ppid,pcpu,pmem,rss,comm'],text=True),
        'diskFreeBytes': shutil.disk_usage(OUTPUT).free,
    }

def child_stats(pid):
    try:
        value = Path('/proc/'+str(pid)+'/stat').read_text()
        fields = value[value.rindex(')')+2:].split()
        return {'monotonicNs': time.monotonic_ns(),
                'rssBytes': int(fields[21])*os.sysconf('SC_PAGE_SIZE'),
                'userTicks': int(fields[11]), 'systemTicks': int(fields[12]),
                'state': fields[0]}
    except FileNotFoundError:
        return None

def freeze():
    OUTPUT.mkdir(parents=True,exist_ok=True)
    receipt=json.loads((HERE/'build-receipt.json').read_text())
    assert receipt['complete'] and receipt['failures']==[]
    for arm, digest in ARM_HASHES.items():
        assert sha(module(arm).read_bytes()) == digest
        name = 'A' if arm == 'C' else arm
        assert receipt['modules'][name]['sha256']==digest
    protocol={
        'schemaVersion': 1, 'frozenBeforeExecutionAtUnixNs': time.time_ns(),
        'sourceSha': SOURCE_SHA, 'arms': ARM_HASHES, 'orders': ORDERS,
        'inputs': identity(), 'node': {'path': str(NODE),'sha256': sha(NODE.read_bytes()),'version':'v22.22.0'},
        'outputDirectory': str(OUTPUT), 'minimumFreeOutputBytes':256*1024*1024,
        'minimumAvailableChildMemoryBytes':512*1024*1024,
        'maximumSampledChildRssBytes':400*1024*1024,
        'maximumChildSeconds':120,'sampleIntervalSeconds':0.25,
        'screenGate': {
            'pairedMedianSpeedupAgainstEachControlPercent': 5,
            'fasterRoundsAgainstEachControl':10,'rounds':12,
            'maximumAbsoluteMedianControlRatioDeviationPercent':3,
            'interpretation':'Exploratory component screen only; no browser or end-to-end import claim.'
        },
        'correctnessBeforeScreen': ['A','B32','D64'],
        'replacementRunsAllowed':False, 'extraRoundsAllowed':False,
    }
    with (OUTPUT/'frozen-protocol.json').open('x') as f:
        json.dump(protocol,f,indent=2);f.write('\n')
    print(json.dumps({'frozen':True,'path':str(OUTPUT/'frozen-protocol.json'),
                      'sha256':sha((OUTPUT/'frozen-protocol.json').read_bytes())}),flush=True)

def run(mode):
    frozen=OUTPUT/'frozen-protocol.json'
    protocol=json.loads(frozen.read_text())
    assert protocol['inputs']==identity(), 'Experiment inputs changed after freeze'
    assert sha(NODE.read_bytes())==protocol['node']['sha256'], 'Node executable changed after freeze'
    for arm,digest in ARM_HASHES.items():
        assert sha(module(arm).read_bytes())==digest
    directory=OUTPUT/mode
    directory.mkdir(exist_ok=False)
    report={'schemaVersion':1,'mode':mode,'complete':False,'failures':[],
            'frozenProtocolSha256':sha(frozen.read_bytes()),'start':machine(),'children':[]}
    report_file=directory/'acquisition.json'
    write_json(report_file,report)
    child=None
    try:
        if mode=='screen':
            parity=json.loads((OUTPUT/'parity/acquisition.json').read_text())
            assert parity['complete'] and parity['failures']==[]
            assert parity['frozenProtocolSha256']==report['frozenProtocolSha256']
            assert [x['arm'] for x in parity['children']]==['A','B32','D64']
        schedule=[(None,arm) for arm in ['A','B32','D64']] if mode=='parity' else [
            (r,arm) for r,order in enumerate(ORDERS,1) for arm in order]
        for number,(round_number,arm) in enumerate(schedule,1):
            assert shutil.disk_usage(OUTPUT).free>=protocol['minimumFreeOutputBytes']
            stem=f'{number:02d}-{arm}'
            result_file=directory/(stem+'.json')
            stdout=directory/(stem+'.log')
            command=[str(NODE),'--max-old-space-size=192',str(HERE/'worker-replay.mjs'),
                     str(BASE),str(module(arm)),str(HERE/'policy-3-oracle.json'),str(result_file),arm]
            item={'number':number,'round':round_number,'arm':arm,'command':command,
                  'startUnixNs':time.time_ns(),'samples':[]}
            report['children'].append(item);write_json(report_file,report)
            start=time.monotonic()
            with stdout.open('xb') as log:
                child=subprocess.Popen(command,cwd=BASE,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                item['pid']=child.pid
                while True:
                    sample=child_stats(child.pid)
                    if sample is not None:
                        item['samples'].append(sample)
                        if sample['rssBytes']>protocol['maximumSampledChildRssBytes']:
                            item['failure']='Sampled child RSS limit exceeded'
                            os.killpg(child.pid,signal.SIGTERM)
                            break
                    code=child.poll()
                    if code is not None: break
                    if time.monotonic()-start>protocol['maximumChildSeconds']:
                        item['failure']='Child time limit exceeded'
                        os.killpg(child.pid,signal.SIGTERM)
                        break
                    time.sleep(protocol['sampleIntervalSeconds'])
                try: code=child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid,signal.SIGKILL);code=child.wait()
                child=None
            item.update({'exitCode':code,'elapsedProcessSeconds':time.monotonic()-start,
                         'endUnixNs':time.time_ns(),'stdoutSha256':sha(stdout.read_bytes())})
            if result_file.exists():
                result=json.loads(result_file.read_text());item['resultSha256']=sha(result_file.read_bytes())
                item['resultComplete']=result['complete']
                item['resultFailures']=result['failures']
                item['observedRows']=result['rows']
                if mode=='screen':
                    item['totalWorkerMs']=result.get('totalWorkerMs')
                    item['totalProcessCpuMicros']=result.get('totalProcessCpuMicros')
            write_json(report_file,report)
            assert code==0 and 'failure' not in item, stem+' failed; no replacement run allowed'
            assert item['resultComplete'] and item['resultFailures']==[] and item['observedRows']==528299
            assert sha(result_file.read_bytes())==item['resultSha256']
            progress={'mode':mode,'finished':number,'total':len(schedule),'arm':arm,'complete':True}
            if mode=='screen': progress['totalWorkerMs']=item['totalWorkerMs']
            print(json.dumps(progress),flush=True)
        assert protocol['inputs']==identity(), 'Experiment inputs changed during acquisition'
        report['end']=machine();report['complete']=True
        if mode=='screen':
            rows={r:{x['arm']:x for x in report['children'] if x['round']==r} for r in range(1,13)}
            control_ratios=[rows[r]['C']['totalWorkerMs']/rows[r]['A']['totalWorkerMs'] for r in rows]
            control_median=statistics.median(control_ratios)
            summary={'controlMedianRatioCOverA':control_median,'controlGate':abs(control_median-1)<=0.03,'candidates':{}}
            for candidate in ['B32','D64']:
                item={}
                for control in ['A','C']:
                    ratios=[rows[r][candidate]['totalWorkerMs']/rows[r][control]['totalWorkerMs'] for r in rows]
                    item[control]={'pairedRatios':ratios,'medianRatio':statistics.median(ratios),
                                   'medianSpeedupPercent':(1-statistics.median(ratios))*100,
                                   'fasterRounds':sum(ratio<1 for ratio in ratios)}
                item['passesExploratoryScreen']=summary['controlGate'] and all(item[c]['medianRatio']<=0.95 and item[c]['fasterRounds']>=10 for c in ['A','C'])
                summary['candidates'][candidate]=item
            report['summary']=summary
            write_json(directory/'summary.json',summary)
        write_json(report_file,report)
        print(json.dumps({'mode':mode,'complete':True,'children':len(report['children']),
                          **({'summary':report['summary']} if mode=='screen' else {})}),flush=True)
    except BaseException as error:
        if child is not None:
            try:
                os.killpg(child.pid,signal.SIGTERM)
                try: child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid,signal.SIGKILL);child.wait()
            except ProcessLookupError:
                child.wait()
        report['failures'].append({'type':type(error).__name__,'message':str(error),'timeUnixNs':time.time_ns()})
        report['end']=machine();write_json(report_file,report)
        raise

parser=argparse.ArgumentParser()
parser.add_argument('mode',choices=['freeze','parity','screen'])
args=parser.parse_args()
if args.mode=='freeze': freeze()
else: run(args.mode)

