# Native shared string-mask experiment

The fixed exploratory screen did not qualify either candidate for browser
promotion. The 64-byte candidate has a favorable component signal, but it is
inconclusive under the prospectively frozen consistency and identical-control
gates. No native mask PR or extra screen rounds were opened.

| Candidate | Median paired change vs A | Faster than A | Median paired change vs identical C | Faster than C | Fixed gate |
| --- | ---: | ---: | ---: | ---: | --- |
| 32-byte cache | +3.061% | 5/12 | -7.024% | 8/12 | Does not pass |
| 64-byte cache | -7.380% | 9/12 | -13.692% | 10/12 | Does not pass |

The identical C/A median ratio was 1.034992891 (+3.499%), above the fixed 3%
control-drift limit. A qualifying candidate also needed at least 5% median gain
and at least 10/12 faster rounds against each control. These gates were not
changed after observing results. The table contains paired within-round ratios;
ratios of separate arm medians are a different statistic.

All 48 measured fresh-process corpus passes completed with exact output oracle,
completed lookup, actual transfer, ownership, resource and identity checks. Each
pass processed 528,299 JMdict rows across all 53 banks and 12 current policy-3
groups. Three earlier correctness-only passes (A/B32/D64) also passed. The focused
native differential passed 45,046 cases for both candidates, comparing acceptance
and all 17 row metadata words, including physical ends and same-address rewrites.

The interval sums sequential actual compressed-source parser-worker handlers,
through owned result copying and completed lookup construction. It excludes
browser scheduling, the canonical sink, downstream compression/storage and UI.
It is not a whole-import measurement. The corpus pass is cold in each fresh Node
22.22.0 child. All observations are retained, including the broad baseline range:
A 790.76–1339.73 ms; identical C 917.95–1434.58 ms.

The 48-child cohort took 103.84 seconds. Highest sampled child RSS was 237.91 MiB;
highest child resourceUsage maxRSS was 246.13 MiB. All output stayed on the /tmp
filesystem, with the unchanged 256 MiB reserve. There were no replacement runs,
timeouts, process failures or resource aborts in this acquisition.

The change caches quote/backslash/control classification across nearby strings in
one composite scan, with bounded 32/64-byte SIMD blocks. Escape and delimiter
grammar remain checked per token. Rebuilt baseline bytes exactly match the pinned
Clang/LLD 21.1.8 artifact. Candidate release sizes are +218 B / +302 B. The full
build receipt and function-body proof identify the precise source/compiler/module
scope; two scalar callers are reordered, so this is not claimed to change only
one function's instructions.

Frozen protocol SHA256:
49682f093c26ea1d93eb9706a8e0186b0ed3e9378594a0948681a54ec354d530

Audit files in this directory: frozen-protocol.json; parity/acquisition.json;
screen/acquisition.json; screen/summary.json; all 51 complete child JSON results
and stdout/stderr logs. Exact hashed sources, runner, controller, differential
test and build receipts are in the existing isolated native-string-round2 tree
under builds/perf/round2-native-83b3. No source or frozen input was modified during
acquisition.
