import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const root='/tmp/manabitan-provenance-census-83b3';
const bytes=await readFile(root+'/census.wasm');
const wasm=(await WebAssembly.instantiate(bytes,{})).instance.exports;
const report={complete:false,moduleSha256:createHash('sha256').update(bytes).digest('hex'),cases:[]};
function run(name,{spans=[[10,20],[50,20]],flags=[0,0],runs=[[45,40,30]],base=0,bankLength=200,sourceLength=200,eligible=1,incremental=1,overlap=0,merged=1,status=1,eligibleBytes=20}={}){
 wasm.wasm_reset_heap();
 const rowsPtr=wasm.wasm_alloc(spans.length*17*4);
 const flagsPtr=wasm.wasm_alloc(flags.length);
 const runsPtr=wasm.wasm_alloc(runs.length*3*4);
 const metas=new Uint32Array(wasm.memory.buffer,rowsPtr,spans.length*17);
 for(const [i,[start,length]] of spans.entries()){metas[i*17+9]=start;metas[i*17+10]=length;}
 new Uint8Array(wasm.memory.buffer,flagsPtr,flags.length).set(flags);
 new Uint32Array(wasm.memory.buffer,runsPtr,runs.length*3).set(runs.flat());
 assert.equal(wasm.provenance_test(rowsPtr,spans.length,flagsPtr,runsPtr,runs.length,base,bankLength,sourceLength),status,name+' status');
 const counters=Array.from(new Uint32Array(wasm.memory.buffer,wasm.provenance_stats_ptr(),64));
 if(status){assert.equal(counters[14],eligible,name+' eligible');assert.equal(counters[15],eligibleBytes,name+' eligible bytes');assert.equal(counters[16],incremental,name+' incremental');assert.equal(counters[18],overlap,name+' overlap');assert.equal(counters[9],merged,name+' merged');}
 report.cases.push({name,status,counters});
}
run('one enclosing history copy');
run('already-reused glossary',{flags:[0,1],incremental:0,overlap:1});
run('merge contiguous equal distance',{runs:[[45,40,15],[60,40,15]]});
run('different distance breaks coverage',{runs:[[45,40,15],[60,41,15]],eligible:0,eligibleBytes:0,incremental:0,merged:2});
run('literal gap breaks coverage',{runs:[[45,40,15],[61,40,14]],eligible:0,eligibleBytes:0,incremental:0,merged:2});
run('prior length differs',{spans:[[10,19],[50,20]],eligible:0,eligibleBytes:0,incremental:0});
run('translated start must be exact',{runs:[[45,39,30]],eligible:0,eligibleBytes:0,incremental:0});
run('exact half-open end boundary',{runs:[[50,40,20]]});
run('missing final byte rejects',{runs:[[50,40,19]],eligible:0,eligibleBytes:0,incremental:0});
run('overlapping prior span rejects',{spans:[[10,60],[50,60]],runs:[[50,40,60]],eligible:0,eligibleBytes:0,incremental:0});
run('nonzero bank base',{spans:[[1010,20],[1050,20]],base:1000,sourceLength:1200});
run('cross-bank distance invalid',{runs:[[45,1040,30]],status:0});
run('long same-distance merge',{spans:[[10,300],[410,300]],runs:[[400,400,258],[658,400,100]],bankLength:1000,sourceLength:1000,eligibleBytes:300});
run('whole range but no earlier row',{spans:[[50,20]],flags:[0],eligible:0,eligibleBytes:0,incremental:0});
report.complete=true;
await writeFile(root+'/range-tests.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});
process.stdout.write(JSON.stringify({complete:true,cases:report.cases.length})+'\n');

