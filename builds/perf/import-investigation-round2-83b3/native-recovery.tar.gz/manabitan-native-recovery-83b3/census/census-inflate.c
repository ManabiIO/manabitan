/*
 * Untimed research instrumentation for exact DEFLATE-copy provenance.
 * Copyright (C) 2026 Manabitan authors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
#include <stdint.h>
#include <stddef.h>

#define CENSUS_MAX_ROWS 65536u
#define CENSUS_MAX_BANKS 16u
#define CENSUS_MAX_SOURCE_BYTES (64u * 1024u * 1024u)
#define CENSUS_MAX_SCRATCH_BYTES (16u * 1024u * 1024u)
#define CENSUS_WORDS 64u
#define ROW_WORDS 17u
#define GLOSSARY_START 9u
#define GLOSSARY_LENGTH 10u

static uint32_t census_stats[CENSUS_WORDS];
static uint8_t baseline_reused[CENSUS_MAX_ROWS];
static const uint32_t* census_rows;
static uint32_t census_row_count;
static uint32_t census_row_cursor;
static uint32_t census_bank_base;
static uint32_t census_bank_length;
static uint32_t census_source_length;
static const uint8_t* verified_source;
static uint32_t run_start, run_end, run_distance;
static int run_present;
static int census_active;

static struct {
    uint32_t input, input_length, offsets, compressed_lengths, uncompressed_lengths;
    uint32_t methods, count, output, bank_spans;
} sources;

static void provenance_note_match(uint32_t start, uint32_t distance, uint32_t length);
#define MANABITAN_PROVENANCE_MATCH(start, distance, length) \
    provenance_note_match((uint32_t)(start), (uint32_t)(distance), (uint32_t)(length))
#define FREESTANDING
#include "vendor/libdeflate/lib/deflate_decompress.c"

extern uint32_t wasm_alloc(uint32_t size);
static struct libdeflate_decompressor term_bank_decompressor;

int32_t term_bank_inflate(
    const uint8_t* input, uint32_t input_length,
    uint8_t* output, uint32_t output_length
) {
    size_t consumed = 0, produced = 0;
    const enum libdeflate_result result = libdeflate_deflate_decompress_ex(
        &term_bank_decompressor, input, input_length, output, output_length,
        &consumed, &produced);
    if (result != LIBDEFLATE_SUCCESS) { return -2; }
    if (produced != output_length) { return -3; }
    if (consumed != input_length) { return -6; }
    return 0;
}

void provenance_capture_inputs(
    uint32_t input, uint32_t input_length, uint32_t offsets,
    uint32_t compressed_lengths, uint32_t uncompressed_lengths, uint32_t methods,
    uint32_t count, uint32_t output, uint32_t bank_spans
) {
    sources.input = input; sources.input_length = input_length;
    sources.offsets = offsets; sources.compressed_lengths = compressed_lengths;
    sources.uncompressed_lengths = uncompressed_lengths; sources.methods = methods;
    sources.count = count; sources.output = output; sources.bank_spans = bank_spans;
}

void provenance_begin_rows(void) {
    __builtin_memset(census_stats, 0, sizeof(census_stats));
    __builtin_memset(baseline_reused, 0, sizeof(baseline_reused));
    census_active = 0; run_present = 0;
    verified_source = 0;
}

void provenance_note_row(uint32_t row, uint32_t reused) {
    if (row >= CENSUS_MAX_ROWS) { census_stats[1] = 1u; return; }
    baseline_reused[row] = reused != 0u;
}

static int prepare_rows(uint32_t rows_ptr, uint32_t count, uint32_t source_length) {
    if (count > CENSUS_MAX_ROWS || source_length > CENSUS_MAX_SOURCE_BYTES) {
        census_stats[1] = 2u; return 0;
    }
    census_rows = (const uint32_t*)(uintptr_t)rows_ptr;
    census_row_count = count; census_row_cursor = 0u;
    census_source_length = source_length;
    census_stats[3] = count; census_stats[23] = source_length;
    uint32_t previous = 0u;
    for (uint32_t i = 0u; i < count; ++i) {
        const uint32_t start = census_rows[i * ROW_WORDS + GLOSSARY_START];
        const uint32_t length = census_rows[i * ROW_WORDS + GLOSSARY_LENGTH];
        if (length == 0u || start >= source_length || length > source_length - start ||
            (i != 0u && start <= previous)) { census_stats[1] = 3u; return 0; }
        previous = start;
        census_stats[4] += length;
        if (baseline_reused[i]) {
            ++census_stats[5]; census_stats[6] += length;
        }
    }
    return 1;
}

static uint32_t length_bucket(uint32_t length) {
    if (length < 64u) { return 0u; }
    if (length < 128u) { return 1u; }
    if (length < 256u) { return 2u; }
    if (length < 512u) { return 3u; }
    if (length < 1024u) { return 4u; }
    if (length < 2048u) { return 5u; }
    if (length < 4096u) { return 6u; }
    return 7u;
}

static uint32_t lookback_bucket(uint32_t rows) {
    if (rows == 1u) { return 0u; }
    if (rows <= 4u) { return 1u; }
    if (rows <= 16u) { return 2u; }
    if (rows <= 64u) { return 3u; }
    return 4u;
}

static void finish_run(void) {
    if (!run_present) { return; }
    ++census_stats[9];
    census_stats[10] += run_end - run_start;
    if (run_end - run_start > census_stats[11]) { census_stats[11] = run_end - run_start; }
    const uint32_t begin = census_bank_base + run_start;
    const uint32_t end = census_bank_base + run_end;
    int eligible_run = 0;
    while (census_row_cursor < census_row_count) {
        const uint32_t row = census_row_cursor;
        const uint32_t start = census_rows[row * ROW_WORDS + GLOSSARY_START];
        if (start >= end) { break; }
        ++census_row_cursor;
        const uint32_t length = census_rows[row * ROW_WORDS + GLOSSARY_LENGTH];
        if (start < begin || length > end - start) { continue; }
        ++census_stats[12]; census_stats[13] += length;
        if (run_distance > start - census_bank_base) { continue; }
        const uint32_t previous_start = start - run_distance;
        uint32_t lo = 0u, hi = row;
        while (lo < hi) {
            const uint32_t mid = lo + (hi - lo) / 2u;
            if (census_rows[mid * ROW_WORDS + GLOSSARY_START] < previous_start) { lo = mid + 1u; }
            else { hi = mid; }
        }
        if (lo == row || census_rows[lo * ROW_WORDS + GLOSSARY_START] != previous_start ||
            census_rows[lo * ROW_WORDS + GLOSSARY_LENGTH] != length ||
            length > start - previous_start) { continue; }
        if (verified_source != 0) {
            for (uint32_t i = 0u; i < length; ++i) {
                if (verified_source[start + i] != verified_source[previous_start + i]) {
                    census_stats[1] = 11u; census_active = 0; run_present = 0; return;
                }
            }
            ++census_stats[28]; census_stats[29] += length;
        }
        eligible_run = 1;
        ++census_stats[14]; census_stats[15] += length;
        if (row - lo > 4u) { ++census_stats[20]; census_stats[21] += length; }
        if (baseline_reused[row]) {
            ++census_stats[18]; census_stats[19] += length;
        } else {
            ++census_stats[16]; census_stats[17] += length;
            const uint32_t lb = length_bucket(length);
            ++census_stats[32u + lb]; census_stats[40u + lb] += length;
            const uint32_t rb = lookback_bucket(row - lo);
            ++census_stats[48u + rb]; census_stats[56u + rb] += length;
        }
    }
    if (eligible_run) { ++census_stats[27]; }
    run_present = 0;
}

static void provenance_note_match(uint32_t start, uint32_t distance, uint32_t length) {
    if (!census_active) { return; }
    if (length == 0u || distance == 0u || distance > start ||
        start > census_bank_length || length > census_bank_length - start) {
        census_stats[1] = 4u; census_active = 0; return;
    }
    ++census_stats[7]; census_stats[8] += length;
    if (run_present && run_end == start && run_distance == distance) {
        run_end += length; return;
    }
    finish_run();
    run_present = 1; run_start = start; run_end = start + length; run_distance = distance;
}

void provenance_measure(uint32_t rows_ptr, uint32_t count, uint32_t source_ptr, uint32_t source_length) {
    if (census_stats[1] != 0u) { return; }
    if (sources.count == 0u || sources.count > CENSUS_MAX_BANKS ||
        sources.output != source_ptr || sources.bank_spans == 0u) {
        census_stats[1] = 5u; return;
    }
    if (!prepare_rows(rows_ptr, count, source_length)) { return; }
    verified_source = (const uint8_t*)(uintptr_t)source_ptr;
    const uint32_t* offsets = (const uint32_t*)(uintptr_t)sources.offsets;
    const uint32_t* compressed = (const uint32_t*)(uintptr_t)sources.compressed_lengths;
    const uint32_t* uncompressed = (const uint32_t*)(uintptr_t)sources.uncompressed_lengths;
    const uint32_t* methods = (const uint32_t*)(uintptr_t)sources.methods;
    const uint32_t* spans = (const uint32_t*)(uintptr_t)sources.bank_spans;
    uint32_t maximum = 0u, expected_base = 0u;
    for (uint32_t i = 0u; i < sources.count; ++i) {
        if (uncompressed[i] > maximum) { maximum = uncompressed[i]; }
        if (offsets[i] > sources.input_length || compressed[i] > sources.input_length - offsets[i] ||
            spans[i * 2u] > source_length || uncompressed[i] > source_length - spans[i * 2u] ||
            spans[i * 2u + 1u] != uncompressed[i] || methods[i] != 8u ||
            spans[i * 2u] != expected_base) {
            census_stats[1] = 6u; return;
        }
        expected_base += uncompressed[i];
    }
    if (expected_base != source_length) { census_stats[1] = 6u; return; }
    if (maximum == 0u || maximum > CENSUS_MAX_SCRATCH_BYTES) { census_stats[1] = 7u; return; }
    const uint32_t scratch_ptr = wasm_alloc(maximum);
    if (scratch_ptr == 0u) { census_stats[1] = 8u; return; }
    uint8_t* scratch = (uint8_t*)(uintptr_t)scratch_ptr;
    census_stats[24] = maximum;
    for (uint32_t bank = 0u; bank < sources.count; ++bank) {
        census_bank_base = spans[bank * 2u]; census_bank_length = uncompressed[bank];
        run_present = 0; census_active = 1;
        const int32_t result = term_bank_inflate(
            (const uint8_t*)(uintptr_t)(sources.input + offsets[bank]),
            compressed[bank], scratch, uncompressed[bank]);
        finish_run(); census_active = 0;
        if (result != 0 || census_stats[1] != 0u) { census_stats[1] = 9u; return; }
        const uint8_t* original = (const uint8_t*)(uintptr_t)(source_ptr + census_bank_base);
        for (uint32_t i = 0u; i < uncompressed[bank]; ++i) {
            if (scratch[i] != original[i]) { census_stats[1] = 10u; return; }
        }
        ++census_stats[2];
    }
    census_stats[25] = census_stats[9] * 12u;
    census_stats[0] = 1u;
}

__attribute__((visibility("default")))
uint32_t provenance_stats_ptr(void) {
    return (uint32_t)(uintptr_t)census_stats;
}

/* Synthetic range/merging checks for the census algorithm; never a parser fast path. */
__attribute__((visibility("default")))
uint32_t provenance_test(
    uint32_t rows_ptr, uint32_t count, uint32_t flags_ptr,
    uint32_t runs_ptr, uint32_t runs_count, uint32_t bank_base,
    uint32_t bank_length, uint32_t source_length
) {
    provenance_begin_rows();
    if (count > CENSUS_MAX_ROWS) { return 0u; }
    const uint8_t* flags = (const uint8_t*)(uintptr_t)flags_ptr;
    for (uint32_t i = 0u; i < count; ++i) { provenance_note_row(i, flags[i]); }
    if (!prepare_rows(rows_ptr, count, source_length)) { return 0u; }
    if (bank_base > source_length || bank_length > source_length - bank_base) { return 0u; }
    census_bank_base = bank_base; census_bank_length = bank_length;
    census_active = 1; run_present = 0;
    const uint32_t* runs = (const uint32_t*)(uintptr_t)runs_ptr;
    for (uint32_t i = 0u; i < runs_count; ++i) {
        provenance_note_match(runs[i * 3u], runs[i * 3u + 1u], runs[i * 3u + 2u]);
    }
    finish_run(); census_active = 0;
    census_stats[25] = census_stats[9] * 12u;
    census_stats[0] = census_stats[1] == 0u;
    return census_stats[0];
}

