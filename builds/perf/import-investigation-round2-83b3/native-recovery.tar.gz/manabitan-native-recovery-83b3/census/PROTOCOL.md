# Untimed DEFLATE-provenance coverage census

This is a diagnostic census of the pinned JMdict corpus on production source
9e10d3b3fcf66d344ab31bc42c9b522fa5215da2. It does not implement parse skipping
or produce performance evidence. It runs the actual compressed policy-3 parser
worker with the unchanged JS and exact baseline output oracle. The only relaxed
oracle field is native heap size, because instrumentation adds bounded scratch.

After the baseline fused parser succeeds, instrumentation retains its existing
validated-glossary witness per row and re-inflates each CRC-verified compressed
bank into one reusable scratch bank. Every replayed byte is compared against the
original inflated source. The real libdeflate fast and tail copy loops report
actual match output positions, backward distances and lengths, before their
permitted speculative over-copy. No speculative bytes enter coverage.

Adjacent copies merge only with contiguous output and the same backward distance.
A glossary qualifies only if its complete raw span is inside one such run and
subtracting that distance maps its start exactly onto an earlier completed
same-bank glossary with the same length. A non-overlap check requires length no
greater than distance. Every admitted raw glossary is additionally compared byte
for byte against its claimed prior span. No normalized equality, partial coverage,
cross-bank history or self-referential copy is admitted.

Counters distinguish gross coverage, eligible exact prior spans, overlap with
the actual current baseline grammar-reuse witness, and incremental rows/bytes
that the baseline actually parsed. Histograms describe incremental glossary
length and prior-row distance. Counts of all merged runs expose an upper-bound
metadata cost for a naive 12-byte descriptor design. The census itself retains
one run and counters, not those descriptors.

Bounds: 65,536 rows; 16 banks; 64 MiB source; 16 MiB scratch maximum, allocating
only the largest current bank; a 64 KiB baseline-reuse bitmap. Bank spans must
be contiguous, nonoverlapping, in bounds and cover exactly the original source.
The module is the existing shared-memory kind; the adapter asserts that premise.
Fourteen synthetic range/merge/boundary/overlap cases passed before acquisition.
Independent review found no blocker in the conservative range criterion.

One complete corpus pass: all 53 banks and 528,299 rows, current 12-group policy,
no JSON materialization in JS and no full-source capture. All output digests,
completed lookups, ownership, actual transfer and previous-result stability must
match the frozen baseline oracle. The observer's existing-reuse row count must
match the production profile exactly in every group. There is no performance
gate, timing comparison, adaptive threshold or parameter sweep in this census.

The child is bounded to 192 MiB oldspace, sampled 400 MiB RSS, 512 MiB available
memory headroom, a 256 MiB /tmp reserve and 120 seconds. Partial results, resource
observations, source/module/compiler identities and failures remain. Its timing
counters include an extra full inflate, full source comparison and census work;
they must not be interpreted as production performance.

