# Exact DEFLATE-provenance census — diagnostic result

The conservative history-copy criterion exposes at most 35,919 additional
glossaries (9,105,015 raw bytes) whose grammar traversal could be skipped on the
tested 9e10d3b3 baseline. That is 6.80% of rows, 6.71% of all glossary bytes, and
7.64% of glossary bytes the current baseline actually scans. Byte coverage is
not a CPU-time estimate. No parse-skipping implementation or speed claim follows.

| Quantity | Rows | Glossary bytes |
| --- | ---: | ---: |
| Complete JMdict corpus | 528,299 | 135,760,945 |
| Existing baseline grammar reuse | 54,641 | 16,529,724 |
| Whole same-distance run maps to exact earlier glossary | 56,714 | 15,769,850 |
| Already covered by existing baseline reuse | 20,795 | 6,664,835 |
| Additional grammar opportunity | 35,919 | 9,105,015 |

The actual production fused-parser witness determines existing reuse. Every
eligible claimed prior span passed an additional raw byte comparison. The second
inflate also matched the complete original CRC-verified source byte for byte.
All 53 banks, 528,299 rows, 12 policy-3 groups, complete output/lookup digests,
actual transfers, ownership receipt and previous-result stability matched the
pinned baseline oracle. Native heap size was intentionally excluded from the
oracle because the observer allocates one bounded scratch bank.

There were 4,228,772 history-copy matches and 4,142,419 merged runs. A naive
12-byte descriptor design would write 49,709,028 descriptor bytes over the full
corpus. This is aggregate work, not simultaneous residency: the largest group
would retain 5,141,844 descriptor bytes (4.90 MiB). The instrumentation itself
retained one run and counters, plus the 64 KiB baseline-witness bitmap. Its
largest scratch bank was 4,312,211 bytes, and observed peak process resourceUsage
RSS was 223.63 MiB.

Only 56,714 merged runs contain an eligible complete glossary. Before parsing,
the inflater does not know which runs those are. Selecting or indexing those
runs online would add work and metadata; the census does not treat that cost as
free. A bounded long-run design would lose some counted coverage and must measure
that loss explicitly. No product implementation was undertaken for this small
grammar-only upper bound.

Incremental opportunity by glossary length:

| Raw glossary length | Rows | Bytes |
| --- | ---: | ---: |
| <64 | 7,348 | 293,104 |
| 64–127 | 2,024 | 165,838 |
| 128–255 | 18,579 | 3,838,680 |
| 256–511 | 3,201 | 1,144,131 |
| 512–1023 | 4,219 | 2,976,780 |
| 1024–2047 | 547 | 683,855 |
| 2048–4095 | 1 | 2,627 |
| >=4096 | 0 | 0 |

Most incremental raw bytes map to a glossary two through four rows earlier:
6,522,468 bytes in 24,619 rows. Adjacent-row sources account for 919,621 bytes in
4,355 rows; farther than four rows accounts for the remainder. That may help
scope future distinct witness-cache research, but does not change this census's
exact compression-provenance criterion.

This diagnostic used source 9e10d3b3fcf66d344ab31bc42c9b522fa5215da2 before the
later #972 merge. Any future implementation must be reassessed on current source;
the old measurements cannot establish benefit on the new glossary fast path.

Audit material: PROTOCOL.md; acquisition.json; census-result.json; census.log;
instrumented C sources and copied libdeflate headers; module/build receipt;
14 passing range/merge/boundary tests and their results; actual-worker adapter.
All timing counters include an extra full inflate, source comparison and census
work and are expressly unsuitable as production performance evidence.

