# Preparation errors and incomplete work

The failed normalized-glossary census exited 137 after two partial groups. Its
cause was not established, and it produced no complete output JSON. The script,
observed exit status and explicitly transcribed partial values are retained here.
Normalized JSON equality was not accepted as raw-byte identity and these partial
values were not used as correctness or performance evidence for either candidate.

An executor outage interrupted preparation. The earlier /tmp toolchain path no
longer existed when execution recovered. Before any experiment acquisition, the
build used the already-existing read-only 81585d Clang/LLD 21.1.8 toolchain instead.
Its exact binary hashes, commands and versions are retained. Rebuilt baseline
bytes equaled the pinned artifact before any corpus execution.

Two local proof-inspection commands initially failed: loading the helper without
providing `__file__` raised `NameError`; a textual-assembly extractor expecting
`.Lfunc_end` raised `ValueError: substring not found`. The corrected inspections
are retained in the body proof and assembly-scope outputs. These errors did not
produce performance observations or change candidate sources.

The recovered output oracle was initially materialized with one extra trailing
newline. Its SHA256 mismatch was caught before freezing or running any corpus.
The extra newline was removed, and every acquired child checked the exact
548,717-byte oracle SHA256 b4719857... retained in the bundle.

The completed mask acquisition has no failed/replaced child: all three
correctness-only passes and all 48 fixed measured passes remain. Its identical
control drift and candidate gate failures are retained without extra rounds.
The exact provenance census and the one current-base diagnostic pass also
completed without replacement runs. Initial and reviewed census builds plus
both passing 14-case range-test receipts are retained; the review only added
range/identity validation before the single corpus census.

The original mask alternatives remain unqualified. D64's favorable component
signal is inconclusive under the fixed gate; neither candidate was converted
into a product PR. The provenance observer was never a product implementation.
