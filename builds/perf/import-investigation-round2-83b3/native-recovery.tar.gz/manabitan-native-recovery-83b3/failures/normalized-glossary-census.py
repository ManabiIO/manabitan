import collections
import hashlib
import json
from pathlib import Path
import zipfile

BASE = Path('/workspace/scratch/83b3b3bfba02/manabitan')
OUT = Path(__file__).resolve().parent
fixture = json.loads((BASE / 'test/perf/dictionaries.lock.json').read_text())['dictionaries']['jmdict']
archive = BASE / 'builds/e2e-dictionary-cache' / fixture['cacheFile']
assert hashlib.file_digest(archive.open('rb'), 'sha256').hexdigest() == fixture['sha256']
profile = json.loads((BASE / 'builds/perf/20261128-compressed-worker-profile-83b3/raw/result.json.txt').read_text())
report = {'kind': 'untimed-normalized-glossary-duplicate-census', 'limitation': 'JSON serialization supplies normalized semantic bytes, not original raw-byte equality; this is an opportunity census, not a runtime or timing oracle.', 'groups': []}
with zipfile.ZipFile(archive) as z:
    for group in profile['groups']:
        first = int(group['firstBank'][10:-5])
        last = int(group['lastBank'][10:-5])
        seen = {}
        counts = collections.Counter()
        lengths = collections.Counter()
        index = 0
        for bank in range(first, last + 1):
            rows = json.loads(z.read(f'term_bank_{bank}.json'))
            for row in rows:
                value = json.dumps(row[5], ensure_ascii=False, separators=(',', ':')).encode()
                key = hashlib.sha256(value).digest()
                prior = seen.get(key)
                counts['rows'] += 1
                lengths['all'] += len(value)
                if prior is not None:
                    distance = index - prior
                    bucket = '1' if distance == 1 else '2-4' if distance <= 4 else '5-16' if distance <= 16 else '17-64' if distance <= 64 else '65+'
                    counts[bucket] += 1
                    lengths[bucket] += len(value)
                    if len(value) < 512:
                        counts['duplicate-under512'] += 1
                        lengths['duplicate-under512'] += len(value)
                seen[key] = index
                index += 1
        report['groups'].append({'index': group['index'], 'rows': index, 'counts': dict(counts), 'normalizedBytes': dict(lengths), 'baselineValidatedReuseCount': group['responseCounters']['validatedGlossaryReuseCount']})
        print(json.dumps(report['groups'][-1]), flush=True)
report['totalCounts'] = dict(sum((collections.Counter(x['counts']) for x in report['groups']), collections.Counter()))
report['totalBytes'] = dict(sum((collections.Counter(x['normalizedBytes']) for x in report['groups']), collections.Counter()))
report['baselineValidatedReuseCount'] = sum(x['baselineValidatedReuseCount'] for x in report['groups'])
(OUT / 'glossary-census.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key != 'groups'}, indent=2))
