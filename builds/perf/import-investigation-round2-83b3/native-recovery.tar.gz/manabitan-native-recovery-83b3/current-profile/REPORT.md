# Current-base JMdict diagnostic profile

This one-pass profile used current develop
dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16, including merged #972. It loaded the
exact pinned release module
5d216041823936521f8a70b721472fb8c42052d165d771a92b59ed967d8d2695.
The rebuilt named module has identical noncustom WASM sections and supplies the
verified mapping for all 52 functions. It was not the loaded release.

All 528,299 rows and 53 banks passed full output, completed lookup, ownership,
actual transfer and previous-result stability oracles. Native maximum heap was
observed rather than equated to the older pre-#972 module. This is an instrumented
Node component diagnostic, not a browser-import comparison or a speed claim.

Measured boundaries in this pass: worker module import/native compile/initialize
23.54 ms; sum of the 12 actual worker handlers 1,101.31 ms; actual adapter
structured-clone delivery 2.94 ms. There are 13 raw 1 ms CPU profiles: one startup
and 12 handler-plus-delivery intervals, excluding archive I/O, source copying,
parent ownership registration and output hashing.

## Observed native leaves

| Native leaf | Samples | Weighted sample intervals |
| --- | ---: | ---: |
| Fused parse/encode/intern function self | 138 | 177.35 ms |
| libdeflate decode | 120 | 144.71 ms |
| Immediate source CRC | 74 | 82.71 ms |
| General composite grammar traversal | 72 | 91.74 ms |
| Term-content row encoder | 60 | 70.35 ms |
| Row parser | 57 | 67.92 ms |
| Paired XXH32 content hashes | 47 | 53.69 ms |
| Compact glossary list fast path | 18 | 19.96 ms |
| Native lookup encoding | 14 | 15.38 ms |
| Scalar token scanning | 13 | 20.59 ms |
| Existing validated-glossary comparisons | 12 | 14.00 ms |

These are sampled leaf occupancy estimates, not independently measured stage CPU
or removable wall time. Existing glossary reuse includes successful and failed
attempts; this profile does not separate their costs. Fused-function self includes
interner, dedup and row bookkeeping work and must not be relabeled entirely
hashing. The production counters report 54,641 existing glossary reuses
and 154,416 recent full-content dedup hits.

Inspector start/stop synchronization contributes 12 node:inspector post samples
and about 223.87 ms in raw profiles. That overhead remains in raw evidence and is
separated from native attribution; it is not parser work. No profiled timing is
pooled with the previous unprofiled candidate cohort.

## Owned output copying is a substantial separate target

The worker result callback accounts for 143 leaf samples (176.77 ms weighted).
Its source position ticks identify 139 at owned.set(resultChunk.contentBytesBuffer)
and four at the preceding SharedArrayBuffer allocation. The pass publishes
101,143,985 encoded-content bytes in owned shared slabs. Total reported result
copy time, including other columns, is 213.52 ms.

This does not prove a lower-cost replacement. Native allocation already aligns
the source content offset to eight bytes. On this exact Node version, the official
V8 source shows shared TypedArray.set using relaxed memmove, with nonoverlapping
ranges delegated to relaxed memcpy; SharedArrayBuffer.slice uses relaxed memcpy
as well. Merely substituting those two APIs has no demonstrated algorithmic gain.

Primary source audit:
- https://github.com/nodejs/node/blob/v22.22.0/deps/v8/src/builtins/typed-array-set.tq
- https://github.com/nodejs/node/blob/v22.22.0/deps/v8/src/base/atomicops.h
- https://github.com/nodejs/node/blob/v22.22.0/deps/v8/src/builtins/builtins-arraybuffer.cc

## Scope/ownership audit for next work

1. Owned content-slab copying is a large observed target, but changing ownership
   overlaps the existing lookahead/cache/borrowed-lease architecture. #820 already
   owns native key/expression-column reuse; #881 owns borrowing large projected
   content; #839/#869 retain memory-regression/budget evidence. Earlier aligned
   cache-copy proposals #27/#758/#766 are distinct from this aligned slab copy,
   but their results prevent a generic assumption that cheaper copying improves
   whole imports.
2. Fused native bookkeeping plus content encoding/hashing remains substantial.
   Adjacent raw-key reuse up to 32 body bytes is already present and is not a new
   candidate. #840 already owns copy/hash fusion for large literal glossaries.
3. General grammar remains visible, but #972 and earlier #948 own compact
   structured-list/type-literal work. The old shared-mask screen is inconclusive
   on its old base and was not rerun here.
4. The exact row-tail mechanism is already owned by the active numeric suffix
   study: workflow ee9450923d14e95b7958feeffffde4998cf8c5d9, run 46113243549,
   baseline 9e10d3b3, candidate 399feae29fea358560af27af68f03dfb6d8b6f58. That
   candidate validates current keys and requires full suffix equality through the
   row terminator. Its admission uses the preceding match streak and equal
   previous scores/sequences. A current-sequence prefilter would be a follow-up
   admission experiment, not a novel independent row-tail implementation.

No new candidate was timed in this diagnostic pass. A separately authorized
bounded follow-up census may compare admission rules after the quiet unit window.
Any such census remains distinct from the existing owner's frozen active study.

