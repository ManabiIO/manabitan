# Current-base diagnostic profile

Exactly one complete current-release JMdict worker replay on
dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16, with no candidate, warmup or speed claim.
The production native module is the exact pinned 5d216041... release binary;
an independently built named module has equal noncustom sections and supplies
the function-index/name mapping. Production JS comes from a clean sparse current
checkout. All 53 banks and 528,299 rows must match the complete prior baseline
output/lookup/ownership/transfer oracle. Native maximum heap is recorded rather
than equated to the older pre-#972 artifact, whose data layout may differ.

Inspector sampling interval is 1 ms. One startup profile covers worker module
import, native module compilation and worker initialize after harness helper
imports. Each of the 12 corpus profiles starts immediately before the actual
worker send and stops after structured-clone delivery, before parent ownership
receipt and output/SHA validation. No archive I/O, source buffer copying or
oracle hashing occurs inside those profile intervals. Handler elapsed time,
adapter delivery time and startup time are recorded with their separate existing
boundaries. The CPU samples represent observed occupancy under instrumentation,
not removable wall time or a browser-import profile.

One process, 192 MiB oldspace, sampled 400 MiB RSS cap, 512 MiB available-memory
gate, 256 MiB output-filesystem reserve, and 120-second cap. All profiles, logs,
identity receipts, partial results and failures are retained. No optional second
profile pass or candidate timing is part of this diagnostic acquisition.
