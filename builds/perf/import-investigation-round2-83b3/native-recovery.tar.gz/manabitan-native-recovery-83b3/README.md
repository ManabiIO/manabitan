# Native import experiments: complete recovery bundle

No product PR is supported by these observations. This bundle preserves the
implementation candidates, frozen protocol, full raw observations, negative or
inconclusive decisions, correctness checks, failed preparation work and a current
baseline diagnostic. It does not overwrite or replace earlier studies.

## Decisions and evidence

**Shared string-classification masks, baseline 9e10d3b3.** Both 32-byte and
64-byte caches passed 45,046 differential cases and three complete correctness
passes. All 48 measured fresh-process passes in the fixed 12-round four-arm
cohort completed. The 32-byte candidate changed paired worker time +3.061%
against A and -7.024% against identical C, with 5/12 and 8/12 faster rounds.
The 64-byte candidate changed -7.380% and -13.692%, with 9/12 and 10/12 faster
rounds. Identical C/A median drift was +3.499%, above the prospectively fixed
3% limit. Neither candidate passes the fixed overall gate. D64 is inconclusive;
the result does not establish that the idea cannot help. There were no optional
rounds, replacements, threshold changes or product PR.

**Exact DEFLATE-copy provenance census, baseline 9e10d3b3.** All raw output
oracles passed. Whole constant-distance copy runs expose 35,919 additional
glossaries / 9,105,015 raw bytes beyond existing grammar witnesses: 7.64% of the
bytes the baseline actually scans. This is an upper bound on grammar bytes,
not time. A naive run list would write 49,709,028 descriptor bytes over all groups;
peak per-group descriptor residency would be 5,141,844 bytes. The census retained
one run, counters and a 64 KiB witness bitmap, not that list. No parser-skipping
implementation followed from this small upper bound.

**Current-base diagnostic, dcfc02a0.** The one predeclared current-release corpus
pass after #972 passed output/lookup/ownership/transfer checks. Thirteen CPU
profiles and the verified native function map are retained. The report separates
Inspector overhead, generic grammar, existing glossary comparisons, native fused
bookkeeping, encoding/hashes, owned-copy work and initialization/delivery.
It is not a candidate comparison or whole-browser timing result.

## Layout

- mask/source: exact frozen C candidates, baseline C, scripts, baseline oracle,
  compiler receipts/logs, all release/named modules, differential harness/result,
  body proof, assembly scope and original replay source. The support directory
  contains the exact inflater and vendored source needed for standalone rebuilds.
- mask/observations: frozen-protocol.json, full parity and measured acquisition
  receipts, every child JSON/stdout log, summary and decision report.
- census: observer sources/vendor copy, module, build receipts, both pre-review
  and reviewed range tests, actual-worker harness, acquisition, complete counts,
  output identity checks and decision report.
- current-profile: exact current module, named counterpart, function map,
  production native source snapshot, rebuild receipt, one-pass controller and
  harness, all CPU profiles, full output receipt, derived summary and report.
- failures: the interrupted normalized-glossary census (exit137, cause unknown),
  its exact source and explicitly transcribed partial values, plus preparation
  errors. No normalized equality was used as raw-byte proof.
- reproduction: portable native rebuild helper. It does not acquire performance
  observations.
- manifest.json: SHA256 and length of every other member.

## Identities

Original source:
9e10d3b3fcf66d344ab31bc42c9b522fa5215da2

Current diagnostic source:
dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16

Frozen mask protocol:
49682f093c26ea1d93eb9706a8e0186b0ed3e9378594a0948681a54ec354d530

Fixture archive, 15,645,766 bytes:
3a614c92cfa747946de8422fc408d6d93926ba76541df66e434b24976a10160f

Fixture lock:
60aa981791f3b60ca17588212aea5bd3536fb8f59288855e5accd019c6e4cf89

Frozen complete-output oracle, 548,717 bytes:
b471985781ae3a6ee6e8b3363f71020ba221dbd7e049347cc7bc7408d22a1c11

Every acquired corpus pass uses the pinned JMdict source: 53 banks, 528,299 rows
and 171,617,523 uncompressed bytes. Exact Node22.22.0 binary identity, compiler
and linker21.1.8 binary identities and actual commands remain in the original
receipts. Large compiler/Node binaries, dependency trees and the dictionary
archive are not duplicated; their identities and source recipes are retained.

## Rebuilding and checking without another experiment

The portable helper accepts explicit clang21.1.8 and wasm-ld21.1.8 paths and a
new output directory. A process-local library path may be supplied if the
read-only compiler installation needs it. It rebuilds A/B32/D64/current and each
named counterpart, then requires exact frozen module SHA256 equality. Original
absolute commands remain separately preserved rather than rewritten.

Run the native differential script with a new output filename and the rebuilt
A, B32 and D64 modules. Do not overwrite the original result. The body-proof
script and function-map proof describe how named and release noncustom sections
were compared. The original worker replay accepts explicit source-root, module,
oracle and output paths, with frozen source/module/fixture checks.

For a complete worker reproduction, check out the exact corresponding Git
commit, provision the repository's normal dependencies/assets, and place the
pinned archive in builds/e2e-dictionary-cache/JMdict.zip. The acquired source
files, static guards, grouping, worker options, ownership checks and oracle are
all retained. The original controllers retain original absolute workspace paths
so their frozen hashes remain intact. Any portability edits must be made to a
new copy and identified as a new protocol.

A future timing acquisition is a new study, not a replacement or continuation
of these failed gates. The original 48 observations and all controls remain
authoritative for this screen. Source/corpus/module identity does not make
different hosts, runtimes or later source revisions interchangeable.

## Remaining work and attribution

The current profile prompted review of a sequence-assisted exact row-tail idea.
The core mechanism is already owned by numeric-suffix candidate
399feae29fea358560af27af68f03dfb6d8b6f58 and active study run46113243549. No duplicate
implementation was created. Any current-sequence admission follow-up must retain
that attribution and remain separate from its frozen active study.

No Work mode or browser UI automation was used for these native experiments.
All source, evidence and toolchain use stayed in isolated or read-only paths.

