"""Rebuild frozen native modules; does not run or replace any performance cohort."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--clang', required=True, type=Path)
parser.add_argument('--wasm-ld', required=True, type=Path)
parser.add_argument('--output', required=True, type=Path)
parser.add_argument('--library-path')
args = parser.parse_args()
bundle = Path(__file__).resolve().parent.parent
args.output.mkdir(parents=True, exist_ok=False)
env = dict(os.environ)
if args.library_path is not None:
    env['LD_LIBRARY_PATH'] = args.library_path
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
receipt = {'complete': False, 'binaries': {}, 'commands': [], 'modules': {}, 'failures': []}
def save():
    (args.output/'rebuild-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
save()
try:
    for name, binary in [('clang', args.clang), ('wasm-ld', args.wasm_ld)]:
        version = subprocess.check_output([str(binary), '--version'], env=env, text=True)
        assert '21.1.8' in version, version
        receipt['binaries'][name] = {'path': str(binary.resolve()), 'sha256': sha(binary.resolve()), 'version': version}
    mask = bundle/'mask/source'
    current = bundle/'current-profile'
    old_receipt = json.loads((mask/'build-receipt.json').read_text())
    current_receipt = json.loads((current/'build-receipt.json').read_text())
    arms = [
        ('A', mask/'baseline-parser.c', mask/'support/term-bank-inflate.c', mask/'manifest-base.json', old_receipt['modules']),
        ('B32', mask/'parser-32.c', mask/'support/term-bank-inflate.c', mask/'manifest-base.json', old_receipt['modules']),
        ('D64', mask/'parser-64.c', mask/'support/term-bank-inflate.c', mask/'manifest-base.json', old_receipt['modules']),
        ('current', current/'product-native/term-bank-parser.c', current/'product-native/term-bank-inflate.c', current/'product-native/manifest.json', current_receipt['modules']),
    ]
    for arm, source, inflater, manifest, expected in arms:
        target = next(t for t in json.loads(manifest.read_text())['targets'] if t['name']=='term-bank-parser.wasm')
        for named in [False, True]:
            label = arm + ('-names' if named else '')
            flags = [f for f in target['arguments'] if not(named and f=='-Wl,--strip-all')]
            output = args.output/(label+'.wasm')
            command = [str(args.clang), '-fuse-ld='+str(args.wasm_ld), *flags, '-o', str(output), str(source), str(inflater)]
            receipt['commands'].append({'label': label, 'argv': command, 'sourceSha256': sha(source), 'inflaterSha256': sha(inflater)})
            save()
            with (args.output/(label+'.log')).open('wb') as log:
                result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=120)
            assert result.returncode==0, label+' compiler failed'
            digest = sha(output)
            assert digest==expected[label]['sha256'], label+' differs from frozen module'
            receipt['modules'][label]={'sha256': digest, 'bytes': output.stat().st_size}
            save()
    receipt['complete']=True;save()
except BaseException as error:
    receipt['failures'].append({'type':type(error).__name__,'message':str(error)})
    save();raise
print(json.dumps({'complete':True,'modules':receipt['modules']},indent=2))

