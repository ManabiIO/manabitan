import hashlib, json, os, pathlib, shutil, signal, subprocess, time

out = pathlib.Path(__file__).resolve().parent
base = pathlib.Path('/tmp/manabitan-current-native-83b3')
node = pathlib.Path('/workspace/scratch/83b3b3bfba02/node-v22.22.0-linux-x64/bin/node')
oracle = pathlib.Path('/workspace/scratch/83b3b3bfba02/native-string-round2/builds/perf/round2-native-83b3/policy-3-oracle.json')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
frozen = json.loads((out / 'frozen-inputs.json').read_text())
assert frozen['sourceSha'] == 'dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16'
assert sha(node) == frozen['nodeSha256']
assert all(sha(out / p) == expected for p, expected in frozen['inputs'].items())
assert shutil.disk_usage(out).free >= 256 * 1024 * 1024
mem_available = lambda: int(next(s.split()[1] for s in pathlib.Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:'))) * 1024
assert mem_available() >= 512 * 1024 * 1024
assert json.loads((out / 'row-tests.json').read_text())['complete']
assert frozen['inputs']['census.wasm'] == json.loads((out / 'build-receipt.json').read_text())['moduleSha256']
command = [str(node), '--max-old-space-size=192', str(out / 'census-worker.mjs'), str(base),
           str(out / 'census.wasm'), str(oracle), str(out / 'census-result.json'), 'CENSUS']
receipt = {'complete': False, 'startedUnixNs': time.time_ns(), 'inputs': frozen,
           'frozenInputSha256': sha(out / 'frozen-inputs.json'), 'command': command,
           'samples': [], 'failures': [], 'initialMemAvailableBytes': mem_available()}
with (out / 'acquisition.json').open('x') as f:
    json.dump(receipt, f, indent=2); f.write('\n')
def save():
    (out / 'acquisition.json').write_text(json.dumps(receipt, indent=2) + '\n')
process = None
try:
    with (out / 'census.log').open('xb') as log:
        process = subprocess.Popen(command, cwd=base, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        start = time.monotonic()
        while True:
            try:
                value = pathlib.Path('/proc/' + str(process.pid) + '/stat').read_text()
                parts = value[value.rindex(')') + 2:].split()
                sample = {'monotonicNs': time.monotonic_ns(),
                          'rssBytes': int(parts[21]) * os.sysconf('SC_PAGE_SIZE'),
                          'userTicks': int(parts[11]), 'systemTicks': int(parts[12]),
                          'memAvailableBytes': mem_available()}
                receipt['samples'].append(sample)
                assert sample['rssBytes'] <= 400 * 1024 * 1024, 'Child RSS cap exceeded'
                assert sample['memAvailableBytes'] >= 512 * 1024 * 1024, '512 MiB memory reserve failed'
            except FileNotFoundError:
                pass
            code = process.poll()
            if code is not None:
                break
            assert time.monotonic() - start <= 120, 'Child deadline exceeded'
            time.sleep(0.25)
        receipt['exitCode'] = process.wait(); process = None; save()
    assert receipt['exitCode'] == 0, 'Census child failed; retain partial output'
    result = json.loads((out / 'census-result.json').read_text())
    assert result['complete'] and not result['failures'] and result['rows'] == 528299
    assert all(sha(out / p) == expected for p, expected in frozen['inputs'].items()), 'Inputs changed during census'
    assert sha(node) == frozen['nodeSha256']
    receipt.update(complete=True, resultSha256=sha(out / 'census-result.json'), endedUnixNs=time.time_ns())
    save()
    print(json.dumps({'complete': True, 'rows': result['rows'], 'totals': result['tailTotals']}))
except BaseException as error:
    if process is not None:
        try:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL); process.wait()
        except ProcessLookupError:
            process.wait()
    receipt['failures'].append({'type': type(error).__name__, 'message': str(error)})
    save()
    raise
