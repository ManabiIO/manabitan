# Exact row-tail follow-up: no eligible JMdict work

The frozen diagnostic completed once, on all 53 pinned JMdict banks and 528,299
rows. It found **zero adjacent exact full row tails**, including when the admission
gate was ignored. The proposed current-sequence prefilter therefore offers no
eligible parser, numeric or content-ID reuse on this fixture. No implementation,
performance run or product PR follows from this census.

This conclusion is specific to the pinned fixture and the exact raw suffix
criterion. It does not claim anything about the existing candidate's eligibility
or performance on Jitendex, VNDB or another corpus. The original suffix mechanism
belongs to candidate 399feae29fea358560af27af68f03dfb6d8b6f58; this experiment only
tested a prospective additive admission on current dcfc02a0.

## Complete observed counts

| Quantity | Rows / probes | Bytes |
| --- | ---: | ---: |
| All current rows / raw tails | 528,299 | 151,918,138 |
| All glossaries | 528,299 | 135,760,945 |
| Existing owner's history admission | 0 | 0 |
| Ungated exact full tails | 0 | 0 |
| Current-sequence probes | 507,323 | 4,058,584 attempted span bytes |
| Current-sequence gate passes | 634 | — |
| Gate passes whose final sample also matches | 619 | 178,256 attempted full-compare span bytes |
| Exact full-tail matches after the gate | 0 | 0 |
| Existing baseline glossary witnesses | 54,641 | 16,529,724 |
| Modeled owner glossary witnesses | 54,641 | 16,529,724 |
| Modeled additive union glossary witnesses | 54,641 | 16,529,724 |
| Additional union grammar reuse | 0 | 0 |
| Baseline compact glossary parsing | 265,096 | 57,926,523 |
| Baseline generic glossary parsing | 208,562 | 61,304,698 |

The current gate rejected 506,689 probes on sequence bytes; another 25 prior
positive-sequence rows could not fit the predicted probe and whole suffix into
the logical bank. All 634 sequence-prefilter passes had unequal complete tails.
The exact last-sample comparisons requested 5,072 bytes in total. Attempted spans
are not actual bytes inspected by short-circuit comparisons or time savings.

The unchanged parser recorded 154,416 recent-content dedup hits and 373,883 rows
requiring full content encoding. The hypothetical exact-tail eligibility is zero,
so no part of that work can be credited to this follow-up. The maximum actual raw
tail was 4,557 bytes; it is a maximum across groups, not an aggregate.

## Validation and scope

All twelve groups preserve the complete frozen output and lookup digests, row and
metadata shapes, owned-content receipt, actual transfer lists and previous-result
stability after native heap reuse. The three-budget observer's baseline witness
matches the actual native witness on every row. Production glossary-reuse and
recent-content-hit counters agree exactly with the observer in every group.

Twelve fixed small worker cases pass. They include positive controls for owner
admission, current-only admission, overlap, owner-only null/zero sequences and
cross-bank/escaped-key equality. They also reject score/glossary mismatches,
numeric prefixes, insufficient bank bounds and a truncated bank. The complete
small inputs and results are in row-tests.json; they show that the zero-corpus
result did not arise from a disabled observer or a predicate unable to accept
exact tails. No second corpus pass was run.

The acquisition had no failed observation. Sampled peak child RSS was 224,608,256
bytes; process.resourceUsage reported maximum RSS of 227,037,184 bytes. The minimum
sampled system MemAvailable was 1,741,262,848 bytes. These are resource guard
observations, not a candidate memory comparison. The diagnostic finished in
2.155 seconds, including its controller window; its instrumented timing counters
must not be interpreted as production performance.

## Frozen identities and reproduction

- Base: dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16.
- Existing candidate: 399feae29fea358560af27af68f03dfb6d8b6f58.
- Frozen input manifest SHA256:
  e1ed7c9d750f1680e143352f9e2914bcc2c0c78945ecdb3782e254d576597fee.
- Observer module SHA256:
  64b74ae6c6489978084ec6aa07233387ed9caafa006ef167170a97ef478ffb8d.
- Current production module SHA256:
  5d216041823936521f8a70b721472fb8c42052d165d771a92b59ed967d8d2695.
- Pinned JMdict ZIP SHA256:
  3a614c92cfa747946de8422fc408d6d93926ba76541df66e434b24976a10160f.
- Exact full-output oracle SHA256:
  b471985781ae3a6ee6e8b3363f71020ba221dbd7e049347cc7bc7408d22a1c11.

PROTOCOL.md defines the prospective criterion and bounds. frozen-inputs.json and
build-receipt.json bind the source, observer, compiler/linker binaries, Node binary,
controller, module and prerequisite small-case results. The complete generated C
and its patch against current production C are retained, together with unchanged
native source/vendor inputs. The worker harness uses the current-base checkout,
its installed dependencies and the pinned ZIP; its seven original oracle helper
functions remain unchanged. Local absolute paths in build.py, row-tests.mjs and
run-census.py identify the acquisition environment and can be relocated for an
independent reproduction, which must have a new output directory and identity.

The complete original acquisition.json, census-result.json and census.log retain
all per-group counters and output proofs. counter-map.json names the raw indices.
manifest.json hashes every bundled member except itself. This is a separate
follow-up bundle; the earlier mask/provenance/profile recovery archive remains
unchanged at SHA256 22ffe506b351607d74889eb58e2159d6d257ae4d6142485b30628d7b4fe9647f.
