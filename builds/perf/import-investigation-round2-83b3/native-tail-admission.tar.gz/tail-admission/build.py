import hashlib, json, os, pathlib, subprocess

out = pathlib.Path(__file__).resolve().parent
root = pathlib.Path('/tmp/manabitan-current-native-83b3')
sdk = pathlib.Path('/tmp/manabitan-81585d-toolchain/usr/lib')
clang = sdk / 'llvm-21/bin/clang'
linker = sdk / 'llvm-21/bin/wasm-ld'
env = dict(os.environ, LD_LIBRARY_PATH=str(sdk / 'x86_64-linux-gnu') + ':' + str(sdk / 'llvm-21/lib'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest = json.loads((root / 'dev/data/dictionary-wasm/manifest.json').read_text())
target = next(t for t in manifest['targets'] if t['name'] == 'term-bank-parser.wasm')
assert target['sha256'] == '5d216041823936521f8a70b721472fb8c42052d165d771a92b59ed967d8d2695'
command = [str(clang), '-fuse-ld=' + str(linker), *target['arguments'],
           '-Wl,--export=tail_census_stats_ptr', '-o', str(out / 'census.wasm'),
           str(out / 'census-parser.c'), str(root / target['sources'][1])]
sources = sorted((root / 'ext/js/dictionary/wasm').rglob('*'))
receipt = {'complete': False, 'sourceSha': 'dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16',
           'existingTailCandidateSha': '399feae29fea358560af27af68f03dfb6d8b6f58',
           'command': command, 'failures': [],
           'sourceHashes': {str(p.relative_to(root)): sha(p) for p in sources if p.is_file()},
           'observerSha256': sha(out / 'observer.c.inc'),
           'parserSha256': sha(out / 'census-parser.c'), 'patchSha256': sha(out / 'observer.patch')}
for label, binary in [('clang', clang), ('wasm-ld', linker)]:
    receipt[label] = {'path': str(binary), 'sha256': sha(binary),
                      'version': subprocess.check_output([str(binary), '--version'], env=env, text=True)}
    assert '21.1.8' in receipt[label]['version']
assert receipt['clang']['sha256'] == 'ca624b13939495e48e99218a7def4039e443b9584dfccb161521952bd4a65289'
assert receipt['wasm-ld']['sha256'] == '83c1ad07cb7801d52fd53cf0bdf39e4318c29a883c5d1353151ece1b2ccdf9f2'
with (out / 'build-receipt.json').open('x') as f:
    json.dump(receipt, f, indent=2); f.write('\n')
try:
    with (out / 'build.log').open('xb') as log:
        result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=60)
    assert result.returncode == 0, 'Compiler failed; preserve build.log'
    receipt.update(complete=True, moduleSha256=sha(out / 'census.wasm'),
                   moduleBytes=(out / 'census.wasm').stat().st_size)
except BaseException as error:
    receipt['failures'].append({'type': type(error).__name__, 'message': str(error)})
    raise
finally:
    (out / 'build-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'complete': receipt['complete'], 'moduleBytes': receipt.get('moduleBytes'),
                  'moduleSha256': receipt.get('moduleSha256')}))
