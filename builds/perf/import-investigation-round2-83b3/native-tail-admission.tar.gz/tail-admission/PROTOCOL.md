# Comparative exact-row-tail admission census

This is one untimed diagnostic pass of the pinned JMdict corpus on develop
dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16. It does not implement an optimization,
skip production work or qualify a performance claim. All parser and encoder
output is produced normally by the current source. The observer runs afterward.

## Existing ownership and the incremental question

The exact suffix reuse mechanism and numeric-history admission belong to existing
candidate 399feae29fea358560af27af68f03dfb6d8b6f58, based on 9e10d3b3. Its frozen
qualification workflow is import-numeric-suffix-qualification-c563d487.yml at
ee9450923d14e95b7958feeffffde4998cf8c5d9, run 46113243549. This census neither
modifies that candidate nor redefines its study. It estimates eligibility for an
attributed follow-up on the newer baseline.

The existing admission requires a nonzero recent-content-match streak, at least
two previous rows, and equal scores and sequences in those previous two rows.
Its suffix starts at definition tags, follows the independently validated current
expression and reading, and ends immediately after the row closing bracket.
The previous suffix length must fit the current logical bank. An exact last-eight
byte sample precedes full raw equality. No normalization or sequence-only match
can establish a witness.

The proposed additive prefilter uses one previous validated row with a positive
sequence. It probes the previous sequence token's translated offset inside the
current predicted suffix. Both the whole suffix and the token plus following
byte must fit the current logical bank; the probe is at most eleven bytes.
It then requires the same existing last-sample and full raw suffix equality.
The additive union retains all existing owner admissions; its new probes are
needed only where the existing history admission is false.

## Accounting and invariants

Every hypothetical exact suffix match must reproduce all shifted metadata,
including null-sequence sentinel, glossary hints, numeric token ends and actual
row end. Score, sequence and first-use content ID must match the previous row.
It must already be a real recent-content-dedup hit in the unchanged parser.
Thus no extra full content encoding or payload-hash pass is credited to this
follow-up. Direct numeric and content-ID reuse are counted separately as possible
small operations beyond the existing owner's witness implementation.

Three independent probe-budget models describe the baseline, the existing owner,
and the additive union. They call the real current glossary equality helper, use
the current four-probe/four-streak/512-byte policy, and reproduce decrement/reset
ordering. The modeled baseline witness must equal the actual production witness
for every row. Exact suffix witnesses reset their model's budget. The observer
counts additional grammar reuse only when the union has a witness and the owner
model does not. It separates direct new suffix wins from later probe-budget
spillover and records whether the unchanged parser used compact or generic
grammar for those rows. Models must be monotone in witness availability.

Counters containing comparison lengths are attempted span bytes. Short-circuit
comparisons may inspect fewer bytes; the counters are neither saved CPU nor memory
bandwidth measurements. Counter 75 is a maximum; other counters aggregate by sum.
The counter map and complete source accompany the raw per-group arrays.

The module requires the production validated-glossary-reuse flag and strict
format-3 validation. The actual successful fused path also establishes int32
numeric output. It retains constant state: 128 uint32 counters, previous-row
ends and three budgets, with no source/row object capture or match index. Source
groups are bounded to 64 MiB and 65,536 rows. Current expressions and readings
are parsed normally, including escaped keys; source bank boundaries remain intact.

Twelve fixed small cases run through the real worker before the corpus pass:
second-row admission, score and glossary mismatch, numeric-prefix rejection,
null and zero owner-only sequences, exact cross-bank tails, escaped keys, current
logical-bank bounds, already-reused long glossaries, nested glossary equality,
and malformed-bank rejection. Their complete inputs and results are retained.

## One bounded corpus pass

The worker replay uses the actual compressed input path, current production JS,
three-parser-worker policy's twelve groups, and sequential execution concurrency
one. It includes all 53 banks and 528,299 rows. The seven original v3 helper
functions, group partition, actual transfer lists, owned-content receipt and
previous-result stability checks are preserved. Full output/lookup digests and
shape/ownership fields must match the existing fixed oracle. Native heap size is
excluded because the observer adds static state. No corpus JSON materialization
is performed in JavaScript.

Acquisition is frozen before execution: source, observer, compiled module, compiler
binaries, Node binary, fixture, oracle, controller and small-case results are
hashed. Both installed current baseline module copies and tracked ext/dev sources
must match the current base. No replacement corpus pass, adaptive thresholds or
optional additional corpus is included in this protocol. A failure stops this
acquisition and retains its partial output and failure record.

Resource bounds are 192 MiB Node oldspace, 400 MiB sampled child RSS, 512 MiB
available memory, a 256 MiB reserve on the /tmp output filesystem and a 120-second
deadline. The result and controller record all failures and resource observations.
All timings include observer comparisons and three extra model traversals. They
must not be presented as production or candidate performance evidence.
