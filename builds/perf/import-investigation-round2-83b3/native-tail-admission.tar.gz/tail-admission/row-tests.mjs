import assert from 'node:assert/strict';
import {readFile, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const root='/tmp/manabitan-current-native-83b3';
const out='/tmp/manabitan-tail-admission-census-83b3';
const bytes=await readFile(out+'/census.wasm');
const module=await WebAssembly.compile(bytes);
let wasm=null,callback=null,pending=null;
globalThis.self={addEventListener(type,value){assert.equal(type,'message');callback=value;},postMessage(message,transfer=[]){
    const counters=message.type==='result'?Array.from(new Uint32Array(wasm.memory.buffer,wasm.tail_census_stats_ptr(),128)):null;
    const received=structuredClone(message,{transfer});const resolve=pending;pending=null;resolve({message:received,counters});
}};
await import(pathToFileURL(root+'/ext/js/dictionary/term-bank-wasm-parser-worker.js'));
async function send(data){
    assert.equal(pending,null);let timer;
    const promise=new Promise((resolve,reject)=>{pending=resolve;timer=setTimeout(()=>reject(Error('Toy worker timeout')),5000);});
    try{callback({data});return await promise;}finally{clearTimeout(timer);}
}
const instantiate=WebAssembly.instantiate;
WebAssembly.instantiate=async(...args)=>{const result=await instantiate(...args);if(args[0]===module)wasm=result.exports;return result;};
try{assert.equal((await send({type:'initialize',module})).message.type,'ready');}finally{WebAssembly.instantiate=instantiate;}
const crc32=bytes=>{let crc=0xffffffff;for(const byte of bytes){crc^=byte;for(let i=0;i<8;i++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}return (crc^0xffffffff)>>>0;};
const row=(key,sequence=123,score=-2,glossary=['same'])=>[key,'','tag','',score,glossary,sequence,''];
const options={copyContentBytes:false,includeContentMetadata:true,initialContentBytesPerRow:48,minimalDecode:true,
    reuseExpressionForReadingDecode:true,preallocateChunkRows:true,skipTagRuleDecode:false,lazyGlossaryDecode:true,
    mediaHintFastScan:false,projectImagePaths:false,validateGlossaryTypes:true,computeContentHashes:true,
    emitContentSlab:true,emitTokenBinaryContent:true,emitTermByteLists:false,prepareLookupIndexes:true,
    prepareLookupRoute:false,ownContentBytes:false,experimentalNativeEscapedKeys:true};
const report={complete:false,moduleSha256:createHash('sha256').update(bytes).digest('hex'),cases:[],failures:[]};
await writeFile(out+'/row-tests.json',JSON.stringify(report,null,2)+'\n',{flag:'wx'});
async function run(name,banks,expected,valid=true){
    const strings=banks.map(bank=>typeof bank==='string'?bank:JSON.stringify(bank));
    if(strings.length===1)strings.push('[]');
    const sourceBytes=strings.map(value=>new TextEncoder().encode(value));
    const sourceMetadata=sourceBytes.map((bytes,index)=>({compressionMethod:0,compressedSize:bytes.byteLength,uncompressedSize:bytes.byteLength,signature:crc32(bytes),filename:'term_bank_'+(index+1)+'.json'}));
    const response=await send({type:'parse',id:0,version:3,sourceBuffers:sourceBytes.map(value=>value.buffer),sourceMetadata,chunkSize:8192,options});
    if(valid){
        assert.equal(response.message.type,'result',name+': '+JSON.stringify(response.message.error));
        const c=response.counters;assert.equal(c[0],1,name+' complete');assert.equal(c[1],0,name+' error code');
        assert.equal(c[2],response.message.chunk.rowCount,name+' rows');
        assert.equal(c[104],response.message.profile.validatedGlossaryReuseCount,name+' baseline witness model');
        for(const [index,value] of Object.entries(expected))assert.equal(c[Number(index)],value,name+' counter '+index);
    }else assert.equal(response.message.type,'parse-error',name+' rejection');
    report.cases.push({name,inputBanks:strings,expected,valid,observedType:response.message.type,counters:response.counters});
}
try{
    await run('current sequence admits the second exact row before history admission',[[row('a'),row('b'),row('c')]],{2:3,8:1,20:2,28:1,40:1,92:1,94:1,96:0});
    await run('same sequence different score rejects full tail',[[row('a'),row('b',123,-3)]],{8:0,18:1,20:0,66:1,92:0});
    await run('same sequence different glossary rejects full tail',[[row('a'),row('b',123,-2,['diff'])]],{8:0,18:1,20:0,66:1});
    await run('sequence prefix must include following byte',[[row('a',12),row('b',123)]],{18:0,20:0,65:1});
    await run('null sequences retain owner-only rows',[[row('a',null),row('b',null),row('c',null)]],{8:1,16:0,20:0,37:1});
    await run('zero sequences are outside current-sequence gate',[[row('a',0),row('b',0),row('c',0)]],{8:1,16:0,20:0,37:1});
    await run('exact tail across logical bank boundary',[[row('a')],[row('different-key-length')]],{8:0,20:1,28:1,51:1,92:1});
    const escaped=JSON.stringify([row('a'),row('foo')]).replace('"foo"','"f\\u006fo"');
    await run('escaped key independently validated before shifted tail',[escaped],{20:1,28:1,53:1});
    await run('whole tail must fit current logical bank',[[row('a',123,-2,['x'.repeat(600)])],[row('b',123,-2,['s'])]],{20:0,64:1});
    await run('long glossary already reused by owner model',[[row('a',123,-2,['x'.repeat(600)]),row('b',123,-2,['x'.repeat(600)])]],{20:1,28:1,104:1,92:0,102:0});
    const structured=[{type:'structured-content',content:[{tag:'span',content:'same'}]}];
    await run('nested glossary equality remains a grammar witness',[[row('a',123,-2,structured),row('b',123,-2,structured)]],{20:1,28:1,92:1});
    await run('truncated current bank rejects before observer completion',[[row('a')],JSON.stringify([row('b')]).slice(0,-2)],{},false);
    report.complete=true;
}catch(error){report.failures.push({name:error.name,message:error.message,stack:error.stack});throw error;}
finally{await writeFile(out+'/row-tests.json',JSON.stringify(report,null,2)+'\n');}
process.stdout.write(JSON.stringify({complete:true,cases:report.cases.length})+'\n');
