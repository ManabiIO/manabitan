
/*
 * Diagnostic admission census only. No row parsing or output work is skipped.
 * The exact row-tail predicate and history admission are attributed to
 * Manabitan candidate 399feae29fea358560af27af68f03dfb6d8b6f58.
 * This observer compares a possible additive current-sequence rejection gate
 * on dcfc02a0 without altering that owner's implementation or frozen study.
 */
#define TAIL_CENSUS_WORDS 128u
#define TAIL_NONE 0xffffffffu
static uint32_t tail_stats[TAIL_CENSUS_WORDS];
static uint32_t tail_prev_row_end, tail_prev_score_end, tail_prev_sequence_end, tail_prev_bank_end;
static uint32_t tail_base_budget, tail_owner_budget, tail_union_budget;

static void tail_fail(uint32_t code) {
    if (tail_stats[1] == 0u) { tail_stats[1] = code; }
}

static void tail_census_begin(uint32_t experiment_mask, uint32_t validate_glossary_types) {
    __builtin_memset(tail_stats, 0, sizeof(tail_stats));
    tail_prev_row_end = tail_prev_score_end = tail_prev_sequence_end = tail_prev_bank_end = 0u;
    tail_base_budget = tail_owner_budget = tail_union_budget = 0u;
    if ((experiment_mask & EXPERIMENT_VALIDATED_GLOSSARY_REUSE) == 0u || validate_glossary_types == 0u) { tail_fail(11u); }
}

/* Same bounded suffix predicate as the existing owner, with outcomes exposed.
 * Every result is observational; actual rows remain parsed by current baseline. */
static int tail_equal(
    const uint8_t* src, uint32_t len, uint32_t start, const TermRowMeta* prior,
    uint32_t* length, uint32_t* bounded, uint32_t* sample_pass
) {
    *length = *bounded = *sample_pass = 0u;
    const uint32_t prior_start = prior->definition_tags_start;
    const uint32_t prior_end = skip_ws(src, len, prior->term_tags_start + prior->term_tags_length);
    if (prior_end >= len || src[prior_end] != ']' || prior_start > prior_end) { return 0; }
    *length = prior_end - prior_start + 1u;
    if (start > len || *length > len - start) { return 0; }
    *bounded = 1u;
    const uint32_t sample = *length < 8u ? *length : 8u;
    if (!content_bytes_equal_between(src, start + *length - sample, src, prior_start + *length - sample, sample)) { return 0; }
    *sample_pass = 1u;
    return content_bytes_equal_between(src, start, src, prior_start, *length);
}

static uint32_t model_glossary_witness(
    const uint8_t* src, uint32_t len, const TermRowMeta* rows, uint32_t row,
    uint32_t budget, int suffix_equal
) {
    if (row == 0u) { return TAIL_NONE; }
    if (suffix_equal) { return row - 1u; }
    uint32_t lookback = 0u;
    if (budget > 0u) { lookback = RECENT_CONTENT_DEDUP_WINDOW; }
    else if (rows[row - 1u].glossary_length >= VALIDATED_GLOSSARY_REUSE_MIN_PREVIOUS_BYTES) { lookback = 1u; }
    if (lookback == 0u) { return TAIL_NONE; }
    TermRowMeta dummy;
    uint32_t end = 0u, witness = TAIL_NONE;
    if (reuse_validated_glossary(src, len, rows[row].glossary_start, rows, row,
        &dummy, &end, &witness, lookback)) {
        if (end != rows[row].glossary_start + rows[row].glossary_length) { tail_fail(12u); }
        return witness;
    }
    return TAIL_NONE;
}

static uint32_t next_budget(uint32_t budget, uint32_t witness, uint32_t recent_match, uint32_t streak) {
    if (witness != TAIL_NONE) { budget = VALIDATED_GLOSSARY_REUSE_PROBE_BUDGET; }
    else if (budget > 0u) { --budget; }
    if (recent_match != TAIL_NONE && streak >= VALIDATED_GLOSSARY_REUSE_ADMISSION_MATCHES) {
        budget = VALIDATED_GLOSSARY_REUSE_PROBE_BUDGET;
    }
    return budget;
}

static int check_shift(
    const TermRowMeta* current, const TermRowMeta* prior, uint32_t row_end,
    uint32_t score_end, uint32_t sequence_end, int32_t score, int32_t sequence,
    int32_t prior_score, int32_t prior_sequence, uint32_t unique_id, uint32_t prior_id
) {
    if (current->definition_tags_start < prior->definition_tags_start) { return 0; }
    const uint32_t delta = current->definition_tags_start - prior->definition_tags_start;
    if (row_end != tail_prev_row_end + delta || score_end != tail_prev_score_end + delta ||
        (prior->sequence_start == TAIL_NONE ? sequence_end != 0u : sequence_end != tail_prev_sequence_end + delta) ||
        score != prior_score || sequence != prior_sequence || unique_id != prior_id) { return 0; }
    const uint32_t* a = (const uint32_t*)current;
    const uint32_t* b = (const uint32_t*)prior;
    const uint32_t offsets[] = {4u, 6u, 8u, 9u, 12u};
    const uint32_t lengths[] = {5u, 7u, 10u, 13u, 14u, 15u, 16u};
    for (uint32_t i = 0u; i < 5u; ++i) { if (a[offsets[i]] != b[offsets[i]] + delta) { return 0; } }
    for (uint32_t i = 0u; i < 7u; ++i) { if (a[lengths[i]] != b[lengths[i]]) { return 0; } }
    return a[11] == (b[11] == TAIL_NONE ? TAIL_NONE : b[11] + delta);
}

static void tail_census_observe(
    const uint8_t* src, uint32_t bank_end, const TermRowMeta* rows, uint32_t row,
    uint32_t row_end, uint32_t score_end, uint32_t sequence_end,
    const int32_t* scores, const int32_t* sequences, const uint32_t* unique_ids,
    uint32_t actual_witness, uint32_t recent_match, uint32_t match_streak,
    int owner_admission, uint32_t key_escape_mask
) {
    if (tail_stats[1] != 0u) { return; }
    if (row >= 65536u || bank_end > 64u * 1024u * 1024u) { tail_fail(13u); return; }
    const TermRowMeta* current = &rows[row];
    const uint32_t start = current->definition_tags_start;
    if (row_end > bank_end || start >= row_end || score_end < current->score_start ||
        (current->sequence_start != TAIL_NONE && sequence_end < current->sequence_start)) { tail_fail(1u); return; }
    ++tail_stats[2]; tail_stats[3] += row_end - start;
    const uint32_t score_bytes = score_end - current->score_start;
    const uint32_t sequence_bytes = current->sequence_start == TAIL_NONE ? 0u : sequence_end - current->sequence_start;
    tail_stats[72] += score_bytes; tail_stats[73] += sequence_bytes;
    if (row_end - start > tail_stats[75]) { tail_stats[75] = row_end - start; }
    uint32_t length = 0u, bounded = 0u, sample_pass = 0u;
    int equal = 0, current_gate = 0;
    uint32_t probe_bytes = 0u;
    if (row > 0u) {
        const TermRowMeta* prior = &rows[row - 1u];
        if (tail_prev_row_end > tail_prev_bank_end || tail_prev_bank_end > bank_end ||
            tail_prev_row_end > start) { tail_fail(2u); return; }
        equal = tail_equal(src, bank_end, start, prior, &length, &bounded, &sample_pass);
        if (equal) {
            ++tail_stats[48]; tail_stats[49] += length; tail_stats[50] += current->glossary_length;
            if (!check_shift(current, prior, row_end, score_end, sequence_end, scores[row], sequences[row],
                scores[row - 1u], sequences[row - 1u], unique_ids[row], unique_ids[row - 1u])) { tail_fail(3u); return; }
            if (recent_match == TAIL_NONE) { tail_fail(4u); return; }
        }
        if (sequences[row - 1u] > 0) {
            ++tail_stats[4];
            if (prior->sequence_start == TAIL_NONE || prior->sequence_start < prior->definition_tags_start ||
                tail_prev_sequence_end <= prior->sequence_start || tail_prev_sequence_end >= tail_prev_row_end) { tail_fail(5u); return; }
            const uint32_t offset = prior->sequence_start - prior->definition_tags_start;
            probe_bytes = tail_prev_sequence_end - prior->sequence_start + 1u; /* Include the exact following byte. */
            if (probe_bytes > 11u) { tail_fail(6u); return; }
            if (bounded && offset <= length && probe_bytes <= length - offset) {
                ++tail_stats[16]; tail_stats[17] += probe_bytes;
                if (!owner_admission) { ++tail_stats[80]; tail_stats[81] += probe_bytes; }
                current_gate = content_bytes_equal_between(src, start + offset, src, prior->sequence_start, probe_bytes);
                if (current_gate) { ++tail_stats[18]; if (!owner_admission) { ++tail_stats[82]; } }
                else { ++tail_stats[65]; }
            } else { ++tail_stats[64]; }
        }
    }
    const int owner_win = owner_admission && equal;
    const int current_win = current_gate && equal;
    const int union_win = owner_win || current_win;
    const uint32_t sample = length < 8u ? length : 8u;
    if (owner_admission) {
        ++tail_stats[5];
        if (bounded) { ++tail_stats[6]; tail_stats[45] += sample; }
        if (sample_pass) { ++tail_stats[7]; tail_stats[43] += length; }
        if (!equal) { ++tail_stats[67]; }
    }
    if (current_gate) {
        tail_stats[46] += sample;
        if (sample_pass) { ++tail_stats[19]; tail_stats[44] += length; }
        if (!equal) { ++tail_stats[66]; }
        if (!owner_admission && sample_pass) { tail_stats[83] += length; }
    }
    const uint32_t path = actual_witness != TAIL_NONE ? 1u : (tail_census_glossary_path == 2u ? 2u : 3u);
    ++tail_stats[102u + 2u * path]; tail_stats[103u + 2u * path] += current->glossary_length;
    ++tail_stats[recent_match != TAIL_NONE ? 110u : 111u]; tail_stats[112] += current->glossary_length;
    const uint32_t numeric_values = 1u + (current->sequence_start != TAIL_NONE);
    if (owner_win) {
        ++tail_stats[8]; tail_stats[9] += length; tail_stats[10] += current->glossary_length;
        ++tail_stats[10u + path];
        if (recent_match == TAIL_NONE) { ++tail_stats[14]; } else { ++tail_stats[15]; }
        if (tail_prev_bank_end != bank_end) { ++tail_stats[52]; }
        if (key_escape_mask != 0u) { ++tail_stats[54]; }
        tail_stats[56] += score_bytes; tail_stats[57] += sequence_bytes;
        tail_stats[60] += length - current->glossary_length;
        tail_stats[69] += numeric_values; ++tail_stats[71];
    }
    if (current_win) {
        ++tail_stats[20]; tail_stats[21] += length; tail_stats[22] += current->glossary_length;
        ++tail_stats[22u + path];
        if (recent_match == TAIL_NONE) { ++tail_stats[26]; } else { ++tail_stats[27]; }
        if (tail_prev_bank_end != bank_end) { ++tail_stats[51]; }
        if (key_escape_mask != 0u) { ++tail_stats[53]; }
        tail_stats[58] += score_bytes; tail_stats[59] += sequence_bytes;
        tail_stats[61] += length - current->glossary_length;
        tail_stats[68] += numeric_values; ++tail_stats[70];
    }
    if (current_win && !owner_win) {
        ++tail_stats[28]; tail_stats[29] += length; tail_stats[30] += current->glossary_length;
        ++tail_stats[30u + path];
        tail_stats[34] += score_bytes; tail_stats[35] += sequence_bytes;
        if (recent_match != TAIL_NONE) { ++tail_stats[36]; }
        tail_stats[62] += length - current->glossary_length;
    }
    if (owner_win && !current_win) { ++tail_stats[37]; tail_stats[38] += length; tail_stats[39] += current->glossary_length; }
    if (owner_win && current_win) { ++tail_stats[40]; tail_stats[41] += length; tail_stats[42] += current->glossary_length; }
    const uint32_t baseline = model_glossary_witness(src, bank_end, rows, row, tail_base_budget, 0);
    const uint32_t owner = model_glossary_witness(src, bank_end, rows, row, tail_owner_budget, owner_win);
    const uint32_t combined = model_glossary_witness(src, bank_end, rows, row, tail_union_budget, union_win);
    if (baseline != actual_witness) { tail_fail(7u); return; }
    if ((baseline != TAIL_NONE && owner == TAIL_NONE) || (owner != TAIL_NONE && combined == TAIL_NONE)) { tail_fail(8u); return; }
    if (owner != TAIL_NONE) { ++tail_stats[88]; tail_stats[89] += current->glossary_length; }
    if (combined != TAIL_NONE) { ++tail_stats[90]; tail_stats[91] += current->glossary_length; }
    if (combined != TAIL_NONE && owner == TAIL_NONE) {
        ++tail_stats[92]; tail_stats[93] += current->glossary_length;
        if (union_win) { ++tail_stats[94]; tail_stats[95] += current->glossary_length; }
        else { ++tail_stats[96]; tail_stats[97] += current->glossary_length; }
        if (path == 2u) { ++tail_stats[98]; tail_stats[99] += current->glossary_length; }
        else if (path == 3u) { ++tail_stats[100]; tail_stats[101] += current->glossary_length; }
        else { tail_fail(9u); return; }
    }
    if (current_win && !owner_win && owner == TAIL_NONE) { ++tail_stats[102]; tail_stats[103] += current->glossary_length; }
    tail_base_budget = next_budget(tail_base_budget, baseline, recent_match, match_streak);
    tail_owner_budget = next_budget(tail_owner_budget, owner, recent_match, match_streak);
    tail_union_budget = next_budget(tail_union_budget, combined, recent_match, match_streak);
    tail_prev_row_end = row_end; tail_prev_score_end = score_end;
    tail_prev_sequence_end = sequence_end; tail_prev_bank_end = bank_end;
}

static void tail_census_finish(uint32_t row_count) {
    if (tail_stats[2] != row_count) { tail_fail(10u); }
    tail_stats[0] = tail_stats[1] == 0u;
}

__attribute__((visibility("default")))
uint32_t tail_census_stats_ptr(void) { return (uint32_t)(uintptr_t)tail_stats; }

