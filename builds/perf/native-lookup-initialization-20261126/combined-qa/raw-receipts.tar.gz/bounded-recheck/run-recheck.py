#!/usr/bin/env python3
"""One fixed baseline/candidate recheck; no retries or timeout overrides."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

EVIDENCE = Path(__file__).resolve().parent
STAGE = json.loads((EVIDENCE / 'stage.json').read_text())
LLVM = Path('/workspace/scratch/f34c9c9fae89/toolchains/llvm21')
NODE = Path(STAGE['nodeExecutable'])
TESTS = [
    'test/android/enable-firefox-remote-debugging.test.js',
    'test/term-record-direct-field-columns.test.js',
    'test/term-entry-content-hash.test.js',
    'test/term-bank-crc.test.js',
    'test/term-bank-memory-page.test.js',
]


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def save(name, value):
    path = EVIDENCE / name
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def source_manifest(root):
    return [
        {'path': name, 'sha256': sha256(root / name), 'bytes': (root / name).stat().st_size}
        for name in STAGE['files']
    ]


def environment_receipt():
    def optional_file(path):
        try:
            return {'available': True, 'text': Path(path).read_text()}
        except OSError as error:
            return {'available': False, 'error': str(error)}

    return {
        'recordedAtUtc': now(),
        'loadAverage': list(os.getloadavg()),
        'meminfo': Path('/proc/meminfo').read_text(),
        'cpuPressure': optional_file('/proc/pressure/cpu'),
        'memoryPressure': optional_file('/proc/pressure/memory'),
        'ioPressure': optional_file('/proc/pressure/io'),
        'filesystem': subprocess.check_output(
            ['df', '-B1', str(EVIDENCE), '/tmp'], text=True,
        ),
    }


def report_summary(path):
    if not path.exists():
        return {'available': False}
    report = json.loads(path.read_text())
    files = report.get('testResults', [])
    return {
        'available': True,
        'sha256': sha256(path),
        'success': report.get('success'),
        'total': report.get('numTotalTests'),
        'passed': report.get('numPassedTests'),
        'failed': report.get('numFailedTests'),
        'pending': report.get('numPendingTests'),
        'fileCount': len(files),
        'failedFiles': [
            {
                'name': item['name'],
                'message': item.get('message', ''),
                'assertions': [
                    {key: assertion.get(key) for key in [
                        'fullName', 'status', 'duration', 'failureMessages',
                    ]}
                    for assertion in item.get('assertionResults', [])
                    if assertion.get('status') in ['failed', 'skipped']
                ],
            }
            for item in files if item.get('status') == 'failed'
        ],
    }


def main():
    resume_before_tests = sys.argv[1:] == ['--qa-frozen', '--resume-before-tests']
    if sys.argv[1:] != ['--qa-frozen'] and not resume_before_tests:
        raise SystemExit('Execution requires explicit --qa-frozen after the QA owner releases the slot')
    # A metadata-only preflight continuation is allowed only if no arm began.
    marker = 'started.json'
    if resume_before_tests:
        if not (EVIDENCE / 'preflight-failure.json').exists():
            raise SystemExit('No recorded pre-test failure exists')
        for arm in STAGE['order']:
            for suffix in ['.log', '.json', '-status.json']:
                if (EVIDENCE / (arm + suffix)).exists():
                    raise SystemExit('An arm already began; no second invocation permitted')
        marker = 'continued-before-tests.json'
    # Exclusive creation makes this runner fail closed on any repeat attempt.
    with (EVIDENCE / marker).open('x') as stream:
        json.dump({'startedAtUtc': now(), 'runnerSha256': sha256(__file__)}, stream, indent=2)
        stream.write('\n')

    env = os.environ.copy()
    env['MANABITAN_CLANG'] = str(LLVM / 'usr/lib/llvm-21/bin/clang')
    env['LD_LIBRARY_PATH'] = str(LLVM / 'usr/lib/x86_64-linux-gnu') + (
        ':' + env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else ''
    )
    env['PATH'] = ':'.join([
        STAGE['nodePathEntry'], str(LLVM / 'usr/lib/llvm-21/bin'), env.get('PATH', ''),
    ])
    candidate = Path(STAGE['candidateRoot'])
    provenance = {
        'baselineCommit': STAGE['baselineCommit'],
        'candidateHead': subprocess.check_output(
            ['git', '-C', str(candidate), 'rev-parse', 'HEAD'], text=True,
        ).strip(),
        'candidateStatus': subprocess.check_output(
            ['git', '-C', str(candidate), 'status', '--short'], text=True,
        ),
        'nodeSha256': sha256(NODE),
        'nodeVersion': subprocess.check_output([str(NODE), '--version'], env=env, text=True).strip(),
        'clangVersion': subprocess.check_output([env['MANABITAN_CLANG'], '--version'], env=env, text=True).strip(),
        'lldVersion': subprocess.check_output([str(LLVM / 'usr/lib/llvm-21/bin/wasm-ld'), '--version'], env=env, text=True).strip(),
        'environment': {key: env.get(key) for key in ['PATH', 'LD_LIBRARY_PATH', 'MANABITAN_CLANG', 'NODE_OPTIONS', 'TZ']},
        'testFiles': TESTS,
        'originalEvidence': {
            name: sha256(EVIDENCE.parent / name)
            for name in ['unit-shard-1.log', 'unit-shard-1.json', 'unit-shard-4.log', 'unit-shard-4.json']
        },
        'commandLimits': {'perArmSeconds': 240, 'killGraceSeconds': 10, 'testTimeoutOverrides': False, 'hookTimeoutOverrides': False},
    }
    diff = subprocess.check_output([
        'git', '-C', str(candidate), 'diff', '--binary', STAGE['baselineCommit'], '--', *STAGE['archivePaths'],
    ])
    (EVIDENCE / 'candidate-source.diff').write_bytes(diff)
    provenance['candidateSourceDiffSha256'] = hashlib.sha256(diff).hexdigest()
    save('provenance.json', provenance)

    results = []
    for arm in STAGE['order']:
        root = Path(STAGE[arm + 'Root'])
        report_path = EVIDENCE / (arm + '.json')
        log_path = EVIDENCE / (arm + '.log')
        before = source_manifest(root)
        if arm == 'baseline' and before != json.loads((EVIDENCE / 'baseline-source-manifest.json').read_text()):
            raise SystemExit('Baseline snapshot changed after staging; no test arm executed')
        save(arm + '-source-before.json', before)
        save(arm + '-environment-before.json', environment_receipt())
        command = [
            'timeout', '--signal=TERM', '--kill-after=10s', '240s',
            str(NODE), '--max-old-space-size=2048', 'node_modules/vitest/vitest.mjs',
            'run', *TESTS, '--maxWorkers', '1', '--no-file-parallelism',
            '--reporter', 'default', '--reporter', 'json', '--outputFile', str(report_path),
        ]
        result = {'arm': arm, 'cwd': str(root), 'command': command, 'startedAtUtc': now(), 'status': 'running'}
        save(arm + '-status.json', result)
        print(json.dumps({'arm': arm, 'status': 'running', 'startedAtUtc': result['startedAtUtc']}), flush=True)
        started = time.monotonic()
        with log_path.open('x') as stream:
            completed = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT)
        result.update({
            'completedAtUtc': now(),
            'elapsedSeconds': time.monotonic() - started,
            'exitCode': completed.returncode,
            'status': 'passed' if completed.returncode == 0 else 'outer_timeout' if completed.returncode == 124 else 'failed_or_terminated',
            'logSha256': sha256(log_path),
            'report': report_summary(report_path),
        })
        (EVIDENCE / (arm + '.exit')).write_text(str(completed.returncode) + '\n')
        after = source_manifest(root)
        save(arm + '-source-after.json', after)
        result['sourceStable'] = before == after
        save(arm + '-environment-after.json', environment_receipt())
        save(arm + '-status.json', result)
        results.append(result)
        save('results.json', results)
        print(json.dumps({key: result[key] for key in ['arm', 'status', 'elapsedSeconds', 'exitCode', 'sourceStable', 'report']}), flush=True)


if __name__ == '__main__':
    main()
