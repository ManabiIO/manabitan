# CRC follow-up source screen

This is a bounded read-only review of existing source and measurements. No compiler restoration, candidate edit, benchmark, or new profile was run.

## Decision

Do not repeat the complete #910 candidate on the strength of the current JMdict CRC profile. Its final shipped runtime already has a complete, inconclusive browser screen. The source did not acquire a later unmeasured hardening change of the kind that justified revisiting #830.

The isolated polynomial-power cache inside #910 remains unmeasured as a separate change, but it cannot improve the observed current JMdict route: the helper has zero execution coverage across all 12 actual groups. This is an execution-coverage conclusion for the recorded corpus and three-worker grouping, not a claim that every possible dictionary or grouping has zero benefit.

## Existing candidates

| Existing work                                                                                                  | Exact source/evidence relationship                                                                                                                                                                              | Relevance now                                                                                                                                                                                                                           |
| -------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [#910](https://github.com/ManabiIO/manabitan/pull/910), head `2fe47fa3db04342d04eb4f309c5d74ef45eef9e3`        | The measured product commit is `c2cf7647c67b02474301ed48e54a53205be0f027`. The measured-to-final comparison contains only one test JSDoc annotation; shipped runtime is unchanged.                              | The complete candidate combines broader deferred-CRC admission, contiguous source runs, witness-chain/root work, incremental braided CRC, and the polynomial-power cache. It is already held on its final product source.               |
| [#664](https://github.com/ManabiIO/manabitan/pull/664), merged head `2d3840f574f45210c4eef19d73282404854c3a40` | It bundled cached powers in an earlier CRC matrix representation, adjacent key/colon parsing, and the accepted WebAssembly 64-bit libdeflate word adaptation. Its phase gains do not isolate the CRC subchange. | The current polynomial representation is later code. Reapplying the old matrix implementation would not be a missing final-source qualification of the accepted patch. The current polynomial-table mechanism is already owned by #910. |

The published #910 study reports 69 timing reports, 24 memory observations, and 2,435 process-tree scans. Its paired whole-import medians were JMdict +1.085% versus A / +0.301% versus C; Jitendex -1.186% / -0.792%; VNDB +0.859% / +0.131%. The Jitendex comparison with C crosses zero. Both VNDB memory replications fail the study's fixed coverage requirement, so their qualified peaks remain null; that is not evidence of a measured memory regression. These existing results are retained as reported, not recomputed here.

The measured #910 base was `7d1643e6147a10cb2165e9744cf0e63b59e46632`, rather than current `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. The historical HOLD is therefore not a new current-base timing result. It does, however, remove the premise that #910's final runtime was never screened. No new mechanism or attributable current-work change was found that justifies repeating its complete study.

## Current JMdict coverage

The existing current-baseline compressed diagnostic binds the exact 9e source and pinned parser WebAssembly. It contains 53 banks, 528,299 rows, and 12 production-policy groups. The source totals are 171,617,523 uncompressed bytes and 15,632,849 compressed bytes. Group compression ratios range from 9.3128767858 to 13.7753414451.

Current `inflateCompressedTermBankSourcesWasm` admits deferred CRC reuse only when its other constraints pass and the group compression ratio is at least 32. Every recorded JMdict group fails that ratio condition. All four deferred-work counters sum to zero: `sourceCrcMs`, `sourceCrcScannedBytes`, `sourceCrcReusedBytes`, and `sourceCrcReusedGlossaryCount`.

In current C source:

- Immediate source verification calls `crc32_bytes` in the inflate loop.
- The production call to `crc32_prepare_shift` is inside `verify_term_bank_source_crcs`, the deferred verifier. The additional combination export is test-only.
- #910's 32-entry input-independent power table reduces work in `crc32_prepare_shift`; it does not reduce the immediate source byte scan.
- The exact-symbol diagnostic assigns `crc32_bytes` a 70.306 ms descriptive preceding-delta sampled-stack weight. As the additive [sampling interpretation correction](https://github.com/ManabiIO/manabitan/blob/cf43df9f197b729085950dc9f2f7b3ee7a773e35/builds/perf/20261128-browser-jmdict-profile-83b3/SAMPLING-NOTE.md) explains, this is not a direct on-CPU measurement, a measured saving, or an upper bound for the power-table subchange. For the recorded JMdict policy-3 route, that subchange's affected-call count is zero.

Removing the ratio guard would activate different work, witness storage, and validation scheduling. That belongs to the already screened broader #910 mechanism and cannot be described as qualifying an isolated power cache.

## Remaining uncertainty

An isolated table could still matter on already eligible dictionaries such as VNDB. This review does not establish its call count or cost on the current VNDB path: the earlier local policy-3 receipt was lost during executor recovery, while its published immutable copy remains available. No corpus was rerun or downloaded for this follow-up. The previous whole-import HOLD does not mathematically disprove a useful isolated subchange, but the current JMdict attribution supplies no reason to pursue it now.

## Retained evidence

- [Current JMdict coverage and source hashes](current-jmdict-coverage.json), derived only from the already completed diagnostic.
- [Exact measured-to-final #910 comparison](measured-to-final-910-compare.json).
- [#910 metadata](upstream-pr-910.json) and [source diff](upstream-910-files.json).
- [#664 metadata](upstream-pr-664.json) and [source diff](upstream-664-files.json).
- Original current diagnostic: sibling `20261128-compressed-worker-profile-83b3/raw/result.json.txt`, SHA-256 `de935a5a20ee5a37b6841e359bb0cc5947de57ae943ed0d0f138e88f20f03189`.
- Original derived attribution: sibling `20261128-compressed-worker-profile-83b3/attribution.json.txt`, SHA-256 `e9db22976cb70a81be3bb39c0a04d44ab2fb5fb0c0c525c8208691d27a19f318`.

No runtime change is proposed by this review.
