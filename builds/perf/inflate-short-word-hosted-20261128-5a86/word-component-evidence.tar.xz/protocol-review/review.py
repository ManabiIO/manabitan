#!/usr/bin/env python3
"""Read original short-word receipts only; never run a decoder or controller."""
import copy
import datetime
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import zipfile

BASELINE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
CANDIDATE = '49bf79f35084e7c42d1088d5d30c522172d8ec3b'
TREE = 'af9a3630ab5acc04ec82023fc40d30b249983182'
REPO = Path('/workspace/scratch/5a86d1e7822a/short-word-hosted')
ORIGINALS = REPO / 'test/perf/inflate-short-word-20261128-5a86'
ARTIFACT = Path('/home/agent/manabitan-short-word-hosted-5a86/component')
EXTRACT = ARTIFACT / 'extract'
REMOTE = Path('/home/agent/manabitan-short-word-validation-prior-review-5a86/remote-git-commit.json')
OUT = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': sha(raw)}


def valid_time(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value >= 0


def main():
    require(__debug__, 'Assertions-disabled review is not permitted')
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    require(identity(ARTIFACT / 'artifact.zip') == {'bytes': 375497, 'sha256': 'baf07612795ba49af3294f4f92698ec7c1ad49c358ac738e20da6ee681cd89f7'}, 'original artifact identity')
    metadata = read_json(ARTIFACT / 'artifact-metadata.json')
    require(metadata['id'] == 15255017646 and metadata['name'] == 'inflate-short-word-component-5a86', 'artifact registration')
    require(metadata['digest'] == 'sha256:' + identity(ARTIFACT / 'artifact.zip')['sha256'], 'artifact digest metadata')
    require(metadata['workflow_run']['id'] == 46112380632 and metadata['workflow_run']['head_sha'] == CANDIDATE, 'artifact source run')
    archive_members = []
    with zipfile.ZipFile(ARTIFACT / 'artifact.zip') as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)), 'duplicate original artifact member')
        require(set(names) == {str(path.relative_to(EXTRACT)) for path in EXTRACT.rglob('*') if path.is_file()}, 'original extraction set')
        for name in names:
            require(not Path(name).is_absolute() and '..' not in Path(name).parts, 'unsafe member')
            data = archive.read(name)
            require(data == (EXTRACT / name).read_bytes(), 'original extraction bytes ' + name)
            archive_members.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
    require(identity(ARTIFACT / 'job.log')['sha256'] == 'b8b8f3692cbcbce0115e52fa755dc9204a0467791349607050cddb98370db865', 'original full job log')
    require(identity(REMOTE) == {'bytes': 1468, 'sha256': '45543c07c0bcb0a9217c7f4b51a15714dedc4e952f4d79d259ec359b407c3c49'}, 'recovered remote commit response')
    remote = read_json(REMOTE)
    require(remote['sha'] == CANDIDATE and remote['tree']['sha'] == TREE and [p['sha'] for p in remote['parents']] == [BASELINE], 'remote source mapping')
    require(git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE, 'independent local exact candidate tree')
    require(git('status', '--porcelain').decode().strip() == '', 'local proof checkout is clean')

    invocation = read_json(EXTRACT / 'invocation.json')
    original_plan = read_json(EXTRACT / 'original-plan.json')
    plan = read_json(EXTRACT / 'observer/plan.json')
    manifest = read_json(EXTRACT / 'observer/observer-manifest.json')
    report = read_json(EXTRACT / 'cohort/report.json')
    oracle = read_json(EXTRACT / 'oracle.json')
    require(identity(EXTRACT / 'cohort/report.json')['sha256'] == 'e99329f0eb72e0820f906415f4723639fc1f57513d0be463df734ce5058c2d1a', 'original report SHA')
    require(identity(EXTRACT / 'oracle.json')['sha256'] == '13ff5b6484b39637b61195578f1a505f1abdbb78ec5511d9978169f30a6062c3', 'new oracle SHA')
    require(invocation['status'] == 'complete' and invocation['baseline'] == BASELINE and invocation['candidate'] == CANDIDATE, 'complete registered invocation')
    require(invocation['host']['githubRunId'] == '46112380632' and invocation['host']['githubRunAttempt'] == '1', 'single original attempt')
    require(invocation['reportSha256'] == identity(EXTRACT / 'cohort/report.json')['sha256'], 'invocation report binding')
    require(invocation['sourceIdentity']['candidateTree'] == TREE, 'candidate tree receipt')
    require(plan['sources']['A'] == plan['sources']['C'], 'same source control')
    require(plan['sources']['A']['commit'] == BASELINE and plan['sources']['B']['commit'] == CANDIDATE, 'arm mapping')
    require(plan['nodeVersion'] == 'v22.22.0' and plan['nodeExecutableSha256'] == '1bec56ef7cfa9a76f3e0b7c0a87f220eb73f23102b9c0b4c7529a3f7c3ce7c31', 'pinned runtime')
    source_bindings = []
    for arm in ('A', 'B'):
        revision = BASELINE if arm == 'A' else TREE
        source = plan['sources'][arm]
        require(source['tree'] == git('rev-parse', revision + '^{tree}').decode().strip(), 'arm tree')
        for path, expected in source['files'].items():
            tracked = 'dev/data/dictionary-wasm/term-bank-parser.wasm' if path == 'ext/lib/term-bank-parser.wasm' else path
            raw = git('show', revision + ':' + tracked)
            require(sha(raw) == expected, 'independent source file ' + arm + ':' + path)
            source_bindings.append({'arm': arm, 'path': path, 'trackedPath': tracked, 'bytes': len(raw), 'sha256': sha(raw)})
    for path, expected in invocation['sourceIdentity']['productHashes'].items():
        require(sha(git('show', TREE + ':' + path)) == expected, 'product/test binding ' + path)
        require(git('show', TREE + ':' + path) == git('show', '7bf2f889a94d955bf8845b9f8d9e2d4afb464617:' + path), 'original product tree ' + path)
    for path, expected in invocation['sourceIdentity']['frozenHashes'].items():
        require(sha(git('show', TREE + ':' + path)) == expected and git('show', TREE + ':' + path) == git('show', BASELINE + ':' + path), 'unchanged shared harness ' + path)
    for path in ('test/perf/inflate-short-word-20261128-5a86/driver.py', 'dev/perf/inflate-short-word-screen-5a86.py', '.github/workflows/inflate-short-word-screen-5a86.yml'):
        require((REPO / path).read_bytes() == git('show', TREE + ':' + path), 'reviewed code matches Git ' + path)

    local_index = read_json(ORIGINALS / 'local-evidence-manifest.json.txt')
    require(identity(ORIGINALS / 'local-evidence-manifest.json.txt')['sha256'] == invocation['originalEvidence']['indexSha256'], 'local historical index')
    require(local_index['archive'] == invocation['originalEvidence']['archive'], 'local historical archive record')
    require(identity(ORIGINALS / 'local-evidence.tar.gz')['sha256'] == local_index['archive']['sha256'], 'local historical archive bytes')
    originals = {}
    with tarfile.open(ORIGINALS / 'local-evidence.tar.gz') as archive:
        for kind, record in local_index['componentInputs'].items():
            raw = archive.extractfile(record['member']).read()
            require(len(raw) == record['bytes'] and sha(raw) == record['sha256'], 'original protocol input ' + kind)
            originals[kind] = raw
        historical_failure = json.loads(archive.extractfile('original-component/failed-cohort/report.json').read())
        historical_outer = json.loads(archive.extractfile('original-component/failed-cohort/controller-receipt.json').read())
        require(historical_failure['complete'] is False and historical_failure['observations'] == [], 'failed local cohort is still zero-child')
    require(originals['plan'] == (EXTRACT / 'original-plan.json').read_bytes(), 'exact original plan')
    require(originals['controller'] == (EXTRACT / 'original-run.py.txt').read_bytes(), 'exact original controller')
    require(originals['observer'] == (EXTRACT / 'observe.mjs').read_bytes() == (EXTRACT / 'observer/observe.mjs').read_bytes(), 'exact original observer')
    require(sha(originals['observer']) == '4bd1085be4fd16cc5e5246be3682bcabfdb546331afb4d5ce123084a9f37a4e4', 'observer pin')
    require(sha(originals['controller']) == '6740a59f94254e2d0060f094993c818f73a472fd9b7be96deceaa13139274c92', 'controller pin')
    require(sha(originals['plan']) == '1ae467eaa524b3aa71d25463fab594379d6d2ee607294bfb351cdde266eee802', 'plan pin')
    text = originals['controller'].decode()
    needle = 'sha = lambda data: hashlib.sha256(data).hexdigest()'
    insertion = needle + "\n\ndef file_sha(filename):\n    digest = hashlib.sha256()\n    with Path(filename).open('rb') as source:\n        for block in iter(lambda: source.read(1024 * 1024), b''):\n            digest.update(block)\n    return digest.hexdigest()\n"
    require(text.count(needle) == 1, 'single hash helper insertion')
    text = text.replace(needle, insertion)
    substitutions = {
        "sha((HERE / 'observer-manifest.json').read_bytes())": "file_sha(HERE / 'observer-manifest.json')",
        'sha((HERE / name).read_bytes())': 'file_sha(HERE / name)',
        "sha(Path(plan['oracle']['path']).read_bytes())": "file_sha(Path(plan['oracle']['path']))",
        "sha(Path(plan['nodeExecutable']).read_bytes())": "file_sha(Path(plan['nodeExecutable']))",
        "sha((Path(source['root']) / name).read_bytes())": "file_sha(Path(source['root']) / name)",
        "sha((out / (label + '.log')).read_bytes())": "file_sha(out / (label + '.log'))",
    }
    for before, after in substitutions.items():
        require(text.count(before) == 1, 'single permitted hashing replacement')
        text = text.replace(before, after)
    require(text.encode() == (EXTRACT / 'observer/run.py').read_bytes(), 'hosted controller changes only six unmeasured hashes and helper')
    restored = copy.deepcopy(plan)
    restored['nodeExecutable'] = original_plan['nodeExecutable']
    restored['fixture']['path'] = original_plan['fixture']['path']
    restored['oracle'] = original_plan['oracle']
    for arm in 'ABC':
        for field in ('root', 'commit', 'tree'):
            restored['sources'][arm][field] = original_plan['sources'][arm][field]
    require(restored == original_plan, 'plan adaptation outside exact allowed identities')
    require(plan['oracle'] == invocation['newHostedOracle'] and plan['oracle']['sha256'] == identity(EXTRACT / 'oracle.json')['sha256'], 'new oracle binding')
    require(set(manifest['files']) == {'observe.mjs', 'run.py', 'plan.json'}, 'manifest file allowlist')
    for name, expected in manifest['files'].items():
        require(identity(EXTRACT / 'observer' / name)['sha256'] == expected, 'hosted manifest ' + name)
    manifest_sha = identity(EXTRACT / 'observer/observer-manifest.json')['sha256']
    require(manifest_sha == invocation['hostedObserver']['manifestSha256'] == report['manifestSha256'], 'manifest chain')
    plan_sha = manifest['files']['plan.json']
    require(report['plan'] == plan and report['planSha256'] == plan_sha, 'report complete plan binding')

    require(oracle['complete'] is True and oracle['noNativeCensusCounts'] is True, 'new oracle completion and scope')
    require(oracle['originalNativeCensusUnavailableSha256'] == original_plan['oracle']['sha256'], 'missing old oracle disclosed')
    require(oracle['archive'] == {k: plan['fixture'][k] for k in ('sha256', 'bytes')}, 'oracle input archive binding')
    require(len(oracle['banks']) == 53, 'all oracle banks')
    bank_by_name = {}
    for index, bank in enumerate(oracle['banks'], 1):
        require(bank['filename'] == f'term_bank_{index}.json', 'ordered unique oracle bank')
        require(bank['eof'] is True and bank['unusedInputBytes'] == bank['unconsumedInputBytes'] == 0, 'exact independent oracle consumption')
        require(bank['consumedCompressedBytes'] == bank['compressedBytes'] > 0 and bank['decodedBytes'] > 0, 'oracle lengths')
        require(0 <= bank['crc32'] <= 0xffffffff, 'oracle CRC')
        require(all(re.fullmatch('[a-f0-9]{64}', bank[key]) for key in ('compressedSha256', 'decodedSha256')), 'full oracle SHA identities')
        bank_by_name[bank['filename']] = bank
    require(sum(b['decodedBytes'] for b in oracle['banks']) == 171617523 and sum(b['compressedBytes'] for b in oracle['banks']) == 15632849, 'all-corpus oracle totals')
    require([name for group in plan['groups'] for name in group] == list(bank_by_name), 'exact group coverage')
    expected_groups = [{'groupIndex': index, 'firstBank': names[0], 'lastBank': names[-1], 'bankCount': len(names),
        'decodedBytes': sum(bank_by_name[name]['decodedBytes'] for name in names),
        'compressedBytes': sum(bank_by_name[name]['compressedBytes'] for name in names)} for index, names in enumerate(plan['groups'])]
    require(len(expected_groups) == 12, 'production group count')
    require(plan['orders'] == ['ABC', 'ACB', 'BAC', 'BCA', 'CAB', 'CBA'] * 2 and plan['freshProcesses'] == 36, 'fixed balanced schedule')
    require(plan['sweeps'] == {'cold': 1, 'postcold': 4, 'selectiveDiscard': False, 'steadyStateClaim': False}, 'fixed five sweeps')
    expected_slots = [(block + 1, order, arm) for block, order in enumerate(plan['orders']) for arm in order]
    require(report['complete'] is True and report['failure'] is None and len(report['observations']) == 36, 'all successful original children')
    require(len(list((EXTRACT / 'cohort').glob('*.json'))) == 37 and len(list((EXTRACT / 'cohort').glob('*.log'))) == 36, 'no missing/extra/replacement child files')
    digests, pids, heap_shapes = set(), set(), set()
    child_bindings = []
    controller_lines = [json.loads(line) for line in (EXTRACT / 'controller.log').read_text().splitlines()]
    require(len(controller_lines) == 37, 'controller emits exactly36 original completions plus summary')
    for slot_index, (receipt, slot) in enumerate(zip(report['observations'], expected_slots)):
        block, order, arm = slot
        label = f'{block:02d}-{arm}'
        require((receipt['block'], receipt['order'], receipt['arm']) == slot, 'fixed slot ' + label)
        require(receipt['exitCode'] == 0 and receipt['signal'] is None and 'rawParseError' not in receipt, 'successful unchanged child ' + label)
        expected_command = [plan['nodeExecutable'], str(Path(plan['oracle']['path']).parent / 'observer/observe.mjs'), str(Path(plan['oracle']['path']).parent / 'observer/plan.json'), plan_sha, arm, str(Path(plan['oracle']['path']).parent / 'cohort' / (label + '.json'))]
        require(receipt['command'] == expected_command, 'exact unflagged invocation ' + label)
        raw_bytes = (EXTRACT / 'cohort' / (label + '.json')).read_bytes()
        log_bytes = (EXTRACT / 'cohort' / (label + '.log')).read_bytes()
        require(sha(raw_bytes) == receipt['rawSha256'] and sha(log_bytes) == receipt['logSha256'], 'raw output/log binding ' + label)
        raw = json.loads(raw_bytes)
        require(raw == receipt['raw'], 'no report substitution ' + label)
        require(raw['complete'] is True and raw['arm'] == arm and raw['source'] == plan['sources'][arm], 'child complete exact source')
        require(raw['node'] == plan['nodeVersion'] and raw['planSha256'] == plan_sha and raw['observerSha256'] == plan['observerSha256'] and raw['oracleSha256'] == plan['oracle']['sha256'] and raw['archiveSha256'] == plan['fixture']['sha256'], 'child input identity')
        require(raw['boundary'] == plan['boundary'], 'timed boundary identity')
        require(raw['pid'] not in pids, 'fresh process identity')
        pids.add(raw['pid'])
        require(len(raw['sweeps']) == 5, 'all sweeps')
        for index, sweep in enumerate(raw['sweeps']):
            require(sweep['index'] == index and sweep['kind'] == ('cold-first-complete-decode' if index == 0 else 'postcold-prescribed-sweep'), 'sweep identity')
            require(sweep['decodedBytes'] == 171617523 and len(sweep['groups']) == 12, 'sweep complete corpus')
            require(all(valid_time(sweep[key]) for key in ('callElapsedMs', 'sourceInflateMs', 'cpuTotalMs', 'cpuUserMicros', 'cpuSystemMicros')), 'finite nonnegative clocks')
            require(sweep['callElapsedMs'] >= sweep['sourceInflateMs'] and sweep['cpuTotalMs'] == (sweep['cpuUserMicros'] + sweep['cpuSystemMicros']) / 1000, 'clock boundaries')
            for key in ('callElapsedMs', 'sourceInflateMs', 'cpuUserMicros', 'cpuSystemMicros'):
                require(sweep[key] == sum(group[key] for group in sweep['groups']), 'exact group sum ' + key)
            for actual, expected in zip(sweep['groups'], expected_groups):
                require({k: actual[k] for k in expected} == expected, 'exact group content boundaries')
            require(sweep['maxNativeHeapBytes'] == max(g['heapBytes'] for g in sweep['groups']), 'heap maximum')
            digests.add(sweep['digest'])
        heap_shapes.add(tuple(tuple(group['heapBytes'] for group in sweep['groups']) for sweep in raw['sweeps']))
        log = json.loads(log_bytes)
        require(log == {'arm': arm, 'complete': True, 'digest': raw['sweeps'][0]['digest'], 'callElapsedMs': [s['callElapsedMs'] for s in raw['sweeps']], 'sourceInflateMs': [s['sourceInflateMs'] for s in raw['sweeps']]}, 'complete child stdout')
        require(controller_lines[slot_index] == {'slot': label, 'complete': True, 'callElapsedMs': [s['callElapsedMs'] for s in raw['sweeps']]}, 'controller ordered completion')
        child_bindings.append({'slot': label, 'pid': raw['pid'], 'rawSha256': sha(raw_bytes), 'logSha256': sha(log_bytes)})
    require(len(digests) == len(heap_shapes) == 1 and len(pids) == 36, 'all-arm output and heap parity')
    require(controller_lines[-1] == {'complete': True, 'summary': report['summary']}, 'final summary log binding')
    require(len(invocation['commands']) == 6, 'one fixture/two checkout-build/one controller invocation')
    require([item['label'] for item in invocation['commands']] == ['prepare-fixture', 'checkout-A', 'build-libs-A', 'checkout-B', 'build-libs-B', 'controller'], 'no command retry')
    for command in invocation['commands']:
        require(command['status'] == 'complete' and command['exitCode'] == 0 and command['signal'] is None, 'command complete')
        require(identity(EXTRACT / (command['label'] + '.log'))['sha256'] == command['logSha256'], 'command log original')
    require(invocation['commands'][-1]['command'][-2] == manifest_sha, 'controller frozen manifest command')
    require(set(report['continuationChecks']) == {'candidateMedianWallAgainstBoth', 'candidateEqualWorkWallAgainstBoth', 'candidateMedianCpuAgainstBoth', 'candidateFasterBlocksAgainstBoth', 'sameCodeMedianWallDrift', 'sameCodeMedianCpuDrift', 'coldWallAgainstBoth'}, 'exact seven continuation guards')
    require(all(type(value) is bool for value in report['continuationChecks'].values()), 'literal guard booleans')
    require(report['eligibleForHostedScreen'] == all(report['continuationChecks'].values()) == invocation['eligibleForBrowserScreen'] is False, 'failed eligibility stays false')
    jobs = read_json(ARTIFACT / 'final-jobs.json')['jobs']
    require([(job['id'], job['conclusion']) for job in jobs] == [(140878598879, 'success'), (140903680352, 'success'), (140915280648, 'skipped')], 'no expanded browser acquisition')
    workflow = (REPO / '.github/workflows/inflate-short-word-screen-5a86.yml').read_text()
    require("if: ${{ needs.validate.result == 'success' && needs.component.result == 'success' && needs.component.outputs.eligible == 'true' }}" in workflow, 'workflow triple eligibility guard')
    native = git('show', TREE + ':ext/js/dictionary/wasm/term-bank-inflate.c').decode()
    require('if (consumed != input_length) { return -6; }' in native and 'if (produced != output_length) { return -3; }' in native, 'native exact input/output guard source')
    result = {
        'status': 'PASS', 'scope': 'Independent read-only source/oracle/controller/raw-receipt audit of the single original hosted component. No decoder, product, controller or acquisition executed.',
        'startedUtc': started, 'completedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'reviewerScript': identity(Path(__file__)), 'originalArtifact': metadata,
        'originalJobLog': identity(ARTIFACT / 'job.log'), 'originalReport': identity(EXTRACT / 'cohort/report.json'),
        'sourceProof': {'remoteCommitResponse': identity(REMOTE), 'remoteCommit': CANDIDATE, 'candidateTree': TREE, 'localSameTreeCommit': git('rev-parse', 'HEAD').decode().strip(), 'bindings': source_bindings},
        'originalProtocol': {kind: {'bytes': len(raw), 'sha256': sha(raw)} for kind, raw in originals.items()},
        'adaptation': {'controller': identity(EXTRACT / 'observer/run.py'), 'onlySixUnmeasuredHashReplacementsAndOneStreamingHelper': True, 'onlyPlanChanges': ['host paths', 'hosted candidate commit/tree', 'new independent oracle identity/scope'], 'newOracle': identity(EXTRACT / 'oracle.json')},
        'rawCounts': {'archiveMembers': len(archive_members), 'children': 36, 'freshPids': len(pids), 'completeSweeps': 180, 'groupCalls': 2160, 'verifiedBankOutputs': 9540, 'banksPerSweep': 53, 'groupsPerSweep': 12, 'decodedBytesPerSweep': 171617523, 'compressedBytesPerSweep': 15632849},
        'outputDigest': next(iter(digests)), 'allNativeHeapShapesEqual': True, 'nativeHeapShapeBytes': next(iter(heap_shapes)),
        'newOracleChecks': {'complete': True, 'all53CompressedAndDecodedSha256': True, 'all53SizeCrcAndExactConsumption': True, 'noOriginalNativeCensusCountsRecreated': True},
        'continuationChecksAsRecorded': report['continuationChecks'], 'eligibleForBrowserScreen': False, 'browserJobConclusion': 'skipped',
        'originalLocalFailure': {'disposition': invocation['originalLocalCohort'], 'rawReport': historical_failure, 'rawOuterReceipt': historical_outer},
        'limitations': ['No decoder or output bytes were regenerated. Per-bank output SHA/CRC/span checks are proved by the exact frozen observer and its successful original receipts; decoded corpus bytes are not retained in this component artifact.', 'Oracle compressed-input/decoded-output hashes and exact-consumption flags are the newly generated hosted Python-zlib oracle, not the unavailable original native census.', 'Per-host browser memory and complete-import behavior were not acquired because the frozen component eligibility failed.', 'Independent numerical recomputation of all clocks, tails and seven criteria is owned by the separate prior-work reviewer.'],
        'children': child_bindings, 'originalArchiveMembers': archive_members,
    }
    (OUT / 'review.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'counts': result['rawCounts'], 'eligible': False, 'review': identity(OUT / 'review.json')}, sort_keys=True))


if __name__ == '__main__':
    main()
