#!/usr/bin/env python3
"""Read-only independent recomputation of the frozen short-word component.

This program reads an already acquired original artifact. It never imports the
artifact's Python/JavaScript modules and never runs the benchmark or product.
"""
import hashlib
import json
import math
from fractions import Fraction
from pathlib import Path, PurePosixPath
import sys
import zipfile

if not __debug__:
    raise SystemExit('Assertions must remain enabled for this evidence review.')

ROOT = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
OUT.mkdir(parents=True, exist_ok=True)
EXPECTED = {
    'artifact.zip': (375497, 'baf07612795ba49af3294f4f92698ec7c1ad49c358ac738e20da6ee681cd89f7'),
    'job.log': (294528, 'b8b8f3692cbcbce0115e52fa755dc9204a0467791349607050cddb98370db865'),
    'cohort/report.json': (1481911, 'e99329f0eb72e0820f906415f4723639fc1f57513d0be463df734ce5058c2d1a'),
    'original-run.py.txt': (10732, '6740a59f94254e2d0060f094993c818f73a472fd9b7be96deceaa13139274c92'),
    'original-plan.json': (11776, '1ae467eaa524b3aa71d25463fab594379d6d2ee607294bfb351cdde266eee802'),
    'observe.mjs': (10088, '4bd1085be4fd16cc5e5246be3682bcabfdb546331afb4d5ce123084a9f37a4e4'),
    'observer/run.py': (10907, 'ee912b5a882fea92dac977355294f7b4219002e3ce155993377bb8bed6ad7871'),
    'observer/plan.json': (11813, 'e67a399d8080a176fcee19d4163643669536be91d994310ca63c4f47d712cf58'),
    'observer/observe.mjs': (10088, '4bd1085be4fd16cc5e5246be3682bcabfdb546331afb4d5ce123084a9f37a4e4'),
    'observer/observer-manifest.json': (274, 'b7eaf145e0641e8b0bbaa1040a3dc6a386b1f5422e90abee4afee9d2f5263b91'),
    'oracle.json': (24318, '13ff5b6484b39637b61195578f1a505f1abdbb78ec5511d9978169f30a6062c3'),
    'invocation.json': (11932, '428f3a789ca9ad708efb5e6b8c11e996f9d24a278df19efc434e2325bbfd554c'),
}
ORDERS = ['ABC', 'ACB', 'BAC', 'BCA', 'CAB', 'CBA'] * 2
PAIRS = ('BA', 'BC', 'CA')
CLOCKS = ('callElapsedMs', 'sourceInflateMs', 'cpuTotalMs', 'cpuUserMs', 'cpuSystemMs')
ORIGINAL_CLOCKS = CLOCKS[:3]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def identity(data):
    return {'bytes': len(data), 'sha256': sha(data)}

def save(name, value):
    data = (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()
    (OUT / name).write_bytes(data)
    return identity(data)

def median(values):
    values = sorted(values)
    size = len(values)
    assert size > 0
    return values[size // 2] if size % 2 else (values[size // 2 - 1] + values[size // 2]) / 2

def mean(values):
    # Independent exact summation, matching the frozen mean's one final rounding.
    values = list(values)
    assert values
    return float(sum((Fraction(value) for value in values), Fraction()) / len(values))

def percent(numerator, denominator):
    return 100 * (numerator / denominator - 1) if denominator != 0 else None

def clock_value(sweep, clock):
    if clock == 'cpuUserMs':
        return sweep['cpuUserMicros'] / 1000
    if clock == 'cpuSystemMs':
        return sweep['cpuSystemMicros'] / 1000
    return sweep[clock]

artifact = (ROOT / 'artifact.zip').read_bytes()
job_log = (ROOT / 'job.log').read_bytes()
for name, data in [('artifact.zip', artifact), ('job.log', job_log)]:
    assert (len(data), sha(data)) == EXPECTED[name], name
with zipfile.ZipFile(ROOT / 'artifact.zip') as archive:
    entries = archive.infolist()
    assert len(entries) == 88 and len({entry.filename for entry in entries}) == 88
    raw_members = {}
    for entry in entries:
        name = PurePosixPath(entry.filename)
        assert not entry.is_dir() and not name.is_absolute() and '..' not in name.parts
        data = archive.read(entry)
        assert (ROOT / 'extract' / entry.filename).read_bytes() == data, entry.filename
        raw_members[entry.filename] = data
for name, expected in EXPECTED.items():
    if name not in ('artifact.zip', 'job.log'):
        assert (len(raw_members[name]), sha(raw_members[name])) == expected, name

report = json.loads(raw_members['cohort/report.json'])
plan = json.loads(raw_members['observer/plan.json'])
original_plan = json.loads(raw_members['original-plan.json'])
manifest = json.loads(raw_members['observer/observer-manifest.json'])
invocation = json.loads(raw_members['invocation.json'])
assert report['complete'] is True and report['failure'] is None
assert invocation['status'] == 'complete'
assert invocation['reportSha256'] == sha(raw_members['cohort/report.json'])
assert report['plan'] == plan
assert report['planSha256'] == sha(raw_members['observer/plan.json'])
assert report['manifestSha256'] == sha(raw_members['observer/observer-manifest.json'])
assert manifest['files'] == {name: sha(raw_members['observer/' + name]) for name in ('observe.mjs', 'run.py', 'plan.json')}
for key in ('orders', 'freshProcesses', 'sweeps', 'summaryRule', 'continuation', 'completionRule', 'policy', 'groups'):
    assert plan[key] == original_plan[key], key
assert plan['orders'] == ORDERS and plan['freshProcesses'] == 36
assert plan['sweeps'] == {'cold': 1, 'postcold': 4, 'selectiveDiscard': False, 'steadyStateClaim': False}
assert plan['nodeVersion'] == 'v22.22.0'
assert plan['policy']['options'] == {} and plan['policy']['componentExecutionConcurrency'] == 1
assert plan['policy']['sourceBankCount'] == 53 and plan['policy']['sourceBytes'] == 171617523
assert plan['policy']['compressedBytes'] == 15632849
assert plan['sources']['A'] == plan['sources']['C']
assert plan['sources']['A']['commit'] == '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
assert plan['sources']['B']['commit'] == '49bf79f35084e7c42d1088d5d30c522172d8ec3b'
criteria = plan['continuation']
assert criteria['minimumPairedWallImprovementPercent'] == 2
assert criteria['minimumFasterBlocks'] == 9
assert criteria['maximumSameCodeMedianDriftPercent'] == 2
assert criteria['maximumColdMedianRegressionPercent'] == 5
assert criteria['candidateEqualWorkWallAgainstBoth'] == 'negative'
assert criteria['candidateMedianCpuAgainstBoth'] == 'negative'
assert criteria['allCorrectnessAndSourceGates'] == 'required'

observations = report['observations']
assert len(observations) == 36
expected_slots = [(block, arm, order) for block, order in enumerate(ORDERS, 1) for arm in order]
assert [(o['block'], o['arm'], o['order']) for o in observations] == expected_slots
expected_child_names = {f'cohort/{block:02d}-{arm}.{ext}' for block, arm, _ in expected_slots for ext in ('json', 'log')}
assert {name for name in raw_members if name.startswith('cohort/')} == expected_child_names | {'cohort/report.json'}
by_block = {}
raw_values = []
digests = set()
heap_shapes = set()
for observation in observations:
    block, arm = observation['block'], observation['arm']
    raw_name = f'cohort/{block:02d}-{arm}.json'
    log_name = f'cohort/{block:02d}-{arm}.log'
    assert observation['exitCode'] == 0 and observation['signal'] is None
    assert observation['rawSha256'] == sha(raw_members[raw_name])
    assert observation['logSha256'] == sha(raw_members[log_name])
    raw = json.loads(raw_members[raw_name])
    assert observation['raw'] == raw
    assert raw['complete'] is True and raw['arm'] == arm
    assert raw['node'] == plan['nodeVersion']
    assert raw['planSha256'] == report['planSha256']
    assert raw['observerSha256'] == plan['observerSha256'] == sha(raw_members['observe.mjs'])
    assert raw['source'] == plan['sources'][arm]
    assert raw['archiveSha256'] == plan['fixture']['sha256']
    assert raw['oracleSha256'] == sha(raw_members['oracle.json'])
    assert len(raw['sweeps']) == 5
    for index, sweep in enumerate(raw['sweeps']):
        assert sweep['index'] == index
        assert sweep['kind'] == ('cold-first-complete-decode' if index == 0 else 'postcold-prescribed-sweep')
        assert len(sweep['groups']) == 12
        assert sweep['decodedBytes'] == 171617523
        assert sweep['decodedBytes'] == sum(group['decodedBytes'] for group in sweep['groups'])
        assert sum(group['bankCount'] for group in sweep['groups']) == 53
        assert sum(group['compressedBytes'] for group in sweep['groups']) == 15632849
        assert [group['groupIndex'] for group in sweep['groups']] == list(range(12))
        for clock in ('callElapsedMs', 'sourceInflateMs', 'cpuUserMicros', 'cpuSystemMicros'):
            assert sweep[clock] == sum(group[clock] for group in sweep['groups']), (block, arm, index, clock)
        assert sweep['cpuTotalMs'] == (sweep['cpuUserMicros'] + sweep['cpuSystemMicros']) / 1000
        values = {clock: clock_value(sweep, clock) for clock in CLOCKS}
        assert all(math.isfinite(value) and value >= 0 for value in values.values())
        assert all(values[clock] > 0 for clock in CLOCKS[:3])
        digests.add(sweep['digest'])
        raw_values.append({'block': block, 'arm': arm, 'order': observation['order'], 'sweep': index,
                           'rawMember': raw_name, 'rawSha256': observation['rawSha256'], 'valuesMs': values})
    heap_shapes.add(tuple(tuple(group['heapBytes'] for group in sweep['groups']) for sweep in raw['sweeps']))
    by_block.setdefault(block, {})[arm] = raw['sweeps']
assert len(digests) == 1 and len(heap_shapes) == 1

def aggregate(clock, sweep):
    values = []
    for block in range(1, 13):
        arms = {}
        for arm in 'ABC':
            sweeps = by_block[block][arm]
            arms[arm] = (clock_value(sweeps[sweep], clock) if sweep is not None else
                         mean(clock_value(value, clock) for value in sweeps[1:]))
        values.append({'block': block, 'values': arms})
    result = {}
    for pair in PAIRS:
        tail = []
        for value in values:
            numerator, denominator = value['values'][pair[0]], value['values'][pair[1]]
            tail.append({'block': value['block'], 'numeratorMs': numerator, 'denominatorMs': denominator,
                         'differenceMs': numerator - denominator, 'percent': percent(numerator, denominator)})
        undefined = [entry['block'] for entry in tail if entry['percent'] is None]
        result[pair] = {
            'pairedMedianPercent': None if undefined else median(entry['percent'] for entry in tail),
            'equalWorkPercent': percent(sum(entry['numeratorMs'] for entry in tail), sum(entry['denominatorMs'] for entry in tail)),
            'numeratorFasterBlocks': sum(entry['numeratorMs'] < entry['denominatorMs'] for entry in tail),
            'equalBlocks': sum(entry['numeratorMs'] == entry['denominatorMs'] for entry in tail),
            'medianAbsoluteDifferenceMs': median(entry['differenceMs'] for entry in tail),
            'bestPercent': None if undefined else min(entry['percent'] for entry in tail),
            'worstPercent': None if undefined else max(entry['percent'] for entry in tail),
            'undefinedRatioBlocks': undefined,
            'allTails': tail,
        }
    return {'blocks': values, 'pairs': result}

derived = {clock: {'cold': aggregate(clock, 0),
                   'postcoldSweeps': [aggregate(clock, index) for index in range(1, 5)],
                   'postcoldMean': aggregate(clock, None)} for clock in CLOCKS}

# Reproduce every field of the original controller's three-clock comparisons
# and summary, including all five individual sweeps, from the raw child JSON.
comparisons = []
summary = {}
for block in range(1, 13):
    for clock in ORIGINAL_CLOCKS:
        cold = derived[clock]['cold']['blocks'][block - 1]['values']
        warm = derived[clock]['postcoldMean']['blocks'][block - 1]['values']
        entry = {'block': block, 'clock': clock, 'cold': cold, 'postcoldMean': warm}
        for pair in ('BA', 'CA', 'BC'):
            entry['cold' + pair + 'Percent'] = percent(cold[pair[0]], cold[pair[1]])
            entry['postcold' + pair + 'Percent'] = percent(warm[pair[0]], warm[pair[1]])
        comparisons.append(entry)
assert comparisons == report['comparisons']
for clock in ORIGINAL_CLOCKS:
    cold, warm = derived[clock]['cold'], derived[clock]['postcoldMean']
    entry = {}
    for pair in PAIRS:
        entry['pairedMedian' + pair + 'Percent'] = warm['pairs'][pair]['pairedMedianPercent']
        entry['equalWork' + pair + 'Percent'] = warm['pairs'][pair]['equalWorkPercent']
        entry['coldPairedMedian' + pair + 'Percent'] = cold['pairs'][pair]['pairedMedianPercent']
    entry['candidateFasterBlocks'] = warm['pairs']['BA']['numeratorFasterBlocks']
    entry['candidateFasterThanControlBlocks'] = warm['pairs']['BC']['numeratorFasterBlocks']
    entry['controlFasterBlocks'] = warm['pairs']['CA']['numeratorFasterBlocks']
    entry['allSweeps'] = []
    for index, values in enumerate([cold] + derived[clock]['postcoldSweeps']):
        blocks = []
        for block in values['blocks']:
            arms = block['values']
            row = {'block': block['block'], 'values': arms}
            row.update({pair + 'Percent': percent(arms[pair[0]], arms[pair[1]]) for pair in PAIRS})
            blocks.append(row)
        entry['allSweeps'].append({'sweep': index, 'blocks': blocks,
                                  'pairedMedians': {pair: values['pairs'][pair]['pairedMedianPercent'] for pair in PAIRS},
                                  'equalWork': {pair: values['pairs'][pair]['equalWorkPercent'] for pair in PAIRS}})
    summary[clock] = entry
assert summary == report['summary']

wall = derived['callElapsedMs']['postcoldMean']['pairs']
cpu = derived['cpuTotalMs']['postcoldMean']['pairs']
cold_wall = derived['callElapsedMs']['cold']['pairs']
checks = {
    'candidateMedianWallAgainstBoth': all(wall[pair]['pairedMedianPercent'] <= -2 for pair in ('BA', 'BC')),
    'candidateEqualWorkWallAgainstBoth': all(wall[pair]['equalWorkPercent'] < 0 for pair in ('BA', 'BC')),
    'candidateMedianCpuAgainstBoth': all(cpu[pair]['pairedMedianPercent'] < 0 for pair in ('BA', 'BC')),
    'candidateFasterBlocksAgainstBoth': min(wall[pair]['numeratorFasterBlocks'] for pair in ('BA', 'BC')) >= 9,
    'sameCodeMedianWallDrift': abs(wall['CA']['pairedMedianPercent']) <= 2,
    'sameCodeMedianCpuDrift': abs(cpu['CA']['pairedMedianPercent']) <= 2,
    'coldWallAgainstBoth': all(cold_wall[pair]['pairedMedianPercent'] <= 5 for pair in ('BA', 'BC')),
}
assert checks == report['continuationChecks']
assert all(checks.values()) == report['eligibleForHostedScreen'] == invocation['eligibleForBrowserScreen']

raw_derivation = {
    'schema': 1, 'kind': 'Independent arithmetic from original short-word component observations',
    'artifact': identity(artifact), 'report': identity(raw_members['cohort/report.json']),
    'method': 'All 36 fresh children, every cold and four postcold sweep. Equal-weight mean of each child\'s four postcold clocks; paired ratios across twelve ordered blocks. No pooling of arms, discard, control subtraction, retry or confidence interval not prescribed by the plan.',
    'systemCpuZeroPolicy': 'Every zero-valued counter is retained. If any denominator is zero, that paired percentage is null and the all-block paired median/best/worst percentage is null. Absolute differences, all values, direct faster/tie counts and aggregate equal-work ratio remain. No zero-denominator block is dropped or imputed.',
    'observedValues': raw_values, 'statistics': derived,
}
derivation_id = save('raw-derivation.json', raw_derivation)
compact = {}
for clock, values in derived.items():
    compact[clock] = {}
    for label, data in [('cold', values['cold']), ('postcoldMean', values['postcoldMean'])] + [(f'postcoldSweep{index}', value) for index, value in enumerate(values['postcoldSweeps'], 1)]:
        compact[clock][label] = {pair: {key: value for key, value in result.items() if key != 'allTails'} for pair, result in data['pairs'].items()}
review = {
    'schema': 1, 'kind': 'Independent original short-word component statistical review',
    'reviewStatus': 'PASS', 'acquisitionStatus': 'COMPLETE', 'eligibleForBrowserScreen': False,
    'disposition': 'The literal continuation rule rejects this component. Five of seven checks fail; no browser expansion or whole-import gain is supported.',
    'noNewAcquisitionOrProductExecution': True,
    'source': {'baseline': plan['sources']['A']['commit'], 'candidate': plan['sources']['B']['commit'], 'sameCodeControl': plan['sources']['C']['commit']},
    'identities': {name: {'bytes': value[0], 'sha256': value[1]} for name, value in EXPECTED.items()},
    'originalArtifactMembers': {name: identity(data) for name, data in sorted(raw_members.items())},
    'counts': {'children': 36, 'blocks': 12, 'coldSweeps': 36, 'postcoldSweeps': 144, 'totalSweeps': 180, 'groupsPerSweep': 12, 'banksPerSweep': 53, 'decodedBytesPerSweep': 171617523, 'comparedOriginalClockSummaries': 3, 'comparedOriginalClockBlockRows': 36, 'retainedClocks': 5},
    'rawDerivation': {'path': 'raw-derivation.json', **derivation_id},
    'frozenBoundary': plan['boundary'], 'frozenCriteria': criteria,
    'checks': checks, 'failedChecks': [name for name, passed in checks.items() if not passed],
    'allOriginalSummaryAndComparisonFieldsReproducedExactly': True,
    'matchingObservedOutputDigest': next(iter(digests)), 'matchingObservedFiveSweepHeapShapeBytes': [list(value) for value in next(iter(heap_shapes))],
    'statistics': compact,
    'limits': [
        'This is an independent read-only artifact/statistical review, not a decoder rerun or a new correctness acquisition.',
        'The source/oracle/production-group/failure-accounting review is separately owned by storage_audit; observed hashes and parity are corroborated here but no original input ZIP or product module is executed.',
        'The source gate and component acquisition succeeded; the performance continuation rule failed. Those are distinct outcomes.',
        'Cold means first complete decode after untimed module compilation and input/oracle preparation. Four prescribed postcold sweeps are all retained; no steady-state or browser-import inference is made.',
        'System CPU zeros yield undefined ratios as explicitly recorded, never exclusions or fabricated percentages. Total CPU remains the sole CPU continuation clock.',
        'The earlier zero-child local SIGKILL remains a separate failed acquisition with unknown cause; this complete hosted acquisition does not repair or replace it.',
    ],
}
review_id = save('review.json', review)
print(json.dumps({'status': 'PASS', 'review': review_id, 'derivation': derivation_id,
                  'checks': checks, 'eligible': all(checks.values()),
                  'wallPostcold': {pair: wall[pair]['pairedMedianPercent'] for pair in PAIRS},
                  'cpuPostcold': {pair: cpu[pair]['pairedMedianPercent'] for pair in PAIRS},
                  'coldWall': {pair: cold_wall[pair]['pairedMedianPercent'] for pair in PAIRS}}, allow_nan=False))
