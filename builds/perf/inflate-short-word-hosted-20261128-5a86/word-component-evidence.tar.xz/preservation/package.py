#!/usr/bin/env python3
"""Preserve existing short-word study receipts. Never invokes a decoder or benchmark."""
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import shutil
import subprocess
import tarfile
import zipfile

ROOT = Path('/workspace/scratch/5a86d1e7822a/short-word-hosted')
HOME = Path('/home/agent/manabitan-short-word-final-pack-5a86')
COMPONENT = Path('/home/agent/manabitan-short-word-hosted-5a86/component')
SESSION = Path('/workspace/scratch/5a86d1e7822a/session-evidence')
DEST = ROOT / 'builds/perf/inflate-short-word-hosted-20261128-5a86'
PERSIST = SESSION / 'word-final-evidence'
BASE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
CAND = '49bf79f35084e7c42d1088d5d30c522172d8ec3b'
TREE = 'af9a3630ab5acc04ec82023fc40d30b249983182'
LOCAL = '94ef3d498a3b68b93d89d2f298332fd87b284033'

def require(value, message):
    if not value:
        raise RuntimeError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def identity(data):
    return {'bytes': len(data), 'sha256': sha(data)}

def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def dump(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()

def read_json(path):
    return json.loads(path.read_text())

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

require(git('rev-parse', LOCAL + '^{tree}').decode().strip() == TREE, 'Local tree mismatch')
report_bytes = (COMPONENT / 'extract/cohort/report.json').read_bytes()
require(sha(report_bytes) == 'e99329f0eb72e0820f906415f4723639fc1f57513d0be463df734ce5058c2d1a', 'Report changed')
report = json.loads(report_bytes)
invocation = read_json(COMPONENT / 'extract/invocation.json')
storage_root = SESSION / 'short-word-component-storage-review'
prior_root = SESSION / 'short-word-component-prior-review'
storage_bytes = (storage_root / 'review.json').read_bytes()
prior_bytes = (prior_root / 'review.json').read_bytes()
require(sha(storage_bytes) == '2d34dd87d37c8ad58f40758065baac9658e19050e98ec5a9d3449149567f9193', 'Storage review changed')
require(sha(prior_bytes) == '67013f1ce48858638c974422e7954883fb5ff6a1ba80a78c050c88fa30c35498', 'Numerical review changed')
storage = json.loads(storage_bytes)
prior = json.loads(prior_bytes)
expected_checks = {
    'candidateMedianWallAgainstBoth': False,
    'candidateEqualWorkWallAgainstBoth': False,
    'candidateMedianCpuAgainstBoth': False,
    'candidateFasterBlocksAgainstBoth': False,
    'sameCodeMedianWallDrift': True,
    'sameCodeMedianCpuDrift': True,
    'coldWallAgainstBoth': False,
}
require(report['complete'] is True and report['failure'] is None, 'Acquisition did not complete')
require(report['eligibleForHostedScreen'] is False, 'Unexpected eligibility')
require(report['continuationChecks'] == expected_checks, 'Continuation changed')
require(invocation['eligibleForBrowserScreen'] is False, 'Invocation eligibility differs')
require(len(report['observations']) == 36, 'Incomplete children')
require(invocation['sourceIdentity']['candidate'] == CAND, 'Source mismatch')
require(invocation['sourceIdentity']['candidateTree'] == TREE, 'Tree mismatch')
require(storage['rawCounts']['completeSweeps'] == 180, 'Incomplete sweeps')
require(prior['allOriginalSummaryAndComparisonFieldsReproducedExactly'] is True, 'Numerical audit mismatch')

archive_bytes = (COMPONENT / 'artifact.zip').read_bytes()
require(identity(archive_bytes) == {'bytes': 375497, 'sha256': 'baf07612795ba49af3294f4f92698ec7c1ad49c358ac738e20da6ee681cd89f7'}, 'Original ZIP changed')
members = {}
origins = {}
def add(name, data, origin):
    p = PurePosixPath(name)
    require(not p.is_absolute() and '..' not in p.parts and str(p) == name, 'Unsafe member')
    require(name not in members, 'Duplicate member')
    members[name] = data
    origins[name] = origin

for p in sorted(COMPONENT.iterdir()):
    if p.is_file():
        add('component/' + p.name, p.read_bytes(), str(p))
original_members = {}
with zipfile.ZipFile(io.BytesIO(archive_bytes)) as z:
    infos = [i for i in z.infolist() if not i.is_dir()]
    require(len(infos) == 88 and len({i.filename for i in infos}) == 88, 'Unexpected original ZIP inventory')
    for info in infos:
        q = PurePosixPath(info.filename)
        require(not q.is_absolute() and '..' not in q.parts and str(q) == info.filename, 'Unsafe original ZIP member')
        data = z.read(info)
        require((COMPONENT / 'extract' / info.filename).read_bytes() == data, 'Extracted original differs')
        original_members[info.filename] = identity(data)
        add('component/original-members/' + info.filename, data, 'component/artifact.zip:' + info.filename)

for label, source in [('protocol-review', storage_root), ('statistics-review', prior_root)]:
    for p in sorted(source.rglob('*')):
        if p.is_file():
            require(not p.is_symlink(), 'Review symlink')
            add(label + '/' + p.relative_to(source).as_posix(), p.read_bytes(), str(p))
for p in sorted((HOME / 'pre-acquisition').glob('*.json')):
    add('pre-acquisition/' + p.name, p.read_bytes(), 'Exact pre-acquisition immutable Git blob restored from retained bytes')
require(len([n for n in members if n.startswith('pre-acquisition/')]) == 2, 'Missing pre-acquisition reviews')
require(sha(members['pre-acquisition/storage-review.json']) == 'c4f2c478ee45df802e6ade16d21e9db9568c444eed1e7a00ba616b64399a9c97', 'Pre-acquisition storage review changed')
require(sha(members['pre-acquisition/prior-review.json']) == 'ae1ca62c30d4684007915799080d0d5ae12c45ff3a233d5b3fee95a510f66e7b', 'Pre-acquisition source review changed')

remote_record = Path('/home/agent/manabitan-short-word-validation-prior-review-5a86/remote-git-commit.json').read_bytes()
require(sha(remote_record) == '45543c07c0bcb0a9217c7f4b51a15714dedc4e952f4d79d259ec359b407c3c49', 'GitHub source metadata changed')
add('source/remote-git-commit.json', remote_record, 'Exact recovered original GitHub API commit response; not a raw Git object')
source_files = {}
for path in invocation['sourceIdentity']['changedPaths']:
    data = git('show', LOCAL + ':' + path)
    source_files[path] = identity(data) | {'gitBlobSha': blob(data)}
    add('source/frozen-candidate/' + path, data, CAND + ':' + path + ' via identical local tree ' + TREE)
for path in ['ext/js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h', 'dev/data/dictionary-wasm/term-bank-parser.wasm']:
    data = git('show', BASE + ':' + path)
    add('source/frozen-baseline/' + path, data, BASE + ':' + path)
add('source/identities.json', dump({
    'remoteCommit': CAND, 'tree': TREE, 'baseline': BASE,
    'identicalLocalCommitUsedOnlyToReadBytes': LOCAL,
    'changedPaths': source_files,
    'recordedSourceIdentity': invocation['sourceIdentity'],
    'scope': 'Thirteen exact frozen candidate paths and two baseline decoder artifacts retained as inert bytes; no source executed during preservation.',
}), 'Preservation-only identity index derived from Git and original invocation')
add('preservation/package.py', Path(__file__).read_bytes(), str(Path(__file__)))

HOME.mkdir(parents=True, exist_ok=True)
DEST.mkdir(parents=True, exist_ok=True)
PERSIST.mkdir(parents=True, exist_ok=True)
tar_path = HOME / 'word-component-evidence.tar.xz'
with tarfile.open(tar_path, 'w:xz', format=tarfile.USTAR_FORMAT, preset=6) as tar:
    for name, data in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.uid = info.gid = info.mtime = 0
        info.uname = info.gname = ''
        tar.addfile(info, io.BytesIO(data))
with tarfile.open(tar_path, 'r:xz') as tar:
    require(tar.getnames() == sorted(members), 'Final archive member order differs')
    for info in tar:
        require(info.isfile() and tar.extractfile(info).read() == members[info.name], 'Final archive differs')
packed = tar_path.read_bytes()
manifest = {
    'schemaVersion': 1,
    'kind': 'Final short-word component preservation after completed acquisition and failed performance eligibility',
    'runId': 46112380632, 'componentJobId': 140903680352, 'skippedBrowserJobId': 140915280648,
    'acquisitionCommit': CAND, 'acquisitionTree': TREE, 'baseline': BASE,
    'disposition': 'STOP / NO PR', 'newAcquisitionByPreservation': False,
    'archive': {'path': tar_path.name, **identity(packed), 'gitBlobSha': blob(packed),
                'members': len(members), 'uncompressedBytes': sum(map(len, members.values())),
                'format': 'USTAR regular files in lexical order; mode0644, uid/gid/mtime zero, empty owner names; xz compression'},
    'members': {name: identity(data) for name, data in sorted(members.items())},
    'originalArtifact': {'id': 15255017646, **identity(archive_bytes), 'members': original_members},
    'sourceReadProvenance': {'candidate': CAND, 'candidateTree': TREE, 'identicalLocalCommit': LOCAL,
                           'remoteCommitRecordMember': 'source/remote-git-commit.json'},
    'scope': [
        'Complete original component ZIP, all 88 byte-identical original members, full job log and final job-state snapshot are retained.',
        'All 36 raw child JSON/log pairs, 180 sweeps, oracle, original/adapted protocol inputs and failure-accounting receipts are retained without omission.',
        'Both independent component reviews, their scripts/commands/outputs and reviewer-only preparation failure history are retained.',
        'Both exact final pre-acquisition reviews and all 13 frozen candidate source/test/study paths are retained as inert evidence.',
        'The successful source validation and complete acquisition are distinct from failed performance eligibility. No browser cohort ran.',
        'The independent source-validation/reset recovery pack is retained separately without modification.',
        'This preservation reads existing bytes only. It does not run a decoder, source validation or timing study.',
    ],
    'limits': storage['limitations'] + prior['limits'],
    'excludedReproducibleScratch': [
        {'path': 'Network artifact download reference', 'reason': 'Expiring signed URL is not retained; original artifact ID, byte count, digest and complete ZIP are retained.'},
        {'path': 'Other local temporary extraction directories and repeated review copies', 'reason': 'All original component members and exact independently supplied review directories are included once under their explicit namespaces; the retained prior statistics subarchive intentionally duplicates its original review files.'},
    ],
    'verification': 'Every final tar member was decoded and byte-compared to the retained source bytes; every one of the 88 extracted component members was also byte-compared to the original ZIP.',
}
(HOME / 'word-component-manifest.json.txt').write_bytes(dump(manifest))
validation_root = SESSION / 'word-source-validation-preserved'
validation_pack = (validation_root / 'word-source-validation.tar.xz').read_bytes()
validation_manifest = (validation_root / 'manifest.json').read_bytes()
require(sha(validation_pack) == 'adb1850f3b2452ec5fabe1c607986cccca152a297cf48d97b71b46741ceb6212', 'Source validation pack changed')
require(sha(validation_manifest) == 'd0d9f6cc8df507069c4251684fda856dbe41fd7c3fa00be9921f86729ec2ac4b', 'Source validation manifest changed')
(HOME / 'word-source-validation.tar.xz').write_bytes(validation_pack)
(HOME / 'word-source-validation-manifest.json.txt').write_bytes(validation_manifest)

short_summary = {
    clock: {key: value for key, value in values.items() if key != 'allSweeps'}
    for clock, values in report['summary'].items()
}
sweep_summary = {
    clock: [{key: value for key, value in sweep.items() if key != 'blocks'} for sweep in values['allSweeps']]
    for clock, values in report['summary'].items()
}
summary = {
    'schemaVersion': 1, 'study': 'inflate-short-word-20261128-5a86',
    'finalDisposition': 'STOP / NO PR',
    'reason': 'Complete fixed decoder component regressed against both identical-code baseline arms; five of seven predeclared continuation checks failed.',
    'run': {'id': 46112380632, 'url': 'https://github.com/ManabiIO/manabitan/actions/runs/46112380632',
            'validationJobId': 140878598879, 'componentJobId': 140903680352, 'skippedBrowserJobId': 140915280648},
    'source': {'baseline': BASE, 'candidate': CAND, 'candidateTree': TREE,
               'originalProductCommit': '1c93b0a18f5dd53a13dfdd3d054687c85e097247',
               'originalProductTree': '7bf2f889a94d955bf8845b9f8d9e2d4afb464617',
               'parserModules': invocation['sourceIdentity']['parserModules'],
               'packageEntriesDeclaredForConditionalBrowserGate': invocation['sourceIdentity']['packageEntries']},
    'statuses': {'sourceValidation': 'SUCCESS', 'componentAcquisition': 'COMPLETE',
                 'componentFailure': None, 'performanceEligibility': False,
                 'conditionalBrowserExpansion': 'SKIPPED', 'actualBrowserImports': 0,
                 'originalLocalAcquisition': 'FAILED/HOLD, zero children and zero sweeps, cause unknown'},
    'counts': storage['rawCounts'],
    'fixture': invocation['sourceIdentity']['fixtures']['jmdict'],
    'policy': report['plan']['policy'],
    'schedule': {'orders': report['plan']['orders'], 'freshProcesses': 36,
                 'coldSweeps': 36, 'postcoldSweeps': 144, 'totalSweeps': 180,
                 'postcoldSummary': 'Mean of all four prescribed postcold sweeps per child; all individual sweeps and tails retained. No steady-state claim.'},
    'predeclaredContinuation': report['plan']['continuation'],
    'continuationChecks': report['continuationChecks'],
    'reportedClockSummaryPercent': short_summary,
    'everySweepSummaryPercent': sweep_summary,
    'allClockAndTailScope': 'The exact numerical review retains callElapsedMs, sourceInflateMs, cpuTotalMs, cpuUserMs and cpuSystemMs, all cold/postcold per-block and per-sweep values. Zero system-CPU denominators remain null, never dropped.',
    'sourceValidation': {
        'status': 'PASS', 'scopedLint': 'test/term-bank-inflater.test.js',
        'typeProjects': 4, 'unitTestsPassed': 15143, 'unitTestsSkipped': 47, 'unitTestFiles': 669,
        'pinnedNativeArtifactsReproduced': 2, 'clangAndLldVersion': '21.1.8',
        'nativeSanitizerCases': 231528, 'sanitizers': ['address', 'undefined', 'leak'],
        'nativeSanitizerCompiler': 'GCC 15.2.0-16ubuntu1', 'nativeWordBytes': 8,
        'buildScope': 'npm run test:build -> node dev/bin/build.js --dryRun --all, seven targets; no validation-stage product ZIP build claimed',
        'syntheticOracleChecks': 15, 'receiptObserverTests': 32,
    },
    'runtime': {'nodeVersion': report['plan']['nodeVersion'], 'nodeExecutableSha256': report['plan']['nodeExecutableSha256']},
    'keyOriginals': {
        'componentArtifactZip': {'artifactId': 15255017646, **identity(archive_bytes)},
        'componentJobLog': identity((COMPONENT / 'job.log').read_bytes()),
        'componentReport': identity(report_bytes),
        'oracle': identity((COMPONENT / 'extract/oracle.json').read_bytes()),
        'invocation': identity((COMPONENT / 'extract/invocation.json').read_bytes()),
        'validationArtifactZip': {'artifactId': 15253507283, 'bytes': 160484,
                                  'sha256': '69eab665c19c68701eae005f6fb67958f46bdf1f4183b80615652aa5e0a3816c'},
    },
    'independentReviews': {
        'sourceValidation': {'sha256': 'e5fa0aec1040a1b4e7d2ceb2e4198499e451bdbc50c54a2c7a63e0f4d82f95c9', 'bytes': 17121,
                             'member': 'independent-review/review.json in word-source-validation.tar.xz'},
        'componentProtocolOracleAndReceipts': {**identity(storage_bytes), 'member': 'protocol-review/review.json in word-component-evidence.tar.xz'},
        'componentAllClockStatisticsAndSevenGuards': {**identity(prior_bytes), 'member': 'statistics-review/review.json in word-component-evidence.tar.xz'},
    },
    'preservedEvidence': {
        'sourceValidationArchive': {'path': 'word-source-validation.tar.xz', **identity(validation_pack)},
        'sourceValidationManifest': {'path': 'word-source-validation-manifest.json.txt', **identity(validation_manifest)},
        'componentArchive': {'path': 'word-component-evidence.tar.xz', **identity(packed)},
        'componentManifest': {'path': 'word-component-manifest.json.txt', **identity((HOME / 'word-component-manifest.json.txt').read_bytes())},
    },
    'limitations': [
        'This is a Node decoder component result, not a browser full-import or whole-process browser-memory result. Browser expansion was skipped exactly as registered.',
        'All 53 complete decoded banks are checked by full digest/CRC/span and input-consumption receipts; the decoded corpus bytes themselves are not in the artifact. This is not a parser row-output replay.',
        'The fixture declares 528299 term rows; the decoder component does not independently parse/count term rows.',
        'The native sourceInflateMs clock includes immediate CRC; the callElapsedMs clock also includes the production helper allocation/copy boundary. Concurrent whole-import phase ceilings are not inferred.',
        'The extra branch reduced modeled source-level speculative stores, but the experiment did not isolate the machine-code reason for regression. No instruction-count or causal slowdown claim follows.',
        'The old local signal-9 acquisition remains FAILED/HOLD with zero observations, unknown cause and unknown initial-versus-pre-slot verification substage. It was not retried, repaired or replaced.',
        'The first reset left the native census and most local validation/preflight logs unavailable. Frozen local-evidence.tar.gz explicitly distinguishes exact recoveries from missing originals; no missing native counts were reconstructed.',
        'The hosted oracle is a new independent pre-timing Python-zlib oracle, bound before the first child, not the missing native census oracle.',
        'The second reset erased local source-validation downloads/review support. Exact original artifact/log/report identities were recovered, with the separately preserved recovery ledgers distinguishing proven bytes from transcript-reserialized metadata and one historical command receipt without a prior whole-file digest.',
        'Reviewer-only preparation assumptions and corrections are retained. They did not replace any observation or change source, criteria or acquisition.',
        'This final follow-up changes evidence and the single handoff only. The observed source stays frozen at ' + CAND + '; no new study, PR or default change is authorized by these results.',
    ],
}
(HOME / 'summary.json.txt').write_bytes(dump(summary))
deliverables = ['word-source-validation.tar.xz', 'word-source-validation-manifest.json.txt',
                'word-component-evidence.tar.xz', 'word-component-manifest.json.txt', 'summary.json.txt']
for name in deliverables:
    data = (HOME / name).read_bytes()
    (DEST / name).write_bytes(data)
    (PERSIST / name).write_bytes(data)
publication = {str((DEST / n).relative_to(ROOT)): {**identity((DEST/n).read_bytes()), 'gitBlobSha': blob((DEST/n).read_bytes())} for n in deliverables}
(HOME / 'publication-files.json').write_bytes(dump(publication))
(PERSIST / 'publication-files.json').write_bytes(dump(publication))
print(json.dumps({'members': len(members), 'uncompressedBytes': sum(map(len,members.values())),
                  'archive': identity(packed), 'files': publication}, indent=2))

