import pathlib,json,hashlib,zipfile,re
assert __debug__, 'Do not use optimized Python'
ROOT=pathlib.Path('/home/agent/manabitan-short-word-hosted-5a86/validation')
BASE='9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
CAND='49bf79f35084e7c42d1088d5d30c522172d8ec3b'
TREE='af9a3630ab5acc04ec82023fc40d30b249983182'
def sha(b):return hashlib.sha256(b).hexdigest()
meta=json.loads((ROOT/'artifact-metadata.json').read_bytes());archive=(ROOT/'artifact.zip').read_bytes()
assert meta['id']==15253507283 and meta['workflow_run']['id']==46112380632 and meta['workflow_run']['head_sha']==CAND
assert len(archive)==160484==meta['size_in_bytes'] and sha(archive)=='69eab665c19c68701eae005f6fb67958f46bdf1f4183b80615652aa5e0a3816c' and meta['digest']=='sha256:'+sha(archive)
job=json.loads((ROOT/'job-status.json').read_bytes())
assert job['id']==140878598879 and job['run_id']==46112380632 and job['status']=='completed' and job['conclusion']=='success'
assert all(s['status']=='completed' and s['conclusion']=='success' for s in job['steps'])
log=(ROOT/'job.log').read_text();assert sha(log.encode())=='f9e151252b3d7ffe4182e996d046717dc05fc09014171421be2989b933c8520c'
with zipfile.ZipFile(ROOT/'artifact.zip') as z:
    names=z.namelist();assert len(names)==len(set(names))==21
    files={n:z.read(n) for n in names}
expected={'build.log','lint.log','json-format.log','local-evidence.log','native-address-undefined-leak.log','native-rebuild.log','native-sanitizer-build.log','native-sanitizer-compiler.log','observer-preflight/invocation.json','observer-preflight/observe.mjs','observer-preflight/observer-syntax.log','observer-preflight/original-plan.json','observer-preflight/original-run.py.txt','observer-preflight/streamed-controller.py','observer-preflight/synthetic-oracle-input.zip','observer-preflight.log','receipt-tests.log','source.log','term-bank-inflater-sanitizer','types.log','unit.log'}
assert set(names)==expected
native_text=files['native-rebuild.log'].decode()
native=json.loads(native_text[native_text.index('{'):])
assert native['mode']=='check' and native['toolchain']=={'compilerVersion':'21.1.8','linkerVersion':'21.1.8'}
assert {x['name']:x['sha256'] for x in native['targets']}=={'term-content-canonical-scan-v1.wasm':'40948d5c20d26253e86c93d267e3cbb3817ea87c9731e02bcca0523c0eb3d6af','term-bank-parser.wasm':'e522cb7f60cef3c8d305853afc57e8eb6c5d2121bf39ae773bff407901cc04b6'}
plain=re.sub(r'\x1b\[[0-9;]*m','',files['unit.log'].decode())
assert re.search(r'Test Files\s+669 passed \(669\)',plain)
assert re.search(r'Tests\s+15143 passed \| 47 skipped \(15190\)',plain)
for project in ['jsconfig.json','dev/jsconfig.json','test/jsconfig.typecheck.json','benches/jsconfig.json']:
    assert '--project '+project in files['types.log'].decode()
assert 'Run npx eslint test/term-bank-inflater.test.js' in log
assert '-fsanitize=address,undefined -fno-omit-frame-pointer' in log
assert 'ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 LSAN_OPTIONS=exitcode=23 UBSAN_OPTIONS=halt_on_error=1' in log
assert files['native-address-undefined-leak.log']==b'231528 exact decoder cases passed; portable native word size=8, context bytes=11568\n'
assert files['native-sanitizer-build.log']==b'' and '15.2.0-16ubuntu1' in files['native-sanitizer-compiler.log'].decode()
builds=re.findall(r'^Building ([a-z-]+)\.\.\.$',files['build.log'].decode(),re.M)
assert builds==['chrome','chrome-dev','chrome-playwright','firefox','firefox-dev','firefox-android','edge']
assert 'Ran 32 tests in ' in files['receipt-tests.log'].decode() and re.search(r'(?m)^OK$',files['receipt-tests.log'].decode())
inv=json.loads(files['observer-preflight/invocation.json'])
assert inv['status']=='preflight-complete' and inv['noWasmDecodeOrTimingObservation'] is True and inv['eligibleForBrowserScreen'] is False
assert inv['host']['nodeVersion']=='v22.22.0' and inv['host']['nodeExecutableSha256']=='1bec56ef7cfa9a76f3e0b7c0a87f220eb73f23102b9c0b4c7529a3f7c3ce7c31'
assert inv['sourceIdentity']['baseline']==BASE and inv['sourceIdentity']['candidate']==CAND and inv['sourceIdentity']['candidateTree']==TREE and len(inv['sourceIdentity']['changedPaths'])==13
assert inv['originalProductCommit']=='1c93b0a18f5dd53a13dfdd3d054687c85e097247' and inv['originalProductTree']=='7bf2f889a94d955bf8845b9f8d9e2d4afb464617'
assert inv['oracleValidation']['caseCount']==len(inv['oracleValidation']['cases'])==15
assert inv['originalLocalCohort']['status']=='FAILED/HOLD' and inv['originalLocalCohort']['children']==inv['originalLocalCohort']['sweeps']==0 and inv['originalLocalCohort']['signal']==9
expected_originals={'observer-preflight/observe.mjs':'4bd1085be4fd16cc5e5246be3682bcabfdb546331afb4d5ce123084a9f37a4e4','observer-preflight/original-run.py.txt':'6740a59f94254e2d0060f094993c818f73a472fd9b7be96deceaa13139274c92','observer-preflight/original-plan.json':'1ae467eaa524b3aa71d25463fab594379d6d2ee607294bfb351cdde266eee802'}
for n,h in expected_originals.items():assert sha(files[n])==h
assert sha(files['observer-preflight/streamed-controller.py'])==inv['adaptedControllerSha256']
local=json.loads(files['local-evidence.log']);assert local['completeOriginalEvidence'] is False and local['originalHashChecks']==15 and local['localCohort']=={'status':'FAILED/HOLD','children':0,'sweeps':0,'signal':9,'timingEstimate':None}
report={'status':'PASS','scope':'Audit of retained completed hosted validation receipts only; no validation command, parser, benchmark or acquisition was reexecuted locally.','runId':46112380632,'jobId':140878598879,'baseline':BASE,'candidate':CAND,'candidateTree':TREE,'artifact':meta,'jobLog':{'bytes':len(log.encode()),'sha256':sha(log.encode())},'checks':{'sourceAndProductGuard':'passed on exact 13-path source','nativeWasmCompilerAndLinker':'21.1.8','nativeParserSha256':'e522cb7f60cef3c8d305853afc57e8eb6c5d2121bf39ae773bff407901cc04b6','unitPassed':15143,'unitSkipped':47,'unitFilesPassed':669,'typeProjects':4,'lint':'Exact changed test source only','oracleSelfTestCases':15,'observerReceiptTests':32,'nativeSanitizerCases':231528,'nativeSanitizerModes':['address','undefined','leak-enabled'],'nativeSanitizerCompiler':'GCC (Ubuntu 15.2.0-16ubuntu1) 15.2.0','nativeSanitizerWordBytes':8,'buildTargets':builds,'generatedJson':'completed source gate success'},'preflight':{'nodeVersion':inv['host']['nodeVersion'],'nodeExecutableSha256':inv['host']['nodeExecutableSha256'],'noWasmDecodeOrTimingObservation':True,'eligibleForBrowserScreen':False,'adaptedControllerSha256':inv['adaptedControllerSha256']},'originalLocalCohort':local['localCohort'],'limits':['Hosted validation is separate from the failed zero-child local cohort and does not retroactively pass or recover its missing raw logs.','The archive recovery verifier explicitly reports incomplete original evidence; its Git bundle verification option was not invoked in this command. The separate exact source guard reconstructs the frozen original product tree.','No component or whole-import speed effect is established by this source validation.','Sanitizer output is preserved and its executable is hashed only, not executed by this audit.'],'members':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in files.items()}}
(ROOT/'validation-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','reportSha256':sha((ROOT/'validation-audit.json').read_bytes()),'unitPassed':15143,'nativeSanitizerCases':231528,'members':len(files)}))
