#!/usr/bin/env python3
"""Compare exact release entries from the frozen current-parent metadata pair."""
import hashlib
import json
import pathlib
import subprocess
import zipfile

OUT = pathlib.Path(__file__).resolve().parent
ARMS = {
    'A': (pathlib.Path('/home/agent/manabitan-current-base-4d9ffe79ec6f'), 'f28c2801fcfd9416f220b46b9cbafeee901c1cb2'),
    'B': (pathlib.Path('/home/agent/manabitan-metadata-current-4d9ffe79ec6f'), '81e203e084c009e79057a36d0e2106ef669ab168'),
}
EXPECTED_CHANGED = {
    'js/dictionary/dictionary-database.js',
    'js/dictionary/term-content-canonical-scan.js',
    'js/dictionary/term-content-metadata-arena.js',
    'js/dictionary/wasm/term-content-canonical-scan-v1.c',
    'lib/term-content-canonical-scan-v1.wasm',
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


reports = {}
members = {}
for arm, (root, source) in ARMS.items():
    actual = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip()
    assert actual == source, (arm, actual)
    assert subprocess.check_output(['git', '-C', str(root), 'diff', 'HEAD']) == b''
    package = root / 'builds/manabitan-chrome.zip'
    entries = {}
    with zipfile.ZipFile(package) as archive:
        names = [item.filename for item in archive.infolist() if not item.is_dir()]
        assert len(names) == len(set(names)), 'Duplicate release entry'
        for name in sorted(names):
            value = archive.read(name)
            entries[name] = {'bytes': len(value), 'sha256': digest(value)}
        manifest = json.loads(archive.read('manifest.json'))
        assert manifest['manifest_version'] == 3
        assert manifest['version'] == '0.0.0.0'
        for name in EXPECTED_CHANGED - {'lib/term-content-canonical-scan-v1.wasm'}:
            assert entries[name]['sha256'] == digest((root / 'ext' / name).read_bytes())
        native = root / 'dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm'
        assert entries['lib/term-content-canonical-scan-v1.wasm']['sha256'] == digest(native.read_bytes())
    members[arm] = entries
    reports[arm] = {
        'sourceId': source,
        'sourceTree': subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD^{tree}'], text=True).strip(),
        'package': str(package), 'packageBytes': package.stat().st_size,
        'packageSha256': digest(package.read_bytes()), 'entryCount': len(entries),
        'uncompressedBytes': sum(item['bytes'] for item in entries.values()), 'entries': entries,
    }
assert members['A'].keys() == members['B'].keys(), 'Release file set changed'
changed = {name for name in members['A'] if members['A'][name] != members['B'][name]}
assert changed == EXPECTED_CHANGED, changed
result = {
    'schemaVersion': 1,
    'scope': 'exact release ZIP entry audit; no performance acquisition',
    'arms': reports,
    'changedEntries': [{
        'path': name, 'A': members['A'][name], 'B': members['B'][name],
    } for name in sorted(changed)],
    'unchangedEntryCount': len(members['A']) - len(changed),
    'conclusion': 'The four intended runtime entries and their shipped canonical C source differ; no added, removed or other changed release entries.',
}
target = OUT / 'package-audit.json'
assert not target.exists(), 'Refusing to overwrite a previous package audit'
target.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({
    'arms': {arm: {k: v for k, v in report.items() if k != 'entries'} for arm, report in reports.items()},
    'changedEntries': result['changedEntries'], 'unchangedEntryCount': result['unchangedEntryCount'],
}, indent=2))
