#!/usr/bin/env python3
"""Run one authorized validation command and retain exact status/provenance."""
import argparse
import datetime
import hashlib
import json
import os
import pathlib
import signal
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--source-root', required=True)
parser.add_argument('--source-id', required=True)
parser.add_argument('--label', required=True)
parser.add_argument('--timeout', type=int, default=1200)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[:1] == ['--'] else args.command
if not command:
    parser.error('a command is required after --')
root = pathlib.Path(args.source_root).resolve()
out = pathlib.Path(__file__).resolve().parent / 'validation' / args.label
out.mkdir(parents=True, exist_ok=False)
node = pathlib.Path('/home/agent/manabitan-node22-4d9ffe79ec6f/node')
llvm = pathlib.Path('/workspace/scratch/4d9ffe79ec6f/toolchains/llvm21')
env = dict(os.environ)
env.update({
    'PATH': str(node.parent) + ':' + str(llvm / 'usr/bin') + ':' + str(llvm / 'usr/lib/llvm-21/bin') + ':' + env.get('PATH', ''),
    'LD_LIBRARY_PATH': str(llvm / 'usr/lib/x86_64-linux-gnu'),
    'MANABITAN_CLANG': str(llvm / 'usr/lib/llvm-21/bin/clang'),
    'MANABITAN_WASM_LD': str(llvm / 'usr/lib/llvm-21/bin/wasm-ld'),
})


def git(*argv):
    return subprocess.check_output(['git', '-C', str(root), *argv], text=True).strip()


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()


actual = git('rev-parse', 'HEAD')
if actual != args.source_id:
    raise RuntimeError(f'expected source {args.source_id}, got {actual}')
receipt = {
    'sourceRoot': str(root), 'sourceId': actual, 'sourceTree': git('rev-parse', 'HEAD^{tree}'),
    'command': command, 'nodeVersion': subprocess.check_output([str(node), '--version'], text=True).strip(),
    'nodeSha256': digest(node), 'startedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'workingDiffBefore': git('diff', '--stat', 'HEAD'),
    'environmentOverrides': {k: env[k] for k in ('PATH', 'LD_LIBRARY_PATH', 'MANABITAN_CLANG', 'MANABITAN_WASM_LD')},
    'timeoutSeconds': args.timeout,
}
(out / 'command.json').write_text(json.dumps(receipt, indent=2) + '\n')
started = time.monotonic()
with (out / 'output.log').open('wb') as log:
    process = subprocess.Popen(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    timed_out = False
    try:
        returncode = process.wait(timeout=args.timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            returncode = process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            returncode = process.wait()
result = {
    **receipt, 'finishedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'diagnosticElapsedSeconds': time.monotonic() - started, 'returnCode': returncode,
    'signal': signal.Signals(-returncode).name if returncode < 0 else None, 'timedOut': timed_out,
    'workingDiffAfter': git('diff', '--stat', 'HEAD'), 'logSha256': digest(out / 'output.log'),
}
(out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'label': args.label, 'returnCode': returncode, 'signal': result['signal'], 'timedOut': timed_out, 'output': str(out)}, indent=2))
raise SystemExit(returncode if returncode >= 0 else 128 - returncode)
