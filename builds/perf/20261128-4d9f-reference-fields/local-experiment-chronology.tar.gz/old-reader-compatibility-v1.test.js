// Local qualification of the actual previous reader, not shipped product code.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile, writeFile} from 'node:fs/promises';
import path from 'node:path';
import sqlite3InitModule from '@sqlite.org/sqlite-wasm';
import {expect, test, vi} from 'vitest';

test('actual current-parent reader refuses floor12 before recovery and preserves SQLite bytes', async () => {
    const root = '/workspace/scratch/4d9ffe79ec6f/manabitan';
    const oldFile = path.join(root, 'ext/js/dictionary/dictionary-database.js');
    const hash = bytes => createHash('sha256').update(bytes).digest('hex');
    assert.equal(hash(await readFile(oldFile)), '75da1c10c8cefd238e17aaabb44fca71f39e2f4e412660420c1e675d9cc7b84b');
    const sqlite3 = await sqlite3InitModule();
    const connection = new sqlite3.oo1.DB(':memory:');
    try {
        connection.exec("CREATE TABLE published_dictionary(summary TEXT, payload BLOB); INSERT INTO published_dictionary VALUES ('format4 published', X'00010203FF');");
        connection.exec('BEGIN; PRAGMA user_version = 12; COMMIT;');
        const before = sqlite3.capi.sqlite3_js_db_export(connection.pointer);
        const sqliteFile = path.join(root, 'ext/js/dictionary/sqlite-wasm.js');
        vi.doMock(sqliteFile, async () => ({
            ...await vi.importActual(sqliteFile),
            getSqlite3: vi.fn(async () => sqlite3),
            openOpfsDatabase: vi.fn(async () => connection),
        }));
        const {DictionaryDatabase} = await import(oldFile);
        const database = new DictionaryDatabase();
        const recovery = vi.spyOn(database, '_recoverInterruptedImportSession').mockResolvedValue();
        const content = vi.spyOn(database._termContentStore, 'prepare').mockResolvedValue();
        const records = vi.spyOn(database._termRecordStore, 'prepare').mockResolvedValue();
        const schema = vi.spyOn(database, '_initializeSchema').mockResolvedValue();
        const runtime = vi.spyOn(database, '_applyRuntimePragmas').mockImplementation(() => {});
        const health = vi.spyOn(database, '_restoreTermRecordDictionaryHealth').mockImplementation(() => {});
        await expect(database._openConnection()).rejects.toThrow('Dictionary storage schema 12 is newer than this build supports (11)');
        for (const method of [recovery, content, records, schema, runtime, health]) { expect(method).not.toHaveBeenCalled(); }
        const after = sqlite3.capi.sqlite3_js_db_export(connection.pointer);
        assert.deepEqual(after, before);
        assert.equal(connection.selectValue('PRAGMA user_version'), 12);
        assert.deepEqual(connection.selectValues('SELECT summary FROM published_dictionary'), ['format4 published']);
        await writeFile('/workspace/scratch/4d9ffe79ec6f/experiments/record-reference-table/prototype/old-reader-result.json', JSON.stringify({
            success: true, readerDatabaseSha256: hash(await readFile(oldFile)),
            beforeDatabaseSha256: hash(before), afterDatabaseSha256: hash(after), databaseBytes: after.byteLength,
            userVersion: 12, recoveryCalls: recovery.mock.calls.length, contentPrepareCalls: content.mock.calls.length,
            recordPrepareCalls: records.mock.calls.length, schemaCalls: schema.mock.calls.length,
            runtimePragmaCalls: runtime.mock.calls.length, healthRestoreCalls: health.mock.calls.length,
            boundary: 'Actual previous DictionaryDatabase._openConnection with real SQLite; OPFS prepare/recovery are observation spies and never reached. No older-browser restart claim.',
        }, null, 2) + '\n');
    } finally { connection.close(); vi.restoreAllMocks(); }
});
