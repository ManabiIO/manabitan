// Local qualification of the actual previous reader, not shipped product code.
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {readFile, readdir, writeFile} from 'node:fs/promises';
import path from 'node:path';
import sqlite3InitModule from '@sqlite.org/sqlite-wasm';
import {expect, test, vi} from 'vitest';

test('actual current-parent reader refuses floor12 before recovery and preserves SQLite bytes', async () => {
    const root = '/workspace/scratch/4d9ffe79ec6f/manabitan';
    const oldFile = path.join(root, 'ext/js/dictionary/dictionary-database.js');
    const hash = bytes => createHash('sha256').update(bytes).digest('hex');
    assert.equal(hash(await readFile(oldFile)), '75da1c10c8cefd238e17aaabb44fca71f39e2f4e412660420c1e675d9cc7b84b');
    const candidateCommit = execFileSync('git', ['rev-parse', 'HEAD'], {encoding: 'utf8'}).trim();
    assert.equal(candidateCommit, '2dd9058a74ec4b4b9195a168fbc167d37fe59f88');
    assert.equal(execFileSync('git', ['diff', 'HEAD', '--binary']).byteLength, 0);
    const sqlite3 = await sqlite3InitModule();
    const connection = new sqlite3.oo1.DB(':memory:');
    const {createBoundedNodeOpfs} = await import('/workspace/scratch/4d9ffe79ec6f/experiments/record-reference-table/node-opfs-bounded.mjs');
    const environment = await createBoundedNodeOpfs();
    vi.stubGlobal('navigator', {storage: {getDirectory: async () => environment.root}});
    const fileHashes = async () => {
        const files = [];
        const walk = async (relative) => {
            for (const entry of await readdir(path.join(environment.rootPath, relative), {withFileTypes: true})) {
                const name = path.join(relative, entry.name);
                if (entry.isDirectory()) { await walk(name); }
                else { const bytes = await readFile(path.join(environment.rootPath, name)); files.push({name, bytes: bytes.byteLength, sha256: hash(bytes)}); }
            }
        };
        await walk('');
        return files.sort((a, b) => a.name.localeCompare(b.name));
    };
    try {
        const {TermRecordOpfsStore, createArtifactTermRecordChunkWithResolvedContent} = await import(path.join(process.cwd(), 'ext/js/dictionary/term-record-opfs-store.js'));
        const writer = new TermRecordOpfsStore();
        await writer.prepare();
        writer.setImportExperiments({experimentalReferenceTableFields: true});
        await writer.beginImportSession();
        const expressions = Array.from({length: 128}, (_, row) => new TextEncoder().encode(`term${row}`));
        const chunk = createArtifactTermRecordChunkWithResolvedContent({
            dictionary: 'Published format4', dictionaryTotalRows: 528299, rowCount: 128,
            expressionBytesList: expressions, readingBytesList: expressions,
            readingEqualsExpressionList: new Uint8Array(128).fill(1),
            scoreList: Int32Array.from({length: 128}, (_, row) => row % 5),
            sequenceList: new Int32Array(128).fill(-1),
        }, Uint32Array.from({length: 128}, (_, row) => row % 3), Float64Array.of(16, 40, 100), Uint32Array.of(7, 9, 11));
        await writer.appendBatchFromArtifactChunkResolvedContent(chunk, [], [], 'raw');
        await writer.endImportSession();
        assert.equal(writer.getLastEndImportSessionMetrics().referenceTableFieldChunkCount, 1);
        const beforeFiles = await fileHashes();
        assert.equal(beforeFiles.length, 2);
        const index = await readFile(path.join(environment.rootPath, beforeFiles.find(file => file.name.endsWith('.mbti')).name));
        assert.equal(index.readUInt32LE(76), 4);
        connection.exec("CREATE TABLE published_dictionary(summary TEXT, payload BLOB); INSERT INTO published_dictionary VALUES ('format4 published', X'00010203FF');");
        connection.exec('BEGIN; PRAGMA user_version = 12; COMMIT;');
        const before = sqlite3.capi.sqlite3_js_db_export(connection.pointer);
        const sqliteFile = path.join(root, 'ext/js/dictionary/sqlite-wasm.js');
        vi.doMock(sqliteFile, async () => ({
            ...await vi.importActual(sqliteFile),
            getSqlite3: vi.fn(async () => sqlite3),
            openOpfsDatabase: vi.fn(async () => connection),
        }));
        const {DictionaryDatabase} = await import(oldFile);
        const database = new DictionaryDatabase();
        const recovery = vi.spyOn(database, '_recoverInterruptedImportSession').mockResolvedValue();
        const content = vi.spyOn(database._termContentStore, 'prepare').mockResolvedValue();
        const records = vi.spyOn(database._termRecordStore, 'prepare').mockResolvedValue();
        const schema = vi.spyOn(database, '_initializeSchema').mockResolvedValue();
        const runtime = vi.spyOn(database, '_applyRuntimePragmas').mockImplementation(() => {});
        const health = vi.spyOn(database, '_restoreTermRecordDictionaryHealth').mockImplementation(() => {});
        await expect(database._openConnection()).rejects.toThrow('Dictionary storage schema 12 is newer than this build supports (11)');
        for (const method of [recovery, content, records, schema, runtime, health]) { expect(method).not.toHaveBeenCalled(); }
        const after = sqlite3.capi.sqlite3_js_db_export(connection.pointer);
        assert.deepEqual(after, before);
        const afterFiles = await fileHashes();
        assert.deepEqual(afterFiles, beforeFiles);
        assert.equal(connection.selectValue('PRAGMA user_version'), 12);
        assert.deepEqual(connection.selectValues('SELECT summary FROM published_dictionary'), ['format4 published']);
        await writeFile('/workspace/scratch/4d9ffe79ec6f/experiments/record-reference-table/prototype/old-reader-result-v2.json', JSON.stringify({
            success: true, readerDatabaseSha256: hash(await readFile(oldFile)),
            candidateCommit,
            beforeDatabaseSha256: hash(before), afterDatabaseSha256: hash(after), databaseBytes: after.byteLength,
            userVersion: 12, recoveryCalls: recovery.mock.calls.length, contentPrepareCalls: content.mock.calls.length,
            recordPrepareCalls: records.mock.calls.length, schemaCalls: schema.mock.calls.length,
            runtimePragmaCalls: runtime.mock.calls.length, healthRestoreCalls: health.mock.calls.length,
            beforeFiles, afterFiles, actualFormat4Chunks: 1,
            boundary: 'Actual previous DictionaryDatabase._openConnection with real SQLite and real format4 record/index files from the candidate writer. OPFS prepare/recovery are observation spies and never reached; every SQLite and OPFS byte remains identical. No older-browser restart claim.',
        }, null, 2) + '\n');
    } finally { connection.close(); vi.restoreAllMocks(); vi.unstubAllGlobals(); await environment.dispose(); }
});
